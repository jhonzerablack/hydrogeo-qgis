"""MODELED drainage topology; synthetic stage only, no QGIS integration.

Input polylines must be explicitly noded at proven junctions. Vertex order is
ignored. Outlet, flow evidence and completeness are caller assertions.
"""
from collections import Counter, defaultdict
from math import dist, isfinite

SCHEMA_VERSION = "0.8.0-synthetic2"
IMPLEMENTATION_STATUS = "synthetic_validation_only"


class TopologyError(ValueError):
    """Expected rejection serialized by the public API."""


def _reject(reason):
    raise TopologyError(reason)


def _point(value):
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        _reject("invalid_coordinates")
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or
           not isfinite(x) for x in value):
        _reject("invalid_coordinates")
    return tuple(float(x) for x in value)


def _cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def _on(a, b, p):
    return (_cross(a,b,p) == 0 and
            min(a[0],b[0]) <= p[0] <= max(a[0],b[0]) and
            min(a[1],b[1]) <= p[1] <= max(a[1],b[1]))


def _intersection(a, b, c, d):
    x,y,z,w = _cross(a,b,c),_cross(a,b,d),_cross(c,d,a),_cross(c,d,b)
    touching = {p for p in (a,b,c,d) if _on(a,b,p) and _on(c,d,p)}
    if len(touching) > 1: return "overlap"
    if touching or ((x > 0 > y or y > 0 > x) and (z > 0 > w or w > 0 > z)):
        return "point"
    return None


def _audit_geometry(lines):
    pieces = [(f,i,a,b) for f,pts in sorted(lines.items())
              for i,(a,b) in enumerate(zip(pts,pts[1:]))]
    for k,(f,i,a,b) in enumerate(pieces):
        if a == b: _reject("zero_length_piece")
        for g,j,c,d in pieces[k+1:]:
            hit = _intersection(a,b,c,d)
            if not hit: continue
            if hit == "overlap": _reject("overlapping_or_duplicate_geometry")
            if f == g:
                if abs(i-j) == 1: continue
                _reject("self_intersection")
            endpoints = {lines[f][0],lines[f][-1]} & {lines[g][0],lines[g][-1]}
            if not ({a,b} & {c,d} & endpoints):
                _reject("unresolved_intersection")


def _unavailable(reasons):
    return {"status":"unavailable", "reason_codes":sorted(set(reasons)), "values":None}


def analyze_drainage_topology(features, *, outlets, snap_tolerance, crs,
                              linear_unit, sources=None):
    """Analyze [{id: str, coordinates: [[x,y], ...]}] pre-noded polylines.

    outlets: [{id, coordinate, direction_evidence, complete_for_rb: bool,
               completeness_evidence: str}]; exactly one terminal per component.
    crs: {id: str, projected: True}; unit: 'm' or 'ft'; explicit tolerance.
    Missing completeness suppresses Rb only. Unsafe snap/geometry rejects the
    network; invalid component topology suppresses that component's metrics.
    """
    result = {
        "schema_version":SCHEMA_VERSION,"product_kind":"modeled_drainage_network",
        "status":"unavailable","reason_codes":[],"metrics":None,
        "methodology":{
            "algorithm":"rooted_tree_strahler_v1",
            "topological_segments":"maximal paths between headwaters, confluences and outlet; degree-2 continuity suppressed",
            "strahler_streams":"maximal continuous same-order paths, including across lower-order tributaries",
            "rb_count_basis":"strahler_streams","rb_formula":"N_u / N_(u+1)",
            "orientation":"unique declared terminal outlet with supplied direction evidence",
            "component_aggregation":"none","connectivity":"pre-noded endpoints; unresolved intersections rejected"},
        "sources":sources,"crs":crs,"linear_unit":linear_unit,
        "tolerances":{"snap":None,"unit":linear_unit,"policy":"euclidean <= tolerance; clique groups; lexicographic canonical coordinate"},
        "snap_audit":[],"components":[],
        "limitations":["modeled_not_field_observed","synthetic_stage_only",
                        "completeness_and_direction_are_caller_assertions",
                        "exact_geometry_predicates_no_hidden_epsilon",
                        "quadratic_checks_not_benchmarked_for_real_networks"],
        "warnings":[] if sources is not None else ["source_metadata_not_supplied"]}
    try:
        if (isinstance(snap_tolerance,bool) or not isinstance(snap_tolerance,(int,float))
                or not isfinite(snap_tolerance) or snap_tolerance < 0):
            _reject("invalid_snap_tolerance")
        result["tolerances"]["snap"] = snap_tolerance
        if not isinstance(crs,dict) or crs.get("projected") is not True or not crs.get("id"):
            _reject("projected_crs_required")
        if linear_unit not in ("m","ft"): _reject("unknown_linear_unit")
        lines = {}
        for feature in features:
            fid = feature.get("id")
            if not isinstance(fid,str) or not fid or fid in lines:
                _reject("invalid_or_duplicate_feature_id")
            pts = feature.get("coordinates")
            if not isinstance(pts,(list,tuple)) or len(pts) < 2:
                _reject("empty_or_invalid_line")
            pts = tuple(_point(p) for p in pts)
            if pts[0] == pts[-1]: _reject("self_loop")
            lines[fid] = min(pts,tuple(reversed(pts)))
        if not lines: _reject("empty_network")
        if len(set(lines.values())) != len(lines): _reject("duplicate_edge")
        _audit_geometry(lines)
        points = sorted({p for pts in lines.values() for p in (pts[0],pts[-1])})
        neighbors = {p:{q for q in points if dist(p,q) <= snap_tolerance} for p in points}
        canonical,unseen = {},set(points)
        while unseen:
            group,stack = set(),[min(unseen)]
            while stack:
                p=stack.pop()
                if p in group: continue
                group.add(p); stack.extend(neighbors[p]-group)
            if any(dist(p,q) > snap_tolerance for p in group for q in group):
                _reject("ambiguous_snap")
            anchor=min(group)
            for p in group: canonical[p]=anchor
            unseen-=group
            members=[{"feature_id":fid,"coordinate":list(p),"distance":dist(p,anchor)}
                     for fid,pts in sorted(lines.items()) for p in (pts[0],pts[-1]) if p in group]
            result["snap_audit"].append({"canonical":list(anchor),"members":members,
                                        "diameter":max(dist(p,q) for p in group for q in group)})
        result["tolerances"]["maximum_effective_displacement"]=max(
            m["distance"] for g in result["snap_audit"] for m in g["members"])
        snapped,adjacency,edges,pairs = {},defaultdict(list),{},set()
        for fid,pts in sorted(lines.items()):
            a,b=canonical[pts[0]],canonical[pts[-1]]
            if a == b: _reject("snap_collapsed_edge")
            pair=tuple(sorted((a,b)))
            if pair in pairs: _reject("duplicate_edge_after_snap")
            pairs.add(pair); edges[fid]=(a,b)
            snapped[fid]=(a,)+pts[1:-1]+(b,)
            adjacency[a].append((b,fid)); adjacency[b].append((a,fid))
        _audit_geometry(snapped)
        declarations,outlet_ids = [],set()
        for outlet in outlets:
            oid=outlet.get("id")
            if not isinstance(oid,str) or not oid or oid in outlet_ids:
                _reject("invalid_or_duplicate_outlet_id")
            outlet_ids.add(oid)
            point=_point(outlet.get("coordinate"))
            candidates={canonical[p] for p in points if dist(p,point) <= snap_tolerance}
            if len(candidates) != 1: _reject("ambiguous_outlet_match")
            declarations.append((next(iter(candidates)),outlet))
        declarations.sort(key=lambda x:x[1]["id"])
        unseen=set(adjacency)
        while unseen:
            nodes,stack=set(),[min(unseen)]
            while stack:
                n=stack.pop()
                if n in nodes: continue
                nodes.add(n); stack.extend(p for p,_ in adjacency[n] if p not in nodes)
            unseen-=nodes
            cedges=sorted(fid for fid,(a,b) in edges.items() if a in nodes)
            declared=[o for n,o in declarations if n in nodes]
            roots=[n for n,o in declarations if n in nodes]
            reasons=[]
            if len(cedges) != len(nodes)-1: reasons.append("cycle_detected")
            if (len(roots) != 1 or (roots and len(adjacency[roots[0]]) != 1)
                    or (declared and not declared[0].get("direction_evidence"))):
                reasons.append("ambiguous_direction")
            component={"id":"component_%03d" % (len(result["components"])+1),
                       "source_feature_ids":cedges,"status":"unavailable","reason_codes":reasons,
                       "metrics":None,"bifurcation_ratios":_unavailable(reasons),"outlet_declarations":declared}
            result["components"].append(component)
            if reasons: continue
            root=roots[0]
            parent,parent_edge,traversal={root:None},{},[root]
            for n in traversal:
                for other,fid in sorted(adjacency[n]):
                    if other not in parent:
                        parent[other]=n; parent_edge[other]=fid; traversal.append(other)
            children={n:[] for n in nodes}
            for n,p in parent.items():
                if p is not None: children[p].append(n)
            orders={}
            for n in reversed(traversal):
                incoming=[orders[ch] for ch in children[n]]
                maximum=max(incoming,default=1)
                orders[n]=maximum + (incoming.count(maximum) >= 2)
            segments=[]
            for n in sorted(nodes):
                if n == root or len(children[n]) == 1: continue
                end,fids=n,[]
                while end != root:
                    fids.append(parent_edge[end]); end=parent[end]
                    if end == root or len(children[end]) != 1: break
                segments.append({"id":"segment_%03d" % (len(segments)+1),
                                 "from":list(n),"to":list(end),"order":orders[n],"source_feature_ids":fids})
            streams,edge_stream=[],{}
            for n in sorted(nodes):
                if n == root or any(orders[ch] == orders[n] for ch in children[n]): continue
                end,fids=n,[]
                sid="stream_%03d" % (len(streams)+1)
                while end != root and orders[end] == orders[n]:
                    fids.append(parent_edge[end]); edge_stream[parent_edge[end]]=sid; end=parent[end]
                streams.append({"id":sid,"from":list(n),"to":list(end),"order":orders[n],"source_feature_ids":fids})
            for s in segments: s["strahler_stream_id"]=edge_stream[s["source_feature_ids"][0]]
            scount=dict(sorted(Counter(s["order"] for s in segments).items()))
            ccount=dict(sorted(Counter(s["order"] for s in streams).items()))
            highest=max(ccount)
            component["status"]="available"
            component["metrics"]={
                "node_count":len(nodes),
                "nodes":[{"coordinate":list(n),"in_degree":len(children[n]),"out_degree":int(n != root),"is_outlet":n == root} for n in sorted(nodes)],
                "modeled_headwater_count":sum(not children[n] for n in nodes),
                "modeled_confluence_count":sum(len(children[n]) >= 2 for n in nodes),
                "terminal_node_count":sum(len(adjacency[n]) == 1 for n in nodes),
                "topological_segments":{"count":len(segments),"counts_by_order":{str(k):v for k,v in scount.items()},"items":segments},
                "strahler_streams":{"count":len(streams),"counts_by_order":{str(k):v for k,v in ccount.items()},"items":streams},
                "max_strahler_order":highest,
                "highest_order_segment_ids":[s["id"] for s in segments if s["order"]==highest],
                "highest_order_stream_ids":[s["id"] for s in streams if s["order"]==highest]}
            rb_reasons=[]
            if declared[0].get("complete_for_rb") is not True or not declared[0].get("completeness_evidence"):
                rb_reasons.append("component_completeness_not_confirmed")
            ratios={str(u):ccount[u]/ccount[u+1] for u in ccount if ccount.get(u+1,0)>0}
            if not ratios: rb_reasons.append("no_consecutive_order_pair")
            component["bifurcation_ratios"]=(_unavailable(rb_reasons) if rb_reasons else
                {"status":"available","reason_codes":[],"count_basis":"strahler_streams","values":ratios})
        if len(result["components"]) > 1:
            result["reason_codes"]=["component_disconnected"]
            result["warnings"].append("per_component_results_only_no_global_aggregation")
        else:
            c=result["components"][0]
            result["status"]=c["status"]; result["reason_codes"]=c["reason_codes"][:]; result["metrics"]=c["metrics"]
    except TopologyError as exc:
        result["reason_codes"]=[str(exc)]
    return result
