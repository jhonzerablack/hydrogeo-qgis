"""Strict GRASS SFD/D8 evidence, with no stream reconstruction or flow repair.

GRASS r.watershed: 1 NE, 2 N, ... 8 E; zero/depressions and negative
region exits are not accepted as evidence of a complete internal network.
"""
import math

OFFSETS = {1: (-1, 1), 2: (-1, 0), 3: (-1, -1), 4: (0, -1),
           5: (1, -1), 6: (1, 0), 7: (1, 1), 8: (0, 1)}
CENTER_TOLERANCE_PIXELS = 1e-6
MAX_NETWORK_EDGES = 5000


class EvidenceError(ValueError):
    pass


def verify_grid_network(records, *, direction, valid, basin_cells, stream_cells,
                        geotransform, outlet, shape):
    """Verify all vector steps and full raster coverage before core analysis.

    Coordinates must be cell centers (numeric tolerance explicitly recorded).
    Only straight cardinal/diagonal runs may be expanded. Every expanded step
    must match D8, and raster stream cells inside the basin must equal the
    vector's covered cells. Basin cells must all drain to the chosen outlet.
    The returned cell edges preserve source IDs, without inventing links.
    """
    rows, cols = shape
    gt = geotransform
    if gt[2] != 0 or gt[4] != 0 or gt[1] <= 0 or gt[5] >= 0:
        raise EvidenceError('unsupported_grid')

    def center(cell):
        r, c = cell
        return [gt[0] + (c + .5) * gt[1], gt[3] + (r + .5) * gt[5]]

    def cell(point):
        c = (point[0] - gt[0]) / gt[1] - .5
        r = (point[1] - gt[3]) / gt[5] - .5
        if not math.isfinite(r) or not math.isfinite(c):
            raise EvidenceError('invalid_coordinates')
        rr, cc = round(r), round(c)
        if abs(rr-r) > CENTER_TOLERANCE_PIXELS or abs(cc-c) > CENTER_TOLERANCE_PIXELS:
            raise EvidenceError('vector_not_on_d8_cell_centers')
        if not (0 <= rr < rows and 0 <= cc < cols):
            raise EvidenceError('vector_outside_d8_grid')
        return rr, cc

    def next_cell(p):
        r, c = p
        if not valid[r][c]:
            raise EvidenceError('d8_nodata')
        value = float(direction[r][c])
        if value not in OFFSETS:
            raise EvidenceError('d8_invalid_or_region_exit')
        dr, dc = OFFSETS[int(value)]
        return r + dr, c + dc

    root = cell(outlet)
    if not basin_cells or root not in basin_cells:
        raise EvidenceError('outlet_outside_basin_mask')
    # Coverage evidence applies to the whole basin, not just sampled terminals.
    for r, c in sorted(basin_cells):
        if not valid[r][c]:
            raise EvidenceError('d8_nodata')
        for dr, dc in OFFSETS.values():
            rr, cc = r+dr, c+dc
            if not (0 <= rr < rows and 0 <= cc < cols) or not valid[rr][cc]:
                raise EvidenceError('basin_may_be_incomplete')
            if (rr, cc) not in basin_cells:
                value = float(direction[rr][cc])
                if value in OFFSETS:
                    er, ec = OFFSETS[int(value)]
                    if (rr+er, cc+ec) in basin_cells:
                        raise EvidenceError('basin_mask_omits_d8_contributor')
    reached = {root}
    for start in sorted(basin_cells):
        path, visited = [], set()
        current = start
        while current not in reached:
            if current in visited:
                raise EvidenceError('d8_cycle')
            if current not in basin_cells:
                raise EvidenceError('basin_d8_does_not_reach_outlet')
            visited.add(current)
            path.append(current)
            current = next_cell(current)
        reached.update(path)
    # Root is the sole exit; it cannot point back into its contributing basin.
    if next_cell(root) in basin_cells:
        raise EvidenceError('outlet_not_terminal_d8')

    selected = set(stream_cells) & basin_cells
    if not selected or root not in selected:
        raise EvidenceError('outlet_missing_from_stream_raster')
    edges, covered, provenance = {}, set(), {}
    ids = set()
    for record in records:
        source_id = record['id']
        if source_id in ids:
            raise EvidenceError('duplicate_source_id')
        ids.add(source_id)
        points = record['coordinates']
        for a, b in zip(points, points[1:]):
            start, end = cell(a), cell(b)
            dr, dc = end[0]-start[0], end[1]-start[1]
            steps = max(abs(dr), abs(dc))
            if steps == 0 or (dr and dc and abs(dr) != abs(dc)):
                raise EvidenceError('vector_segment_not_d8_aligned')
            sr, sc = (dr > 0)-(dr < 0), (dc > 0)-(dc < 0)
            for k in range(steps):
                p = start[0]+k*sr, start[1]+k*sc
                q = p[0]+sr, p[1]+sc
                if p in basin_cells:
                    covered.add(p)
                if q in basin_cells:
                    covered.add(q)
                if p not in basin_cells or q not in basin_cells:
                    continue
                forward, backward = next_cell(p) == q, next_cell(q) == p
                if forward == backward:
                    raise EvidenceError('vector_d8_direction_conflict')
                upstream, downstream = (p, q) if forward else (q, p)
                key = tuple(sorted((p, q)))
                if key in edges:
                    raise EvidenceError('duplicate_vector_step')
                edge_id = 'r%dc%d_r%dc%d' % (*upstream, *downstream)
                edges[key] = {'id': edge_id, 'coordinates': [center(upstream), center(downstream)]}
                provenance[edge_id] = source_id
                if len(edges) > MAX_NETWORK_EDGES:
                    raise EvidenceError('network_size_requires_review')
    if covered != selected:
        raise EvidenceError('vector_stream_raster_coverage_mismatch')
    if not edges:
        raise EvidenceError('empty_network')
    # Every selected cell except the outlet must have its actual downstream link.
    for p in selected - {root}:
        q = next_cell(p)
        if q not in selected or tuple(sorted((p, q))) not in edges:
            raise EvidenceError('stream_network_incomplete')
    return sorted(edges.values(), key=lambda x: x['id']), {
        'method': 'all_vector_steps_match_grass_d8_and_all_basin_cells_reach_outlet',
        'direction_encoding': 'GRASS_SFD_1_NE_8_E',
        'center_tolerance_pixels': CENTER_TOLERANCE_PIXELS,
        'snap_tolerance': 0, 'verified_basin_cells': len(reached),
        'outlet_coordinate': center(root), 'input_outlet_coordinate': list(outlet),
        'verified_stream_cells': len(selected), 'verified_network_edges': len(edges),
        'edge_source_feature_ids': provenance,
        'coverage_scope': 'entire_selected_stream_raster_within_basin_mask',
        'threshold': None, 'field_verification': False,
    }
