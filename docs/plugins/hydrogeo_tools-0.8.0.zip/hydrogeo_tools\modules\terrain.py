import os
import math
import uuid
from .hydrology_chain import (fresh, record_product, validate_direction,
    check_dem_parent, check_snap_inputs)

import processing

from qgis.core import QgsRuleBasedRenderer, QgsLineSymbol
from qgis.core import (
    QgsRuleBasedLabeling,
    QgsPalLayerSettings,
    QgsTextFormat,
    QgsTextBufferSettings,
    QgsLabelLineSettings,
    QgsUnitTypes
)
from qgis.PyQt.QtGui import QColor

from qgis.PyQt.QtGui import QColor
from qgis.core import QgsPalettedRasterRenderer
from qgis.core import (
    QgsSingleBandPseudoColorRenderer,
    QgsRasterShader,
    QgsColorRampShader
)

from qgis.core import (
    QgsProject,
    QgsRasterLayer,
    QgsRasterBandStats,
    QgsVectorLayer
)


class TerrainEngine:
    """Motor de produtos derivados do relevo."""

    def __init__(self, dem_layer):
        if dem_layer is None:
            raise ValueError("Nenhum MDT/MDE foi definido.")

        if not isinstance(dem_layer, QgsRasterLayer):
            raise TypeError("A camada de elevação precisa ser raster.")

        if not dem_layer.isValid():
            raise ValueError("O MDT/MDE selecionado não é válido.")

        self.dem = dem_layer

    def _ensure_parent(self, output_path):
        parent = os.path.dirname(output_path)

        if parent:
            os.makedirs(parent, exist_ok=True)

    def _add_raster(self, path, name):
        layer = QgsRasterLayer(path, name)

        if not layer.isValid():
            raise RuntimeError(
                f"O produto foi criado, mas não pôde ser "
                f"carregado no QGIS:\n{path}"
            )

        QgsProject.instance().addMapLayer(layer)
        return layer

    def _add_vector(self, path, name):
        layer = QgsVectorLayer(path, name, "ogr")

        if not layer.isValid():
            raise RuntimeError(
                f"O produto foi criado, mas não pôde ser "
                f"carregado no QGIS:\n{path}"
            )

        QgsProject.instance().addMapLayer(layer)
        return layer

    def contours(
        self,
        output_path,
        interval=1.0,
        field_name="ELEV"
    ):
        if interval <= 0:
            raise ValueError(
                "A equidistância das curvas deve ser maior que zero."
            )

        self._ensure_parent(output_path)

        params = {
            "INPUT": self.dem,
            "BAND": 1,
            "INTERVAL": float(interval),
            "FIELD_NAME": field_name,
            "CREATE_3D": False,
            "IGNORE_NODATA": False,
            "NODATA": None,
            "OFFSET": 0.0,
            "EXTRA": "",
            "OUTPUT": output_path
        }

        result = processing.run(
            "gdal:contour",
            params
        )

        return self._add_vector(
            result["OUTPUT"],
            f"Curvas de nível - {interval:g} m"
        )


    def cartographic_contours(
        self,
        input_contours,
        output_path,
        interval=1.0,
        threshold=5.0,
        iterations=1
    ):
        """
        Gera uma copia cartografica suavizada das curvas de nivel.

        A geometria tecnica original permanece inalterada.
        O metodo Chaiken e aplicado somente ao produto destinado
        a mapas, plantas e relatorios.
        """
        if input_contours is None:
            raise ValueError("Nenhuma camada de curvas de nivel foi definida.")

        if not isinstance(input_contours, QgsVectorLayer):
            raise TypeError("As curvas de nivel precisam ser uma camada vetorial.")

        if not input_contours.isValid():
            raise ValueError("A camada de curvas de nivel nao e valida.")

        if threshold <= 0:
            raise ValueError("O limiar de suavizacao deve ser maior que zero.")

        if iterations < 1:
            raise ValueError("O numero de iteracoes deve ser pelo menos 1.")

        self._ensure_parent(output_path)

        params = {
            "input": input_contours,
            "type": 0,
            "method": 8,
            "threshold": float(threshold),
            "look_ahead": 7,
            "reduction": 50,
            "slide": 0.5,
            "angle_thresh": 3,
            "degree_thresh": 0,
            "closeness_thresh": 0,
            "betweeness_thresh": 0,
            "alpha": 1,
            "beta": 1,
            "iterations": int(iterations),
            "-t": False,
            "-l": False,
            "output": output_path,
            "error": "TEMPORARY_OUTPUT"
        }

        result = processing.run(
            "grass:v.generalize",
            params
        )

        layer = self._add_vector(
            result["output"],
            "Curvas de nivel - cartograficas"
        )

        self._style_cartographic_contours(
            layer,
            interval=interval,
            field_name="ELEV"
        )

        return layer

    def _style_cartographic_contours(
        self,
        layer,
        interval=1.0,
        field_name="ELEV"
    ):
        """Aplica simbologia automatica as curvas cartograficas."""

        if interval <= 0:
            raise ValueError(
                "A equidistancia deve ser maior que zero."
            )

        master_interval = float(interval) * 5.0

        master_filter = (
            f'abs("{field_name}" / {master_interval:.12g} - '
            f'round("{field_name}" / {master_interval:.12g})) '
            '< 0.000001'
        )

        intermediate_filter = (
            f"NOT ({master_filter})"
        )

        root = QgsRuleBasedRenderer.Rule(None)

        master_symbol = QgsLineSymbol.createSimple({
            "line_color": "70,67,30",
            "line_width": "0.35",
            "line_width_unit": "MM",
            "capstyle": "round",
            "joinstyle": "round"
        })

        master_rule = QgsRuleBasedRenderer.Rule(
            master_symbol,
            0,
            0,
            master_filter,
            f"Curvas mestras - {master_interval:g} m"
        )

        intermediate_symbol = QgsLineSymbol.createSimple({
            "line_color": "150,105,55",
            "line_width": "0.16",
            "line_width_unit": "MM",
            "capstyle": "round",
            "joinstyle": "round"
        })

        intermediate_rule = QgsRuleBasedRenderer.Rule(
            intermediate_symbol,
            0,
            0,
            intermediate_filter,
            "Curvas intermediarias"
        )

        root.appendChild(master_rule)
        root.appendChild(intermediate_rule)

        layer.setRenderer(QgsRuleBasedRenderer(root))

        self._label_cartographic_contours(
            layer,
            master_interval=master_interval,
            field_name=field_name
        )

        layer.triggerRepaint()

    def _label_cartographic_contours(
        self,
        layer,
        master_interval,
        field_name="ELEV"
    ):
        """Rotula somente curvas mestras adequadas a apresentacao."""

        master_filter = (
            f'abs("{field_name}" / {master_interval:.12g} - '
            f'round("{field_name}" / {master_interval:.12g})) '
            '< 0.000001'
        )

        label_filter = (
            f"({master_filter}) AND $length >= 30"
        )

        settings = QgsPalLayerSettings()
        settings.fieldName = field_name
        settings.isExpression = False
        settings.placement = QgsPalLayerSettings.Line

        # Texto.
        text_format = QgsTextFormat()
        text_format.setFont(
            text_format.font()
        )
        text_format.setSize(9)

        # Halo branco para manter a cota legivel sobre o mapa.
        buffer = QgsTextBufferSettings()
        buffer.setEnabled(True)
        buffer.setSize(0.7)
        buffer.setColor(QColor("white"))

        text_format.setBuffer(buffer)
        text_format.setColor(QColor(70, 67, 30))
        settings.setFormat(text_format)

        # Rotulo diretamente sobre a linha.
        line_settings = QgsLabelLineSettings()
        line_settings.setPlacementFlags(
            type(line_settings.placementFlags()).OnLine
        )
        settings.setLineSettings(line_settings)

        # Repete a cota em linhas longas sem saturar o mapa.
        settings.repeatDistance = 200.0
        settings.repeatDistanceUnit = (
            QgsUnitTypes.RenderUnit.MapUnits
        )

        rule = QgsRuleBasedLabeling.Rule(settings)
        rule.setFilterExpression(label_filter)
        rule.setDescription("Cotas das curvas mestras")

        root_rule = QgsRuleBasedLabeling.Rule(None)
        root_rule.appendChild(rule)

        layer.setLabeling(
            QgsRuleBasedLabeling(root_rule)
        )
        layer.setLabelsEnabled(True)

    def prepare_hydrologic_dem(
        self,
        output_path,
        min_slope=0.0
    ):
        """
        Gera um MDT derivado preparado para analise hidrologica.

        O raster original nunca e sobrescrito.
        O preenchimento de depressões utiliza Wang & Liu.
        NoData nao e interpolado automaticamente.
        """

        if min_slope < 0:
            raise ValueError(
                "A declividade minima nao pode ser negativa."
            )

        source_path = self.dem.source()

        if (
            os.path.abspath(source_path)
            == os.path.abspath(output_path)
        ):
            raise ValueError(
                "O MDT preparado deve ser salvo em arquivo diferente "
                "do MDT original."
            )

        fresh(output_path)
        self._ensure_parent(output_path)

        params = {
            "INPUT": self.dem,
            "BAND": 1,
            "MIN_SLOPE": float(min_slope),
            "CREATION_OPTIONS": "",
            "OUTPUT_FILLED_DEM": output_path,
            "OUTPUT_FLOW_DIRECTIONS": "TEMPORARY_OUTPUT",
            "OUTPUT_WATERSHED_BASINS": "TEMPORARY_OUTPUT"
        }

        result = processing.run(
            "native:fillsinkswangliu",
            params
        )

        layer = self._add_raster(
            result["OUTPUT_FILLED_DEM"],
            "MDT preparado - hidrologia"
        )

        record_product(layer.source(), "prepared_dem", "native:fillsinkswangliu",
                       {"source": source_path}, {"min_slope": min_slope})
        return layer



    def _style_flow_direction_d8(self, layer):
        """
        Simbologia categorica para direcao de fluxo GRASS D8.

        Valores positivos representam direcoes internas.
        Valores negativos preservam a direcao indicada pelo valor
        absoluto, mas sao identificados separadamente como saida
        da area analisada.

        O raster original nao e modificado.
        """

        if layer is None or not layer.isValid():
            return

        classes = [
            QgsPalettedRasterRenderer.Class(
                -8, QColor(120, 120, 120),
                "Saida da area - Leste (E)"
            ),
            QgsPalettedRasterRenderer.Class(
                -7, QColor(120, 120, 120),
                "Saida da area - Sudeste (SE)"
            ),
            QgsPalettedRasterRenderer.Class(
                -6, QColor(120, 120, 120),
                "Saida da area - Sul (S)"
            ),
            QgsPalettedRasterRenderer.Class(
                -5, QColor(120, 120, 120),
                "Saida da area - Sudoeste (SW)"
            ),
            QgsPalettedRasterRenderer.Class(
                -4, QColor(120, 120, 120),
                "Saida da area - Oeste (W)"
            ),
            QgsPalettedRasterRenderer.Class(
                -3, QColor(120, 120, 120),
                "Saida da area - Noroeste (NW)"
            ),
            QgsPalettedRasterRenderer.Class(
                -2, QColor(120, 120, 120),
                "Saida da area - Norte (N)"
            ),
            QgsPalettedRasterRenderer.Class(
                -1, QColor(120, 120, 120),
                "Saida da area - Nordeste (NE)"
            ),

            QgsPalettedRasterRenderer.Class(
                1, QColor(255, 193, 7),
                "Nordeste (NE)"
            ),
            QgsPalettedRasterRenderer.Class(
                2, QColor(76, 175, 80),
                "Norte (N)"
            ),
            QgsPalettedRasterRenderer.Class(
                3, QColor(0, 150, 136),
                "Noroeste (NW)"
            ),
            QgsPalettedRasterRenderer.Class(
                4, QColor(33, 150, 243),
                "Oeste (W)"
            ),
            QgsPalettedRasterRenderer.Class(
                5, QColor(63, 81, 181),
                "Sudoeste (SW)"
            ),
            QgsPalettedRasterRenderer.Class(
                6, QColor(156, 39, 176),
                "Sul (S)"
            ),
            QgsPalettedRasterRenderer.Class(
                7, QColor(233, 30, 99),
                "Sudeste (SE)"
            ),
            QgsPalettedRasterRenderer.Class(
                8, QColor(244, 67, 54),
                "Leste (E)"
            )
        ]

        renderer = QgsPalettedRasterRenderer(
            layer.dataProvider(),
            1,
            classes
        )

        layer.setRenderer(renderer)
        layer.triggerRepaint()



    def _style_flow_accumulation_d8(
        self,
        layer,
        minimum,
        positive_stats
    ):
        """
        Aplica simbologia hidrologica dinamica a acumulacao D8.

        O GeoTIFF nao e alterado.

        Valores negativos permanecem no raster e na legenda,
        mas sao representados de forma muito discreta.

        As maiores acumulacoes recebem progressivamente maior
        destaque visual.
        """

        if layer is None or not layer.isValid():
            return

        provider = layer.dataProvider()

        p50 = positive_stats.get("p50")
        p75 = positive_stats.get("p75")
        p90 = positive_stats.get("p90")
        p95 = positive_stats.get("p95")
        p99 = positive_stats.get("p99")
        p995 = positive_stats.get("p995")
        p999 = positive_stats.get("p999")
        maximum = positive_stats.get("max")

        required = [
            p50, p75, p90, p95,
            p99, p995, p999, maximum
        ]

        if any(value is None for value in required):
            return

        shader_function = QgsColorRampShader()
        shader_function.setColorRampType(
            QgsColorRampShader.Discrete
        )

        items = []

        if minimum is not None and minimum < 0:
            items.append(
                QgsColorRampShader.ColorRampItem(
                    0.0,
                    QColor(110, 110, 110, 18),
                    "Negativo - sinal GRASS preservado"
                )
            )

        items.extend([
            QgsColorRampShader.ColorRampItem(
                p50,
                QColor(255, 255, 255, 0),
                f"Baixa - ate P50 ({p50:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                p75,
                QColor(224, 247, 250, 18),
                f"P50-P75 (ate {p75:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                p90,
                QColor(178, 235, 242, 30),
                f"P75-P90 (ate {p90:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                p95,
                QColor(128, 222, 234, 65),
                f"P90-P95 (ate {p95:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                p99,
                QColor(38, 198, 218, 115),
                f"P95-P99 (ate {p99:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                p995,
                QColor(3, 169, 244, 165),
                f"P99-P99,5 (ate {p995:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                p999,
                QColor(30, 136, 229, 215),
                f"P99,5-P99,9 (ate {p999:,.0f})"
            ),
            QgsColorRampShader.ColorRampItem(
                maximum,
                QColor(13, 71, 161, 255),
                "Muito alta - acima de P99,9"
            )
        ])

        shader_function.setColorRampItemList(items)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(
            shader_function
        )

        renderer = QgsSingleBandPseudoColorRenderer(
            provider,
            1,
            raster_shader
        )

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def flow_accumulation_d8(self, output_path):
        """
        Calcula acumulacao de fluxo D8/SFD com GRASS r.watershed.

        O sinal produzido pelo GRASS e preservado.
        Valores negativos nao sao convertidos automaticamente,
        pois carregam informacao do proprio modelo hidrologico.

        O MDT de entrada nunca e sobrescrito.
        """

        source_path = self.dem.source()

        if not source_path:
            raise ValueError(
                "O MDT ativo nao possui uma origem valida."
            )

        if os.path.abspath(source_path) == os.path.abspath(output_path):
            raise ValueError(
                "A acumulacao de fluxo deve ser salva em arquivo "
                "diferente do MDT de entrada."
            )

        fresh(output_path)
        self._ensure_parent(output_path)

        params = {
            "elevation": self.dem,
            "convergence": 5,
            "memory": 300,
            "-s": True,
            "-m": False,
            "-4": False,
            "-a": False,
            "-b": True,
            "accumulation": output_path,
            "drainage": "TEMPORARY_OUTPUT",
            "GRASS_REGION_PARAMETER": self.dem.extent(),
            "GRASS_REGION_CELLSIZE_PARAMETER": 0,
            "GRASS_RASTER_FORMAT_OPT": "",
            "GRASS_RASTER_FORMAT_META": ""
        }

        result = processing.run(
            "grass:r.watershed",
            params
        )

        accumulation_path = result.get("accumulation")

        if not accumulation_path:
            accumulation_path = output_path

        if not os.path.exists(accumulation_path):
            raise RuntimeError(
                "O GRASS r.watershed terminou, mas o arquivo de "
                "acumulacao de fluxo nao foi encontrado:\n"
                + str(accumulation_path)
            )

        layer = self._add_raster(
            accumulation_path,
            "Acumulacao de fluxo - D8"
        )

        record_product(layer.source(), "accumulation", "grass:r.watershed",
                       {"dem": source_path}, {"sfd": True, "signed": True, "convergence": 5})
        provider = layer.dataProvider()
        width = layer.width()
        height = layer.height()

        block = provider.block(
            1,
            layer.extent(),
            width,
            height
        )

        valid_cells = 0
        positive_cells = 0
        negative_cells = 0
        zero_cells = 0

        positive_values = []

        minimum = None
        maximum = None

        for row in range(height):
            for col in range(width):

                if block.isNoData(row, col):
                    continue

                value = float(block.value(row, col))

                if not math.isfinite(value):
                    continue

                valid_cells += 1

                if minimum is None or value < minimum:
                    minimum = value

                if maximum is None or value > maximum:
                    maximum = value

                if value > 0:
                    positive_cells += 1
                    positive_values.append(value)

                elif value < 0:
                    negative_cells += 1

                else:
                    zero_cells += 1

        def percentile(values, percentile_value):
            if not values:
                return None

            ordered = sorted(values)

            if len(ordered) == 1:
                return ordered[0]

            position = (
                (len(ordered) - 1)
                * float(percentile_value)
                / 100.0
            )

            lower = int(math.floor(position))
            upper = int(math.ceil(position))

            if lower == upper:
                return ordered[lower]

            fraction = position - lower

            return (
                ordered[lower] * (1.0 - fraction)
                + ordered[upper] * fraction
            )

        positive_stats = {
            "p50": percentile(positive_values, 50),
            "p75": percentile(positive_values, 75),
            "p90": percentile(positive_values, 90),
            "p95": percentile(positive_values, 95),
            "p99": percentile(positive_values, 99),
            "p995": percentile(positive_values, 99.5),
            "p999": percentile(positive_values, 99.9),
            "max": max(positive_values) if positive_values else None
        }

        self._style_flow_accumulation_d8(
            layer,
            minimum,
            positive_stats
        )

        return {
            "layer": layer,
            "minimum": minimum,
            "maximum": maximum,
            "valid_cells": valid_cells,
            "positive_cells": positive_cells,
            "negative_cells": negative_cells,
            "zero_cells": zero_cells,
            "positive_stats": positive_stats
        }

    def _absolute_flow_accumulation(
        self,
        accumulation_layer,
        output_path
    ):
        """
        Cria uma copia auxiliar da acumulacao de fluxo usando
        o valor absoluto das celulas.

        A acumulacao D8 oficial permanece inalterada, inclusive
        quanto ao sinal original produzido pelo GRASS.
        """

        if accumulation_layer is None:
            raise ValueError(
                "Nenhuma camada de acumulacao de fluxo foi informada."
            )

        if not isinstance(accumulation_layer, QgsRasterLayer):
            raise TypeError(
                "A acumulacao de fluxo precisa ser uma camada raster."
            )

        if not accumulation_layer.isValid():
            raise ValueError(
                "A camada de acumulacao de fluxo nao e valida."
            )

        if not output_path:
            raise ValueError(
                "Nenhum caminho foi definido para a acumulacao auxiliar."
            )

        source_path = accumulation_layer.source()

        if source_path and (
            os.path.normcase(os.path.realpath(source_path))
            == os.path.normcase(os.path.realpath(output_path))
        ):
            raise ValueError(
                "A acumulacao auxiliar deve ser salva em arquivo "
                "diferente da acumulacao D8 original."
            )

        self._ensure_parent(output_path)

        provider = accumulation_layer.dataProvider()
        valid_expression = "isfinite(A)"
        if provider.sourceHasNoDataValue(1):
            nodata = provider.sourceNoDataValue(1)
            if math.isfinite(nodata):
                valid_expression += " & (A != " + repr(nodata) + ")"
        # Explicit mask avoids NaN propagation in gdal_calc's NoData arithmetic.
        params = {
            "INPUT_A": accumulation_layer,
            "BAND_A": 1,
            "INPUT_B": None,
            "BAND_B": 1,
            "INPUT_C": None,
            "BAND_C": 1,
            "INPUT_D": None,
            "BAND_D": 1,
            "INPUT_E": None,
            "BAND_E": 1,
            "INPUT_F": None,
            "BAND_F": 1,
            "FORMULA": "where(" + valid_expression + ", abs(A), -9999.0)",
            "NO_DATA": -9999.0,
            "EXTENT_OPT": 0,
            "PROJWIN": None,
            "RTYPE": 5,
            "OPTIONS": "",
            "EXTRA": "--hideNoData",
            "OUTPUT": output_path
        }

        result = processing.run(
            "gdal:rastercalculator",
            params
        )

        result_path = result.get("OUTPUT")

        if not result_path:
            result_path = output_path

        if not os.path.exists(result_path):
            raise RuntimeError(
                "A acumulacao auxiliar foi processada, mas o arquivo "
                "de saida nao foi encontrado:\n"
                + str(result_path)
            )

        layer = QgsRasterLayer(
            result_path,
            "Acumulacao auxiliar - magnitude"
        )

        if not layer.isValid():
            raise RuntimeError(
                "A acumulacao auxiliar foi criada, mas nao pode ser "
                "carregada como raster:\n"
                + str(result_path)
            )

        return layer

    @staticmethod
    def _same_stream_grid(left, right):
        # GRASS export rounds map coordinates; tolerate only a millionth of a pixel.
        tolerance = min(abs(left.rasterUnitsPerPixelX()), abs(left.rasterUnitsPerPixelY())) * 1e-6
        a, b = left.extent(), right.extent()
        return (left.width() == right.width() and left.height() == right.height()
                and all(math.isclose(x, y, rel_tol=0, abs_tol=tolerance)
                        for x, y in zip(
                            (a.xMinimum(), a.yMinimum(), a.xMaximum(), a.yMaximum()),
                            (b.xMinimum(), b.yMinimum(), b.xMaximum(), b.yMaximum()))))

    def stream_network_d8(
        self,
        accumulation_layer,
        stream_vector_path,
        stream_raster_path,
        minimum_contributing_area_m2
    ):
        """
        Extrai uma rede de drenagem modelada usando GRASS
        r.stream.extract.

        O limiar e informado como area contribuinte minima em m2.
        Internamente ele e convertido para numero de celulas de
        acordo com a resolucao real do raster de acumulacao.

        A acumulacao D8 original permanece inalterada.
        """

        import tempfile
        import shutil

        if accumulation_layer is None:
            raise ValueError(
                "Nenhuma camada de acumulacao de fluxo foi informada."
            )

        if not isinstance(accumulation_layer, QgsRasterLayer):
            raise TypeError(
                "A acumulacao de fluxo precisa ser uma camada raster."
            )

        if not accumulation_layer.isValid():
            raise ValueError(
                "A camada de acumulacao de fluxo nao e valida."
            )

        minimum_contributing_area_m2 = float(
            minimum_contributing_area_m2
        )

        if not math.isfinite(minimum_contributing_area_m2) or minimum_contributing_area_m2 <= 0:
            raise ValueError(
                "A area contribuinte minima deve ser maior que zero."
            )

        if not stream_vector_path:
            raise ValueError(
                "Nenhum caminho foi definido para a rede vetorial."
            )

        if not stream_raster_path:
            raise ValueError(
                "Nenhum caminho foi definido para a rede raster."
            )

        if accumulation_layer.crs() != self.dem.crs():
            raise ValueError(
                "O MDT e a acumulacao de fluxo precisam usar "
                "o mesmo SRC."
            )

        if (
            not self._same_stream_grid(accumulation_layer, self.dem)
        ):
            raise ValueError(
                "O MDT e a acumulacao de fluxo precisam possuir "
                "a mesma grade raster."
            )

        pixel_width = abs(
            accumulation_layer.rasterUnitsPerPixelX()
        )

        pixel_height = abs(
            accumulation_layer.rasterUnitsPerPixelY()
        )

        pixel_area_m2 = pixel_width * pixel_height

        if pixel_area_m2 <= 0:
            raise ValueError(
                "Nao foi possivel determinar a area do pixel."
            )

        if (
            accumulation_layer.crs().mapUnits()
            != QgsUnitTypes.DistanceMeters
        ):
            raise ValueError(
                "A area contribuinte em m2 exige um raster em "
                "SRC projetado com unidades em metros."
            )

        threshold_cells = int(
            math.ceil(
                minimum_contributing_area_m2
                / pixel_area_m2
            )
        )

        threshold_cells = max(
            threshold_cells,
            1
        )

        effective_area_m2 = (
            threshold_cells * pixel_area_m2
        )

        self._ensure_parent(stream_vector_path)
        self._ensure_parent(stream_raster_path)

        dem_source = self.dem.source()
        accumulation_source = accumulation_layer.source()

        protected_paths = [
            path_value
            for path_value in [
                dem_source,
                accumulation_source
            ]
            if path_value
        ]

        for output_path in [
            stream_vector_path,
            stream_raster_path
        ]:
            for protected_path in protected_paths:
                if (
                    os.path.normcase(os.path.realpath(output_path))
                    == os.path.normcase(os.path.realpath(protected_path))
                ):
                    raise ValueError(
                        "Os produtos da rede de drenagem devem ser "
                        "salvos em arquivos diferentes dos rasters "
                        "de entrada."
                    )

        if os.path.normcase(os.path.realpath(stream_vector_path)) == os.path.normcase(os.path.realpath(stream_raster_path)):
            raise ValueError("As saidas raster e vetorial devem usar arquivos diferentes.")
        for path in (stream_vector_path, stream_raster_path):
            if os.path.exists(path):
                raise ValueError("Escolha um arquivo de saida novo: " + str(path))

        check_dem_parent(accumulation_source, dem_source)
        from .hydrology_chain import read_record
        acc_record = read_record(accumulation_source)
        if acc_record and acc_record['role'] != 'accumulation':
            raise ValueError('Selecione um raster de acumulação.')
        direction_path = os.path.splitext(stream_raster_path)[0] + '_direcao_extracao.tif'
        fresh(stream_vector_path, stream_raster_path, direction_path)
        temp_dir = tempfile.mkdtemp(
            prefix="hydrogeo_stream_"
        )

        temp_accumulation = os.path.join(
            temp_dir,
            "accumulation_abs.tif"
        )

        try:
            absolute_accumulation = (
                self._absolute_flow_accumulation(
                    accumulation_layer,
                    temp_accumulation
                )
            )

            params = {
                "elevation": self.dem,
                "accumulation": absolute_accumulation,
                "depression": None,
                "threshold": float(threshold_cells),
                "mexp": 0.0,
                "stream_length": 0,
                "d8cut": None,
                "memory": 300,
                "stream_raster": stream_raster_path,
                "stream_vector": stream_vector_path,
                "direction": direction_path,
                "GRASS_REGION_PARAMETER": self.dem.extent(),
                "GRASS_REGION_CELLSIZE_PARAMETER": 0,
                "GRASS_RASTER_FORMAT_OPT": "",
                "GRASS_RASTER_FORMAT_META": "",
                "GRASS_OUTPUT_TYPE_PARAMETER": 2,
                "GRASS_VECTOR_DSCO": "",
                "GRASS_VECTOR_LCO": "",
                "GRASS_VECTOR_EXPORT_NOCAT": False
            }

            result = processing.run(
                "grass:r.stream.extract",
                params
            )

            vector_path = result.get(
                "stream_vector"
            )

            if not vector_path:
                vector_path = stream_vector_path

            raster_path = result.get(
                "stream_raster"
            )

            if not raster_path:
                raster_path = stream_raster_path

            if not os.path.exists(vector_path):
                raise RuntimeError(
                    "O GRASS r.stream.extract terminou, mas "
                    "a rede vetorial nao foi encontrada:\n"
                    + str(vector_path)
                )

            if not os.path.exists(raster_path):
                raise RuntimeError(
                    "O GRASS r.stream.extract terminou, mas "
                    "a rede raster nao foi encontrada:\n"
                    + str(raster_path)
                )

            raster_layer = QgsRasterLayer(raster_path, "Rede de drenagem modelada - raster")
            if not raster_layer.isValid():
                raise RuntimeError("A rede raster criada nao e valida.")
            if (raster_layer.crs() != self.dem.crs()
                    or not self._same_stream_grid(raster_layer, self.dem)):
                raise RuntimeError("A rede raster nao corresponde a grade do MDT.")
            vector_layer = QgsVectorLayer(vector_path, "Rede de drenagem modelada", "ogr")
            if not vector_layer.isValid() or vector_layer.crs() != self.dem.crs():
                raise RuntimeError("A rede vetorial nao e valida ou possui SRC diferente do MDT.")

            feature_count = vector_layer.featureCount()

            total_length_m = 0.0

            for feature in vector_layer.getFeatures():
                geometry = feature.geometry()

                if geometry is None:
                    continue

                if geometry.isEmpty():
                    continue

                total_length_m += geometry.length()

            if feature_count <= 0 or total_length_m <= 0:
                raise RuntimeError("Nenhum trecho de drenagem foi extraido. Revise o limiar e os dados.")
            validate_direction(direction_path)
            run_id = uuid.uuid4().hex
            inputs = {'dem': dem_source, 'accumulation': accumulation_source}
            provenance_parameters = {'threshold_cells': threshold_cells, 'mexp': 0.0,
                'stream_length': 0, 'd8cut': None, 'accumulation_transform': 'absolute',
                'accumulation_role': 'extraction_input_and_snap_heuristic_not_direction_proof',
                'direction_policy': 'use_extract_direction_and_redelimit_basin'}
            for path, role in [(vector_path,'stream_vector'), (raster_path,'stream_raster'),
                               (direction_path,'direction')]:
                record_product(path, role, 'grass:r.stream.extract', inputs,
                               provenance_parameters, run_id)
            self._add_raster(direction_path, 'Direção D8 — par da rede extraída')
            QgsProject.instance().addMapLayer(vector_layer)
            return {
                "layer": vector_layer,
                "stream_vector_path": vector_path,
                "direction_path": direction_path,
                "stream_raster_path": raster_path,
                "pixel_area_m2": pixel_area_m2,
                "threshold_cells": threshold_cells,
                "requested_area_m2": (
                    minimum_contributing_area_m2
                ),
                "requested_area_ha": (
                    minimum_contributing_area_m2
                    / 10000.0
                ),
                "effective_area_m2": effective_area_m2,
                "effective_area_ha": (
                    effective_area_m2 / 10000.0
                ),
                "feature_count": feature_count,
                "total_length_m": total_length_m
            }

        finally:
            shutil.rmtree(
                temp_dir,
                ignore_errors=True
            )

    def snap_outlet_to_accumulation(
        self,
        accumulation_layer,
        outlet_x,
        outlet_y,
        search_radius_m=10.0
    ):
        """
        Ajusta um ponto de exutorio para a celula de maior
        magnitude de acumulacao dentro de um raio de busca.

        O raster oficial de acumulacao nao e modificado.
        """

        if accumulation_layer is None:
            raise ValueError(
                "A camada de acumulacao nao foi informada."
            )

        if not isinstance(
            accumulation_layer,
            QgsRasterLayer
        ):
            raise TypeError(
                "A acumulacao deve ser uma camada raster valida."
            )

        if not accumulation_layer.isValid():
            raise ValueError(
                "A camada de acumulacao nao e valida."
            )

        if accumulation_layer.crs() != self.dem.crs():
            raise ValueError(
                "A acumulacao deve usar o mesmo SRC do MDT."
            )

        if not self._same_stream_grid(
            accumulation_layer,
            self.dem
        ):
            raise ValueError(
                "A acumulacao deve usar a mesma grade do MDT."
            )

        outlet_x = float(outlet_x)
        outlet_y = float(outlet_y)
        search_radius_m = float(search_radius_m)

        if search_radius_m <= 0:
            raise ValueError(
                "O raio de busca deve ser maior que zero."
            )

        if not self.dem.extent().contains(
            outlet_x,
            outlet_y
        ):
            raise ValueError(
                "O exutorio informado esta fora da extensao do MDT."
            )

        pixel_x = abs(
            accumulation_layer.rasterUnitsPerPixelX()
        )

        pixel_y = abs(
            accumulation_layer.rasterUnitsPerPixelY()
        )

        extent = accumulation_layer.extent()

        center_col = int(
            (outlet_x - extent.xMinimum())
            / pixel_x
        )

        center_row = int(
            (extent.yMaximum() - outlet_y)
            / pixel_y
        )

        radius_cols = int(
            math.ceil(
                search_radius_m / pixel_x
            )
        )

        radius_rows = int(
            math.ceil(
                search_radius_m / pixel_y
            )
        )

        provider = accumulation_layer.dataProvider()

        block = provider.block(
            1,
            extent,
            accumulation_layer.width(),
            accumulation_layer.height()
        )

        best = None

        for row in range(
            max(
                0,
                center_row - radius_rows
            ),
            min(
                accumulation_layer.height(),
                center_row + radius_rows + 1
            )
        ):
            for col in range(
                max(
                    0,
                    center_col - radius_cols
                ),
                min(
                    accumulation_layer.width(),
                    center_col + radius_cols + 1
                )
            ):

                if block.isNoData(
                    row,
                    col
                ):
                    continue

                value = float(
                    block.value(
                        row,
                        col
                    )
                )

                if not math.isfinite(value):
                    continue

                magnitude = abs(value)

                x = (
                    extent.xMinimum()
                    + (col + 0.5) * pixel_x
                )

                y = (
                    extent.yMaximum()
                    - (row + 0.5) * pixel_y
                )

                distance_m = math.hypot(
                    x - outlet_x,
                    y - outlet_y
                )

                if distance_m > search_radius_m:
                    continue

                if (
                    best is None
                    or magnitude > best["magnitude"]
                ):
                    best = {
                        "row": row,
                        "col": col,
                        "value": value,
                        "magnitude": magnitude,
                        "x": x,
                        "y": y,
                        "distance_m": distance_m
                    }

        if best is None:
            raise RuntimeError(
                "Nenhuma celula valida de acumulacao foi encontrada "
                "dentro do raio de busca."
            )

        return {
            "original_x": outlet_x,
            "original_y": outlet_y,
            "snapped_x": best["x"],
            "snapped_y": best["y"],
            "distance_m": best["distance_m"],
            "accumulation_value": best["value"],
            "accumulation_magnitude": best["magnitude"],
            "row": best["row"],
            "col": best["col"],
            "search_radius_m": search_radius_m
        }


    def delimit_watershed_d8(
        self,
        accumulation_layer,
        direction_layer,
        outlet_x,
        outlet_y,
        basin_raster_path,
        basin_vector_path,
        search_radius_m=10.0
    ):
        """
        Delimita uma microbacia modelada a partir de um ponto
        informado pelo usuario.

        Fluxo:
        1. preserva o ponto original;
        2. ajusta o exutorio para a maior magnitude de acumulacao
           dentro do raio de busca;
        3. delimita a microbacia com a direcao D8;
        4. retorna os diagnosticos do snap e da microbacia.

        Os rasters oficiais de acumulacao e direcao nao sao
        modificados.
        """

        check_snap_inputs(direction_layer.source(), accumulation_layer.source(), self.dem.source())
        snap = self.snap_outlet_to_accumulation(
            accumulation_layer,
            outlet_x,
            outlet_y,
            search_radius_m
        )

        watershed = self.watershed_from_outlet_d8(
            direction_layer,
            snap["snapped_x"],
            snap["snapped_y"],
            basin_raster_path,
            basin_vector_path
        )

        result = dict(watershed)

        result.update(
            {
                "original_outlet_x": snap["original_x"],
                "original_outlet_y": snap["original_y"],
                "snapped_outlet_x": snap["snapped_x"],
                "snapped_outlet_y": snap["snapped_y"],
                "snap_distance_m": snap["distance_m"],
                "snap_search_radius_m": snap["search_radius_m"],
                "snap_accumulation_value": snap[
                    "accumulation_value"
                ],
                "snap_accumulation_magnitude": snap[
                    "accumulation_magnitude"
                ],
                "snap_row": snap["row"],
                "snap_col": snap["col"]
            }
        )

        return result


    def watershed_from_outlet_d8(
        self,
        direction_layer,
        outlet_x,
        outlet_y,
        basin_raster_path,
        basin_vector_path
    ):
        """
        Delimita uma microbacia modelada a partir de um raster
        de direcao de fluxo D8 e de um ponto de exutorio.

        O raster de direcao e tratado apenas como entrada.
        Os dados originais nunca sao sobrescritos.
        """

        if direction_layer is None:
            raise ValueError(
                "Nenhuma camada de direcao de fluxo foi informada."
            )

        if not isinstance(direction_layer, QgsRasterLayer):
            raise TypeError(
                "A direcao de fluxo precisa ser uma camada raster."
            )

        if not direction_layer.isValid():
            raise ValueError(
                "A camada de direcao de fluxo nao e valida."
            )

        if direction_layer.crs() != self.dem.crs():
            raise ValueError(
                "O MDT e a direcao de fluxo precisam usar o mesmo SRC."
            )

        if (
            direction_layer.width() != self.dem.width()
            or direction_layer.height() != self.dem.height()
        ):
            raise ValueError(
                "O MDT e a direcao de fluxo precisam possuir "
                "a mesma grade raster."
            )

        if not self._same_stream_grid(direction_layer, self.dem):
            raise ValueError('Direção e MDT devem ter mesma extensão e resolução.')
        direction_audit = validate_direction(direction_layer.source())
        check_dem_parent(direction_layer.source(), self.dem.source())
        fresh(basin_raster_path, basin_vector_path)
        outlet_x = float(outlet_x)
        outlet_y = float(outlet_y)

        if not self.dem.extent().contains(
            outlet_x,
            outlet_y
        ):
            raise ValueError(
                "O ponto de exutorio esta fora da extensao do MDT."
            )

        if not basin_raster_path:
            raise ValueError(
                "Nenhum caminho foi definido para o raster da microbacia."
            )

        if not basin_vector_path:
            raise ValueError(
                "Nenhum caminho foi definido para o poligono da microbacia."
            )

        self._ensure_parent(basin_raster_path)
        self._ensure_parent(basin_vector_path)

        protected_paths = [
            self.dem.source(),
            direction_layer.source()
        ]

        for output_path in [
            basin_raster_path,
            basin_vector_path
        ]:
            for protected_path in protected_paths:
                if not protected_path:
                    continue

                if (
                    os.path.normcase(os.path.realpath(output_path))
                    == os.path.normcase(os.path.realpath(protected_path))
                ):
                    raise ValueError(
                        "As saidas da microbacia devem ser salvas em "
                        "arquivos diferentes dos rasters de entrada."
                    )

        if (
            os.path.normcase(os.path.realpath(basin_raster_path))
            == os.path.normcase(os.path.realpath(basin_vector_path))
        ):
            raise ValueError(
                "As saidas raster e vetorial devem usar arquivos diferentes."
            )

        for output_path in [
            basin_raster_path,
            basin_vector_path
        ]:
            if os.path.exists(output_path):
                raise ValueError(
                    "Escolha um arquivo de saida novo: "
                    + str(output_path)
                )

        outlet_coordinates = (
            f"{outlet_x:.12f},{outlet_y:.12f}"
        )

        basin_result = processing.run(
            "grass:r.water.outlet",
            {
                "input": direction_layer,
                "coordinates": outlet_coordinates,
                "output": basin_raster_path,
                "GRASS_REGION_PARAMETER": direction_layer.extent(),
                "GRASS_REGION_CELLSIZE_PARAMETER": 0,
                "GRASS_RASTER_FORMAT_OPT": "",
                "GRASS_RASTER_FORMAT_META": ""
            }
        )

        raster_path = basin_result.get("output")

        if not raster_path:
            raster_path = basin_raster_path

        if not os.path.exists(raster_path):
            raise RuntimeError(
                "O GRASS r.water.outlet terminou, mas o raster da "
                "microbacia nao foi encontrado:\n"
                + str(raster_path)
            )

        raster_layer = QgsRasterLayer(
            raster_path,
            "Microbacia modelada - raster"
        )

        if not raster_layer.isValid():
            raise RuntimeError(
                "O raster da microbacia foi criado, mas nao e valido."
            )

        if (
            raster_layer.crs() != self.dem.crs()
            or not self._same_stream_grid(
                raster_layer,
                self.dem
            )
        ):
            raise RuntimeError(
                "O raster da microbacia nao corresponde "
                "a grade do MDT."
            )

        basin_provider = raster_layer.dataProvider()
        dem_provider = self.dem.dataProvider()

        width = raster_layer.width()
        height = raster_layer.height()

        basin_block = basin_provider.block(
            1,
            raster_layer.extent(),
            width,
            height
        )

        dem_block = dem_provider.block(
            1,
            self.dem.extent(),
            self.dem.width(),
            self.dem.height()
        )

        basin_cells = 0
        touches_dem_boundary = False

        for row in range(height):
            for col in range(width):

                if basin_block.isNoData(row, col):
                    continue

                value = float(
                    basin_block.value(row, col)
                )

                if not math.isfinite(value):
                    continue

                if value <= 0:
                    continue

                basin_cells += 1

                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):

                        if dr == 0 and dc == 0:
                            continue

                        neighbor_row = row + dr
                        neighbor_col = col + dc

                        if (
                            neighbor_row < 0
                            or neighbor_col < 0
                            or neighbor_row >= height
                            or neighbor_col >= width
                        ):
                            touches_dem_boundary = True
                            continue

                        if dem_block.isNoData(
                            neighbor_row,
                            neighbor_col
                        ):
                            touches_dem_boundary = True

        pixel_area_m2 = (
            abs(raster_layer.rasterUnitsPerPixelX())
            * abs(raster_layer.rasterUnitsPerPixelY())
        )

        raster_area_m2 = (
            basin_cells * pixel_area_m2
        )

        boundary_warning = ""

        if touches_dem_boundary:
            boundary_warning = (
                "A microbacia modelada intercepta o limite "
                "valido do MDT. A area contribuinte pode estar "
                "incompleta."
            )

        polygon_result = processing.run(
            "gdal:polygonize",
            {
                "INPUT": raster_layer,
                "BAND": 1,
                "FIELD": "DN",
                "EIGHT_CONNECTEDNESS": True,
                "EXTRA": "",
                "OUTPUT": basin_vector_path
            }
        )

        vector_path = polygon_result.get("OUTPUT")

        if not vector_path:
            vector_path = basin_vector_path

        if not os.path.exists(vector_path):
            raise RuntimeError(
                "A vetorizacao terminou, mas o arquivo da microbacia "
                "nao foi encontrado:\n"
                + str(vector_path)
            )

        vector_layer = QgsVectorLayer(
            vector_path,
            "Microbacia modelada",
            "ogr"
        )

        if not vector_layer.isValid():
            raise RuntimeError(
                "O poligono da microbacia foi criado, mas nao e valido."
            )

        feature_count = vector_layer.featureCount()

        total_area_m2 = 0.0
        total_perimeter_m = 0.0

        for feature in vector_layer.getFeatures():
            geometry = feature.geometry()

            if geometry is None:
                continue

            if geometry.isEmpty():
                continue

            total_area_m2 += geometry.area()
            total_perimeter_m += geometry.length()

        run_id = uuid.uuid4().hex
        for product_path in (raster_path, vector_path):
            record_product(product_path, 'basin', 'grass:r.water.outlet',
                {'dem': self.dem.source(), 'direction': direction_layer.source()},
                {'outlet': [outlet_x, outlet_y], 'direction_audit': direction_audit,
                 'polygon_connectivity': 8}, run_id)
        QgsProject.instance().addMapLayer(vector_layer)

        return {
            "layer": vector_layer,
            "raster_path": raster_path,
            "vector_path": vector_path,
            "outlet_x": outlet_x,
            "outlet_y": outlet_y,
            "feature_count": feature_count,
            "area_m2": total_area_m2,
            "area_ha": total_area_m2 / 10000.0,
            "area_km2": total_area_m2 / 1000000.0,
            "perimeter_m": total_perimeter_m,
            "basin_cells": basin_cells,
            "pixel_area_m2": pixel_area_m2,
            "raster_area_m2": raster_area_m2,
            "raster_area_ha": raster_area_m2 / 10000.0,
            "touches_dem_boundary": touches_dem_boundary,
            "boundary_warning": boundary_warning
        }

    def flow_direction_d8(
        self,
        output_path
    ):
        """
        Calcula direcao de fluxo D8/SFD com GRASS r.watershed.

        Gera somente os produtos necessarios nesta etapa:
        acumulacao auxiliar temporaria e direcao de drenagem.
        O MDT de entrada nunca e sobrescrito.
        """

        source_path = self.dem.source()

        if not source_path:
            raise ValueError(
                "O MDT ativo nao possui uma origem valida."
            )

        if os.path.abspath(source_path) == os.path.abspath(output_path):
            raise ValueError(
                "A direcao de fluxo deve ser salva em arquivo "
                "diferente do MDT de entrada."
            )

        fresh(output_path)
        self._ensure_parent(output_path)

        params = {
            "elevation": self.dem,
            "convergence": 5,
            "memory": 300,
            "-s": True,
            "-m": False,
            "-4": False,
            "-a": False,
            "-b": True,
            "accumulation": "TEMPORARY_OUTPUT",
            "drainage": output_path,
            "GRASS_REGION_PARAMETER": self.dem.extent(),
            "GRASS_REGION_CELLSIZE_PARAMETER": 0,
            "GRASS_RASTER_FORMAT_OPT": "",
            "GRASS_RASTER_FORMAT_META": ""
        }

        result = processing.run(
            "grass:r.watershed",
            params
        )

        direction_path = result.get("drainage")

        # Alguns provedores retornam o caminho solicitado; outros
        # podem nao devolver a chave mesmo tendo gravado o arquivo.
        if not direction_path:
            direction_path = output_path

        if not os.path.exists(direction_path):
            raise RuntimeError(
                "O GRASS r.watershed terminou, mas o arquivo de "
                "direcao de fluxo nao foi encontrado:\n"
                + str(direction_path)
            )

        layer = self._add_raster(
            direction_path,
            "Direcao de fluxo - D8"
        )

        self._style_flow_direction_d8(layer)

        record_product(layer.source(), "direction", "grass:r.watershed",
                       {"dem": source_path}, {"sfd": True, "memory": 300, "convergence": 5})
        return layer

    def _style_hydrologic_corrections(self, layer):
        """
        Aplica simbologia diagnostica ao raster de correcoes.

        Ate 1 mm fica transparente para representar ausencia de
        alteracao significativa. As demais classes representam
        magnitude crescente da correcao aplicada ao MDT.
        """

        if layer is None or not layer.isValid():
            return

        provider = layer.dataProvider()

        stats = provider.bandStatistics(
            1,
            QgsRasterBandStats.All
        )

        maximum = max(
            float(stats.maximumValue),
            0.500001
        )

        shader_function = QgsColorRampShader()
        shader_function.setColorRampType(
            QgsColorRampShader.Discrete
        )

        items = [
            QgsColorRampShader.ColorRampItem(
                0.001,
                QColor(255, 255, 255, 0),
                "Sem alteracao (<= 1 mm)"
            ),
            QgsColorRampShader.ColorRampItem(
                0.05,
                QColor(255, 245, 157),
                "> 1 mm ate 5 cm"
            ),
            QgsColorRampShader.ColorRampItem(
                0.10,
                QColor(255, 213, 79),
                "> 5 ate 10 cm"
            ),
            QgsColorRampShader.ColorRampItem(
                0.25,
                QColor(255, 167, 38),
                "> 10 ate 25 cm"
            ),
            QgsColorRampShader.ColorRampItem(
                0.50,
                QColor(239, 108, 0),
                "> 25 ate 50 cm"
            ),
            QgsColorRampShader.ColorRampItem(
                maximum,
                QColor(183, 28, 28),
                "> 50 cm - verificar"
            )
        ]

        shader_function.setColorRampItemList(items)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(
            shader_function
        )

        renderer = QgsSingleBandPseudoColorRenderer(
            provider,
            1,
            raster_shader
        )

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def hydrologic_dem_difference(
        self,
        prepared_dem,
        output_path
    ):
        """
        Calcula a diferenca entre o MDT preparado e o MDT original.

        Resultado:
            diferenca = preparado - original

        Valores positivos representam elevacao aplicada pelo
        condicionamento hidrologico.
        """

        if prepared_dem is None:
            raise ValueError(
                "Nenhum MDT preparado foi informado."
            )

        if not isinstance(prepared_dem, QgsRasterLayer):
            raise TypeError(
                "O MDT preparado precisa ser uma camada raster."
            )

        if not prepared_dem.isValid():
            raise ValueError(
                "O MDT preparado nao e valido."
            )

        self._ensure_parent(output_path)

        params = {
            "INPUT_A": prepared_dem,
            "BAND_A": 1,
            "INPUT_B": self.dem,
            "BAND_B": 1,
            "INPUT_C": None,
            "BAND_C": 1,
            "INPUT_D": None,
            "BAND_D": 1,
            "INPUT_E": None,
            "BAND_E": 1,
            "INPUT_F": None,
            "BAND_F": 1,
            "FORMULA": "A-B",
            "NO_DATA": -9999.0,
            "EXTENT_OPT": 0,
            "PROJWIN": None,
            "RTYPE": 5,
            "CREATION_OPTIONS": "",
            "EXTRA": "",
            "OUTPUT": output_path
        }

        result = processing.run(
            "gdal:rastercalculator",
            params
        )

        layer = self._add_raster(
            result["OUTPUT"],
            "Correcao do MDT - diferenca"
        )

        self._style_hydrologic_corrections(layer)

        stats = layer.dataProvider().bandStatistics(
            1,
            QgsRasterBandStats.All
        )

        provider = layer.dataProvider()

        width = layer.width()
        height = layer.height()

        block = provider.block(
            1,
            layer.extent(),
            width,
            height
        )

        pixel_width = abs(layer.rasterUnitsPerPixelX())
        pixel_height = abs(layer.rasterUnitsPerPixelY())
        pixel_area = pixel_width * pixel_height

        classes = [
            {
                "key": "unchanged",
                "label": "Sem alteracao (<= 1 mm)",
                "count": 0
            },
            {
                "key": "0_5cm",
                "label": "> 1 mm ate 5 cm",
                "count": 0
            },
            {
                "key": "5_10cm",
                "label": "> 5 ate 10 cm",
                "count": 0
            },
            {
                "key": "10_25cm",
                "label": "> 10 ate 25 cm",
                "count": 0
            },
            {
                "key": "25_50cm",
                "label": "> 25 ate 50 cm",
                "count": 0
            },
            {
                "key": "over_50cm",
                "label": "> 50 cm",
                "count": 0
            }
        ]

        valid_cells = 0
        negative_cells = 0

        for row in range(height):
            for col in range(width):
                if block.isNoData(row, col):
                    continue

                value = float(block.value(row, col))

                if not math.isfinite(value):
                    continue

                valid_cells += 1

                if value < -0.001:
                    negative_cells += 1

                if value <= 0.001:
                    classes[0]["count"] += 1
                elif value <= 0.05:
                    classes[1]["count"] += 1
                elif value <= 0.10:
                    classes[2]["count"] += 1
                elif value <= 0.25:
                    classes[3]["count"] += 1
                elif value <= 0.50:
                    classes[4]["count"] += 1
                else:
                    classes[5]["count"] += 1

        for item in classes:
            count = item["count"]
            area_m2 = count * pixel_area

            item["area_m2"] = area_m2
            item["area_ha"] = area_m2 / 10000.0
            item["percent"] = (
                (count / valid_cells) * 100.0
                if valid_cells > 0
                else 0.0
            )

        changed_cells = sum(
            item["count"]
            for item in classes[1:]
        )

        changed_area_m2 = changed_cells * pixel_area

        changed_percent = (
            (changed_cells / valid_cells) * 100.0
            if valid_cells > 0
            else 0.0
        )

        return {
            "layer": layer,
            "minimum": float(stats.minimumValue),
            "maximum": float(stats.maximumValue),
            "mean": float(stats.mean),
            "stddev": float(stats.stdDev),
            "valid_cells": valid_cells,
            "pixel_area_m2": pixel_area,
            "changed_cells": changed_cells,
            "changed_area_m2": changed_area_m2,
            "changed_area_ha": changed_area_m2 / 10000.0,
            "changed_percent": changed_percent,
            "negative_cells": negative_cells,
            "classes": classes
        }

    def slope_degrees(self, output_path, z_factor=1.0):
        self._ensure_parent(output_path)

        params = {
            "INPUT": self.dem,
            "Z_FACTOR": float(z_factor),
            "NODATA": -9999.0,
            "OUTPUT": output_path
        }

        result = processing.run(
            "native:slope",
            params
        )

        return self._add_raster(
            result["OUTPUT"],
            "Declividade - graus"
        )

    def slope_percent(self, output_path, z_factor=1.0):
        """Calcula declividade em porcentagem."""

        import tempfile

        self._ensure_parent(output_path)

        temp_dir = tempfile.mkdtemp(
            prefix="hydrogeo_slope_"
        )

        temp_degrees = os.path.join(
            temp_dir,
            "slope_degrees.tif"
        )

        try:
            degree_result = processing.run(
                "native:slope",
                {
                    "INPUT": self.dem,
                    "Z_FACTOR": float(z_factor),
                    "NODATA": -9999.0,
                    "OUTPUT": temp_degrees
                }
            )

            params = {
                "INPUT_A": degree_result["OUTPUT"],
                "BAND_A": 1,
                "INPUT_B": None,
                "BAND_B": None,
                "INPUT_C": None,
                "BAND_C": None,
                "INPUT_D": None,
                "BAND_D": None,
                "INPUT_E": None,
                "BAND_E": None,
                "INPUT_F": None,
                "BAND_F": None,
                "FORMULA": "tan(A*pi/180.0)*100.0",
                "NO_DATA": -9999.0,
                "EXTENT_OPT": 0,
                "PROJWIN": None,
                "RTYPE": 5,
                "OPTIONS": "",
                "EXTRA": "",
                "OUTPUT": output_path
            }

            result = processing.run(
                "gdal:rastercalculator",
                params
            )

            return self._add_raster(
                result["OUTPUT"],
                "Declividade - porcentagem"
            )

        finally:
            try:
                import shutil
                shutil.rmtree(
                    temp_dir,
                    ignore_errors=True
                )
            except Exception:
                pass

    def _style_slope_classes(self, layer):
        """Aplica simbologia categórica à declividade classificada."""

        classes = [
            QgsPalettedRasterRenderer.Class(
                1,
                QColor("#1a9850"),
                "0 a <3 %"
            ),
            QgsPalettedRasterRenderer.Class(
                2,
                QColor("#91cf60"),
                "3 a <8 %"
            ),
            QgsPalettedRasterRenderer.Class(
                3,
                QColor("#d9ef8b"),
                "8 a <20 %"
            ),
            QgsPalettedRasterRenderer.Class(
                4,
                QColor("#fee08b"),
                "20 a <45 %"
            ),
            QgsPalettedRasterRenderer.Class(
                5,
                QColor("#fc8d59"),
                "45 a <75 %"
            ),
            QgsPalettedRasterRenderer.Class(
                6,
                QColor("#d73027"),
                "75 % ou mais"
            ),
        ]

        renderer = QgsPalettedRasterRenderer(
            layer.dataProvider(),
            1,
            classes
        )

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def classify_slope_percent(
        self,
        input_raster,
        output_path
    ):
        """Classifica declividade percentual em seis classes."""

        self._ensure_parent(output_path)

        table = [
            0.0, 3.0, 1,
            3.0, 8.0, 2,
            8.0, 20.0, 3,
            20.0, 45.0, 4,
            45.0, 75.0, 5,
            75.0, 1000000.0, 6
        ]

        params = {
            "INPUT_RASTER": input_raster,
            "RASTER_BAND": 1,
            "TABLE": table,
            "NO_DATA": 0,
            "RANGE_BOUNDARIES": 1,
            "NODATA_FOR_MISSING": True,
            "DATA_TYPE": 0,
            "CREATION_OPTIONS": "",
            "OUTPUT": output_path
        }

        result = processing.run(
            "native:reclassifybytable",
            params
        )

        layer = self._add_raster(
            result["OUTPUT"],
            "Declividade - classes"
        )

        self._style_slope_classes(layer)

        return layer

    def hypsometry(
        self,
        output_path,
        minimum,
        maximum,
        interval
    ):
        """Gera produto hipsométrico preservando as cotas originais."""

        self._ensure_parent(output_path)

        minimum = float(minimum)
        maximum = float(maximum)
        interval = float(interval)

        if maximum <= minimum:
            raise ValueError(
                "A elevação máxima deve ser maior que a mínima."
            )

        if interval <= 0:
            raise ValueError(
                "O intervalo hipsométrico deve ser maior que zero."
            )

        params = {
            "INPUT": self.dem,
            "TARGET_CRS": None,
            "NODATA": None,
            "COPY_SUBDATASETS": False,
            "OPTIONS": "",
            "EXTRA": "",
            "DATA_TYPE": 0,
            "OUTPUT": output_path
        }

        result = processing.run(
            "gdal:translate",
            params
        )

        layer = self._add_raster(
            result["OUTPUT"],
            "Hipsometria — unidade vertical não confirmada"
        )

        # -------------------------------------------------
        # Classes cartograficamente arredondadas.
        #
        # Exemplo:
        # MDT = 448.22 a 476.42 m
        # intervalo = 5 m
        #
        # Resultado:
        # 445-450, 450-455 ... 475-480 m
        # -------------------------------------------------

        class_minimum = (
            math.floor(minimum / interval) * interval
        )

        class_maximum = (
            math.ceil(maximum / interval) * interval
        )

        # Proteção para valores exatamente múltiplos.
        if class_maximum <= maximum:
            class_maximum += interval

        breaks = [class_minimum]

        value = class_minimum + interval

        while value < class_maximum:
            breaks.append(value)
            value += interval

        breaks.append(class_maximum)

        # -------------------------------------------------
        # Paleta hipsométrica.
        #
        # Azul fica reservado aos produtos relacionados
        # à água, drenagem e alagamento.
        # -------------------------------------------------

        colors = [
            "#1B7837",
            "#5AAE61",
            "#A6D96A",
            "#D9EF8B",
            "#FFFFBF",
            "#FEE08B",
            "#FDAE61",
            "#D98C4A",
            "#A6611A",
            "#8C510A",
            "#B8A99A",
            "#F2F2F2"
        ]

        shader_function = QgsColorRampShader()
        shader_function.setColorRampType(
            QgsColorRampShader.Type.Discrete
        )

        items = []

        class_count = len(breaks) - 1

        for index in range(class_count):
            lower = breaks[index]
            upper = breaks[index + 1]

            if class_count == 1:
                color_index = 0
            else:
                color_index = round(
                    index * (len(colors) - 1)
                    / (class_count - 1)
                )

            def format_elevation(value):
                if abs(value - round(value)) < 1e-9:
                    return f"{value:.0f}"
                return f"{value:.2f}"

            label = (
                f"{format_elevation(lower)} a "
                f"{format_elevation(upper)}"
            )

            items.append(
                QgsColorRampShader.ColorRampItem(
                    upper,
                    QColor(colors[color_index]),
                    label
                )
            )

        shader_function.setColorRampItemList(items)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(
            shader_function
        )

        renderer = QgsSingleBandPseudoColorRenderer(
            layer.dataProvider(),
            1,
            raster_shader
        )

        layer.setRenderer(renderer)
        layer.triggerRepaint()

        return layer, breaks

    def aspect(self, output_path, z_factor=1.0):
        self._ensure_parent(output_path)

        params = {
            "INPUT": self.dem,
            "Z_FACTOR": float(z_factor),
            "NODATA": -9999.0,
            "OUTPUT": output_path
        }

        result = processing.run(
            "native:aspect",
            params
        )

        return self._add_raster(
            result["OUTPUT"],
            "Orientação de vertentes"
        )

    def classify_aspect(self, input_raster, output_path):
        """Classifica orientação de vertentes em oito direções."""

        self._ensure_parent(output_path)

        # Classes:
        # 1 = N
        # 2 = NE
        # 3 = E
        # 4 = SE
        # 5 = S
        # 6 = SO
        # 7 = O
        # 8 = NO
        #
        # Norte cruza 0 graus:
        # 337.5-360 e 0-22.5.

        formula = (
            "1*((A>=0)*(A<22.5)) + "
            "2*((A>=22.5)*(A<67.5)) + "
            "3*((A>=67.5)*(A<112.5)) + "
            "4*((A>=112.5)*(A<157.5)) + "
            "5*((A>=157.5)*(A<202.5)) + "
            "6*((A>=202.5)*(A<247.5)) + "
            "7*((A>=247.5)*(A<292.5)) + "
            "8*((A>=292.5)*(A<337.5)) + "
            "1*((A>=337.5)*(A<=360))"
        )

        params = {
            "INPUT_A": input_raster,
            "BAND_A": 1,
            "INPUT_B": None,
            "BAND_B": 1,
            "INPUT_C": None,
            "BAND_C": 1,
            "INPUT_D": None,
            "BAND_D": 1,
            "INPUT_E": None,
            "BAND_E": 1,
            "INPUT_F": None,
            "BAND_F": 1,
            "FORMULA": formula,
            "NO_DATA": 0,
            "EXTENT_OPT": 0,
            "PROJWIN": None,
            "RTYPE": 0,
            "OPTIONS": "",
            "EXTRA": "",
            "OUTPUT": output_path
        }

        result = processing.run(
            "gdal:rastercalculator",
            params
        )

        layer = self._add_raster(
            result["OUTPUT"],
            "Orientação de vertentes - classes"
        )

        classes = [
            QgsPalettedRasterRenderer.Class(
                1, QColor("#4C78A8"), "N"
            ),
            QgsPalettedRasterRenderer.Class(
                2, QColor("#72B7B2"), "NE"
            ),
            QgsPalettedRasterRenderer.Class(
                3, QColor("#54A24B"), "E"
            ),
            QgsPalettedRasterRenderer.Class(
                4, QColor("#B5CF6B"), "SE"
            ),
            QgsPalettedRasterRenderer.Class(
                5, QColor("#F2CF5B"), "S"
            ),
            QgsPalettedRasterRenderer.Class(
                6, QColor("#F28E2B"), "SO"
            ),
            QgsPalettedRasterRenderer.Class(
                7, QColor("#E15759"), "O"
            ),
            QgsPalettedRasterRenderer.Class(
                8, QColor("#B279A2"), "NO"
            )
        ]

        renderer = QgsPalettedRasterRenderer(
            layer.dataProvider(),
            1,
            classes
        )

        layer.setRenderer(renderer)
        layer.triggerRepaint()

        return layer

    def hillshade(
        self,
        output_path,
        z_factor=1.0,
        azimuth=315.0,
        vertical_angle=45.0
    ):
        """Gera sombreamento do relevo a partir do MDT/MDE ativo."""

        self._ensure_parent(output_path)

        params = {
            "INPUT": self.dem,
            "Z_FACTOR": float(z_factor),
            "AZIMUTH": float(azimuth),
            "V_ANGLE": float(vertical_angle),
            "NODATA": -9999.0,
            "CREATION_OPTIONS": "",
            "OUTPUT": output_path
        }

        result = processing.run(
            "native:hillshade",
            params
        )

        return self._add_raster(
            result["OUTPUT"],
            "Sombreamento do relevo"
        )

    def relief(self, output_path, z_factor=1.0):
        self._ensure_parent(output_path)

        params = {
            "INPUT": self.dem,
            "Z_FACTOR": float(z_factor),
            "AUTO_COLORS": True,
            "COLORS": None,
            "OUTPUT": output_path
        }

        result = processing.run(
            "native:relief",
            params
        )

        return self._add_raster(
            result["OUTPUT"],
            "Relevo hipsométrico"
        )
