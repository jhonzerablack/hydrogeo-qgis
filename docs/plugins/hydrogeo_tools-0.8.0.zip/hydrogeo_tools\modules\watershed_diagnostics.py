"""Additive diagnostics; never changes the validated watershed engine."""
import json
import math
from pathlib import Path

import numpy as np
from osgeo import gdal, osr
from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
                       QgsField, QgsVectorFileWriter, QgsProject, QgsUnitTypes,
                       QgsMarkerSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer)
from qgis.PyQt.QtCore import QMetaType


def _valid(ds):
    band = ds.GetRasterBand(1)
    a = band.ReadAsArray().astype(float)
    ok = np.isfinite(a) & (band.GetMaskBand().ReadAsArray() != 0)
    nd = band.GetNoDataValue()
    if nd is not None:
        ok &= a != nd
    return a, ok


def diagnose(dem, result, vertical_metres=False):
    """Full-grid Horn slope, then basin mask. No invented vertical units."""
    if dem.crs().mapUnits() != QgsUnitTypes.DistanceUnit.Meters:
        raise ValueError("Diagnóstico requer SRC projetado em metros.")
    ds = gdal.Open(dem.source())
    basin = gdal.Open(result['raster_path'])
    if ds is None or basin is None:
        raise ValueError("Não foi possível abrir MDT/máscara da microbacia.")
    gt = ds.GetGeoTransform()
    if gt[2] != 0 or gt[4] != 0 or gt[1] <= 0 or gt[5] >= 0:
        raise ValueError('Diagnóstico requer grade norte-acima sem rotação.')
    s1, s2 = osr.SpatialReference(), osr.SpatialReference()
    s1.ImportFromWkt(ds.GetProjection())
    s2.ImportFromWkt(basin.GetProjection())
    if (ds.RasterXSize != basin.RasterXSize or ds.RasterYSize != basin.RasterYSize
            or not s1.IsSame(s2) or not np.allclose(ds.GetGeoTransform(), basin.GetGeoTransform(), rtol=0, atol=1e-8)):
        raise ValueError("MDT e máscara devem ter exatamente a mesma grade e SRC.")
    z, valid = _valid(ds)
    b, bv = _valid(basin)
    mask = bv & (b > 0)
    selected = mask & valid
    values = z[selected]
    if not values.size:
        raise ValueError("Microbacia sem elevações válidas.")
    out = {k: result[k] for k in ('area_m2', 'area_ha', 'perimeter_m', 'boundary_warning', 'touches_dem_boundary')}
    out.update(elevation_unit='m (confirmada pelo usuário)' if vertical_metres else 'unidade vertical não confirmada',
               elevation_min=float(values.min()), elevation_mean=float(values.mean()),
               elevation_max=float(values.max()), elevation_range=float(np.ptp(values)),
               basin_cells=int(mask.sum()), elevation_cells=int(values.size),
               slope_mean_deg=None, slope_max_deg=None, slope_cells=0,
               drainage_length_m=None, drainage_density_km_km2=None,
               pending=['Comprimento e densidade: rede modelada e limiar ainda não selecionados.',
                        'Canal principal: pendente de implementação e validação.'])
    if vertical_metres:
        # Exclude every 3x3 neighbourhood containing invalid elevation, including edges.
        neighbours = np.zeros_like(valid)
        neighbours[1:-1, 1:-1] = True
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                neighbours[1:-1, 1:-1] &= valid[1+dy:valid.shape[0]-1+dy, 1+dx:valid.shape[1]-1+dx]
        slope_ds = gdal.DEMProcessing('', ds, 'slope', format='MEM', alg='Horn', computeEdges=False, scale=1.0)
        if slope_ds is None:
            raise ValueError('Falha ao calcular declividade Horn.')
        slope, sv = _valid(slope_ds)
        samples = slope[selected & neighbours & sv]
        if samples.size:
            out.update(slope_mean_deg=float(samples.mean()), slope_max_deg=float(samples.max()), slope_cells=int(samples.size))
        else:
            out['pending'].append('Declividade: sem vizinhança 3x3 válida.')
    else:
        out['pending'].append('Confirmar unidade vertical em metros para calcular declividade.')
    out['method'] = 'Elevações nos centros das células válidas; declividade Horn em graus no MDT completo, sem interpolar bordas/NoData; área e perímetro planares do motor v0.4.0.'
    return out


def save_outlets(dem, accumulation, result, path):
    """Two records even when coincident. Accumulation belongs to each point."""
    if Path(path).exists():
        raise FileExistsError(path)
    if not accumulation.isValid() or accumulation.crs() != dem.crs():
        raise ValueError('Acumulação deve ser válida e ter o mesmo SRC do MDT.')
    layer = QgsVectorLayer('Point', 'Exutório — clicado e ajustado (modelado)', 'memory')
    layer.setCrs(dem.crs())
    provider = layer.dataProvider()
    names = [('tipo', False), ('x', True), ('y', True), ('snap_m', True),
             ('acum_val', True), ('acum_mag', True), ('raio_m', True), ('src', False), ('semantica', False)]
    provider.addAttributes([QgsField(n, QMetaType.Type.Double if numeric else QMetaType.Type.QString) for n, numeric in names])
    layer.updateFields()
    for kind, prefix in [('clicado', 'original'), ('ajustado', 'snapped')]:
        x, y = result[prefix + '_outlet_x'], result[prefix + '_outlet_y']
        if kind == 'ajustado':
            value = result['snap_accumulation_value']
        else:
            value, ok = accumulation.dataProvider().sample(QgsPointXY(x, y), 1)
            value = float(value) if ok and math.isfinite(value) else None
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        f.setAttributes([kind, x, y, result['snap_distance_m'], value,
                         abs(value) if value is not None else None, result['snap_search_radius_m'],
                         dem.crs().authid() or dem.crs().toWkt(), 'informado pelo usuário' if kind == 'clicado' else 'ajustado à acumulação modelada'])
        if not provider.addFeatures([f])[0]:
            raise RuntimeError('Falha ao criar ponto auditável.')
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = 'GPKG'
    options.layerName = 'exutorios_modelados'
    status = QgsVectorFileWriter.writeAsVectorFormatV3(layer, str(path), QgsProject.instance().transformContext(), options)
    if status[0] != QgsVectorFileWriter.WriterError.NoError:
        raise RuntimeError(str(status))
    saved = QgsVectorLayer(str(path), layer.name(), 'ogr')
    if not saved.isValid() or saved.featureCount() != 2:
        raise RuntimeError('Falha ao verificar pontos salvos.')
    categories = []
    for kind, shape, color, size in [('clicado', 'cross2', '#d55e00', '4'),
                                      ('ajustado', 'circle', '#0072b2', '2.5')]:
        symbol = QgsMarkerSymbol.createSimple({'name': shape, 'color': color,
                                              'size': size, 'outline_color': '#ffffff',
                                              'outline_width': '0.3'})
        categories.append(QgsRendererCategory(kind, symbol, kind.capitalize()))
    saved.setRenderer(QgsCategorizedSymbolRenderer('tipo', categories))
    # Persist beside the new GPKG so reopening retains the audit symbology.
    _, style_ok = saved.saveNamedStyle(str(Path(path).with_suffix('.qml')))
    if not style_ok:
        raise RuntimeError('Pontos salvos, mas falhou a gravação do estilo QML.')
    return saved



def drainage_metrics(basin_vector_path, drainage_layer, area_m2):
    """
    Calcula métricas da rede de drenagem modelada dentro da
    microbacia modelada.

    O comprimento considera somente a parte das geometrias
    que intersecta o polígono da microbacia.

    A densidade é expressa em km de drenagem modelada por km²
    de microbacia modelada.
    """

    area_m2 = float(area_m2)

    if not math.isfinite(area_m2) or area_m2 <= 0:
        raise ValueError(
            "A área da microbacia deve ser válida e maior que zero."
        )

    basin = QgsVectorLayer(
        str(basin_vector_path),
        "Microbacia modelada",
        "ogr"
    )

    if not basin.isValid():
        raise ValueError(
            "Não foi possível abrir o vetor da microbacia modelada."
        )

    if drainage_layer is None:
        raise ValueError(
            "A rede de drenagem modelada não foi informada."
        )

    if isinstance(drainage_layer, (str, Path)):
        drainage = QgsVectorLayer(
            str(drainage_layer),
            "Rede de drenagem modelada",
            "ogr"
        )
    else:
        drainage = drainage_layer

    if not drainage.isValid():
        raise ValueError(
            "A rede de drenagem modelada não é válida."
        )

    if basin.crs() != drainage.crs():
        raise ValueError(
            "Microbacia e rede de drenagem devem usar o mesmo SRC."
        )

    basin_geometries = []

    for feature in basin.getFeatures():
        geometry = feature.geometry()

        if geometry is None or geometry.isEmpty():
            continue

        basin_geometries.append(
            QgsGeometry(geometry)
        )

    if not basin_geometries:
        raise ValueError(
            "A microbacia não possui geometria válida."
        )

    if len(basin_geometries) == 1:
        basin_geometry = basin_geometries[0]
    else:
        basin_geometry = QgsGeometry.unaryUnion(
            basin_geometries
        )

    if (
        basin_geometry is None
        or basin_geometry.isEmpty()
    ):
        raise ValueError(
            "Não foi possível construir a geometria da microbacia."
        )

    drainage_length_m = 0.0
    intersecting_features = 0

    for feature in drainage.getFeatures():
        geometry = feature.geometry()

        if geometry is None or geometry.isEmpty():
            continue

        if not geometry.intersects(
            basin_geometry
        ):
            continue

        clipped = geometry.intersection(
            basin_geometry
        )

        if clipped is None or clipped.isEmpty():
            continue

        length_m = float(
            clipped.length()
        )

        if (
            not math.isfinite(length_m)
            or length_m <= 0
        ):
            continue

        drainage_length_m += length_m
        intersecting_features += 1

    area_km2 = area_m2 / 1000000.0
    drainage_length_km = (
        drainage_length_m / 1000.0
    )

    drainage_density_km_km2 = (
        drainage_length_km / area_km2
    )

    return {
        "drainage_length_m": drainage_length_m,
        "drainage_length_km": drainage_length_km,
        "drainage_density_km_km2": drainage_density_km_km2,
        "drainage_intersecting_features": intersecting_features,
        "drainage_semantics": (
            "Rede de drenagem modelada selecionada pelo usuário; "
            "comprimento recortado geometricamente pela microbacia "
            "modelada. A densidade depende do limiar e da rede "
            "utilizados."
        )
    }



def attach_drainage_metrics(
    diagnostic,
    basin_vector_path,
    drainage_layer,
    drainage_source=None
):
    """
    Acrescenta ao diagnóstico as métricas da rede de drenagem
    modelada selecionada pelo usuário.

    Não altera a microbacia nem a rede original.
    """

    metrics = drainage_metrics(
        basin_vector_path,
        drainage_layer,
        diagnostic["area_m2"]
    )

    diagnostic.update(
        metrics
    )

    if drainage_source is None:
        try:
            drainage_source = drainage_layer.source()
        except AttributeError:
            drainage_source = str(drainage_layer)

    diagnostic["drainage_source"] = str(
        drainage_source
    )

    pending = diagnostic.get(
        "pending",
        []
    )

    diagnostic["pending"] = [
        item
        for item in pending
        if not item.startswith(
            "Comprimento e densidade:"
        )
    ]

    return diagnostic


def summary_text(d):
    slope = (
        'pendente'
        if d['slope_mean_deg'] is None
        else f"{d['slope_mean_deg']:.2f}° / {d['slope_max_deg']:.2f}°"
    )

    lines = [
        "",
        "",
        "Diagnóstico da microbacia modelada",
        (
            "Altitude mín./média/máx.: "
            f"{d['elevation_min']:.2f} / "
            f"{d['elevation_mean']:.2f} / "
            f"{d['elevation_max']:.2f}"
        ),
        (
            f"Amplitude: {d['elevation_range']:.2f} — "
            f"{d['elevation_unit']}"
        ),
        f"Declividade média/máxima: {slope}",
        (
            "Células de altitude: "
            f"{d['elevation_cells']}/{d['basin_cells']}; "
            f"declividade: {d['slope_cells']}"
        )
    ]

    drainage_length = d.get(
        "drainage_length_m"
    )

    drainage_density = d.get(
        "drainage_density_km_km2"
    )

    if (
        drainage_length is not None
        and drainage_density is not None
    ):
        lines.extend(
            [
                (
                    "Comprimento da rede modelada: "
                    f"{drainage_length:.2f} m"
                ),
                (
                    "Densidade da rede modelada: "
                    f"{drainage_density:.2f} km/km²"
                ),
                (
                    "Trechos intersectados: "
                    f"{d.get('drainage_intersecting_features', 0)}"
                )
            ]
        )

        source = d.get(
            "drainage_source"
        )

        if source:
            lines.append(
                "Rede utilizada: "
                + str(source)
            )

    if d.get('main_channel_status') == 'unavailable':
        lines.append(d['main_channel_reason_text'])
    elif d.get('main_channel_length_m') is not None:
        lines.extend([
            f"Comprimento do canal principal modelado: {d['main_channel_length_m']:.2f} m",
            f"Trechos do canal principal modelado: {d['main_channel_segments']}",
            f"Distância exutório-rede: {d['main_channel_outlet_distance_m']:.3f} m",
            "Canal principal modelado salvo: " + str(d['main_channel_path']),
            str(d['main_channel_semantics']),
        ])

    pending = d.get(
        "pending",
        []
    )

    if pending:
        lines.extend(
            pending
        )

    return "\n".join(
        lines
    )


def save_report(diagnostic, path):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(diagnostic, stream, ensure_ascii=False, indent=2, allow_nan=False)
