from __future__ import annotations

from datetime import datetime
from html import escape
import json
from pathlib import Path


def load_diagnostic(path):
    source = Path(path)
    with source.open("r", encoding="utf-8") as stream:
        data = json.load(stream)

    if not isinstance(data, dict):
        raise ValueError("Estrutura JSON inválida.")

    if "morphometry" not in data:
        raise ValueError(
            "O arquivo selecionado não parece ser um diagnóstico completo do HydroGeo."
        )

    return data


def _find_first(value, key):
    if isinstance(value, dict):
        if key in value:
            return value[key]
        for child in value.values():
            found = _find_first(child, key)
            if found is not None:
                return found

    elif isinstance(value, list):
        for child in value:
            found = _find_first(child, key)
            if found is not None:
                return found

    return None


def _fmt(value, digits=3):
    if value is None:
        return "Indisponível"
    if isinstance(value, bool):
        return "Sim" if value else "Não"
    if isinstance(value, float):
        return f"{value:.{digits}f}"
    return str(value)


def _metric(data, key):
    morph = data.get("morphometry") or {}
    return (morph.get("metrics") or {}).get(key) or {}


def _metric_text(data, key, digits=3):
    metric = _metric(data, key)

    if not metric:
        return "Indisponível"

    if metric.get("status") != "computed":
        reason = metric.get("reason")
        return (
            "Indisponível  " + str(reason)
            if reason
            else "Indisponível"
        )

    value = metric.get("value")
    unit = metric.get("unit") or ""

    text = _fmt(value, digits)
    if unit and unit != "1":
        text += " " + unit

    return text


def _row(label, value):
    return (
        "<tr><th>"
        + escape(str(label))
        + "</th><td>"
        + escape(str(value))
        + "</td></tr>"
    )


def _section(title, rows):
    return (
        "<section><h2>"
        + escape(title)
        + "</h2><table>"
        + "".join(rows)
        + "</table></section>"
    )


def _collect_messages(data):
    output = []

    def walk(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ("warnings", "limitations", "pending"):
                    if isinstance(child, list):
                        for item in child:
                            text = str(item).strip()
                            if text and text not in output:
                                output.append(text)
                else:
                    walk(child)

        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(data)
    return output


def build_html_report(data, diagnostic_path=None):
    crs = (
        data.get("crs_authid")
        or _find_first(data, "crs_authid")
        or "Indisponível"
    )

    outlet = (
        data.get("adjusted_outlet_xy")
        or _find_first(data, "adjusted_outlet_xy")
    )

    if isinstance(outlet, (list, tuple)) and len(outlet) >= 2:
        outlet_text = f"{outlet[0]:.3f}, {outlet[1]:.3f}"
    else:
        outlet_text = "Indisponível"

    elevation = _find_first(data, "elevation_sampling") or {}
    elevation_unit = (
        " m"
        if (data.get("morphometry") or {}).get("vertical_metres_confirmed") is True
        else " (unidade vertical não confirmada)"
    )

    topology = _find_first(data, "topological_segments") or {}
    streams = _find_first(data, "strahler_streams") or {}
    bifurcation = _find_first(data, "bifurcation_ratios") or {}

    headwaters = _find_first(data, "modeled_headwater_count")
    confluences = _find_first(data, "modeled_confluence_count")
    max_order = _find_first(data, "max_strahler_order")

    counts = streams.get("counts_by_order") or {}
    if counts:
        stream_text = "; ".join(
            f"ordem {order}: {count}"
            for order, count in sorted(
                counts.items(),
                key=lambda item: int(item[0]),
            )
        )
    else:
        stream_text = "Indisponível"

    rb_values = bifurcation.get("values") or {}
    if bifurcation.get("status") == "available" and rb_values:
        rb_text = "; ".join(
            f"Rb{order} = {_fmt(value, 3)}"
            for order, value in sorted(
                rb_values.items(),
                key=lambda item: int(item[0]),
            )
        )
    else:
        rb_text = "Indisponível"
        reasons = bifurcation.get("reason_codes") or []
        if reasons:
            rb_text += "  " + ", ".join(map(str, reasons))

    identification_rows = [
        _row("SRC", crs),
        _row("Exutório ajustado", outlet_text),
        _row("Área", _metric_text(data, "area", 2)),
        _row(
            "Área em hectares",
            (
                f"{_metric(data, 'area').get('value') / 10000:.3f} ha"
                if _metric(data, "area").get("status") == "computed"
                and _metric(data, "area").get("value") is not None
                else "Indisponível"
            ),
        ),
        _row("Perímetro", _metric_text(data, "perimeter", 2)),
        _row(
            "Altitude mínima",
            (
                _fmt(elevation.get("minimum"), 2) + elevation_unit
                if elevation.get("minimum") is not None
                else "Indisponível"
            ),
        ),
        _row(
            "Altitude máxima",
            (
                _fmt(elevation.get("maximum"), 2) + elevation_unit
                if elevation.get("maximum") is not None
                else "Indisponível"
            ),
        ),
        _row(
            "Amplitude altimétrica",
            _metric_text(data, "elevation_range", 2),
        ),
    ]

    morphometry_rows = [
        _row(
            "Comprimento axial reto",
            _metric_text(data, "axial_length", 3),
        ),
        _row(
            "Coeficiente de compacidade",
            _metric_text(data, "compactness_coefficient", 5),
        ),
        _row(
            "Índice de circularidade",
            _metric_text(data, "circularity_index", 5),
        ),
        _row(
            "Fator de forma",
            _metric_text(data, "form_factor", 5),
        ),
        _row(
            "Relação de relevo",
            _metric_text(data, "relief_ratio", 6),
        ),
    ]

    drainage_rows = [
        _row(
            "Comprimento da rede modelada",
            _metric_text(data, "modelled_network_length", 2),
        ),
        _row(
            "Densidade de drenagem modelada",
            _metric_text(data, "modelled_drainage_density", 3),
        ),
        _row(
            "Feições intersectadas",
            _metric_text(data, "modelled_intersecting_features", 0),
        ),
        _row(
            "Canal principal modelado",
            _metric_text(data, "modelled_main_channel_length", 2),
        ),
    ]

    topology_rows = [
        _row("Cabeceiras modeladas", _fmt(headwaters, 0)),
        _row("Confluências modeladas", _fmt(confluences, 0)),
        _row("Segmentos topológicos", _fmt(topology.get("count"), 0)),
        _row("Ordem máxima de Strahler", _fmt(max_order, 0)),
        _row("Cursos contínuos por ordem", stream_text),
        _row("Razões de bifurcação", rb_text),
    ]

    sources = _find_first(data, "sources") or {}
    source_rows = []

    if diagnostic_path:
        source_rows.append(
            _row("Diagnóstico JSON", str(Path(diagnostic_path)))
        )

    source_labels = {
        "direction": "Direção de fluxo D8",
        "basin_mask": "Raster da microbacia",
        "stream_raster": "Raster da rede de drenagem modelada",
        "basin": "Microbacia vetorial",
        "network": "Rede de drenagem modelada",
        "dem_path": "MDT/MDE utilizado",
        "basin_vector": "Microbacia vetorial",
        "basin_raster_path": "Raster da microbacia",
        "drainage_source": "Rede de drenagem modelada",
        "main_channel_path": "Canal principal modelado",
        "outlet_points_path": "Pontos de exutório",
    }

    for name, item in sources.items():
        if not isinstance(item, dict):
            continue

        uri = (
            item.get("uri")
            or item.get("path")
            or item.get("source")
        )
        sha = item.get("sha256")

        if uri:
            value = str(uri)
        elif sha:
            value = "Caminho não registrado no diagnóstico."
        else:
            value = "Indisponível"

        if sha:
            value += "\nSHA-256: " + str(sha)

        label = source_labels.get(name, name)
        source_rows.append(_row(label, value))

    messages = _collect_messages(data)

    message_labels = {
        "modeled_not_field_observed":
            "Resultados modelados; não correspondem automaticamente a observações de campo.",
        "synthetic_stage_only":
            "Diagnóstico proveniente de etapa ou caso sintético de validação.",
        "completeness_and_direction_are_caller_assertions":
            "A completude e a direção da rede dependem das verificações de proveniência registradas na cadeia.",
        "exact_geometry_predicates_no_hidden_epsilon":
            "As verificações geométricas utilizam critérios explícitos, sem tolerância oculta adicional.",
        "quadratic_checks_not_benchmarked_for_real_networks":
            "Algumas verificações topológicas de maior custo ainda possuem limitação de desempenho em redes muito grandes.",
    }

    translated_messages = [
        message_labels.get(item, item)
        for item in messages
    ]

    warnings_html = "".join(
        "<li>" + escape(text) + "</li>"
        for text in translated_messages
    )

    if not warnings_html:
        warnings_html = "<li>Nenhum aviso adicional registrado.</li>"

    generated = datetime.now().astimezone().strftime(
        "%d/%m/%Y %H:%M:%S %z"
    )

    return f"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Relatório Técnico da Microbacia Modelada</title>
<style>
@page {{ size: A4; margin: 18mm; }}
body {{
    font-family: Arial, Helvetica, sans-serif;
    color: #202020;
    max-width: 1000px;
    margin: 0 auto;
    line-height: 1.4;
}}
header {{
    border-bottom: 3px solid #444;
    margin-bottom: 24px;
    padding-bottom: 12px;
}}
h1 {{ font-size: 24px; margin-bottom: 4px; }}
h2 {{
    margin-top: 26px;
    font-size: 17px;
    border-bottom: 1px solid #bbb;
    padding-bottom: 5px;
}}
.subtitle {{ color: #555; }}
.notice {{
    background: #f2f2f2;
    border-left: 5px solid #666;
    padding: 12px;
    margin: 18px 0;
}}
table {{
    width: 100%;
    border-collapse: collapse;
    margin-top: 8px;
}}
th, td {{
    border: 1px solid #ccc;
    padding: 7px;
    vertical-align: top;
    text-align: left;
}}
th {{ width: 38%; background: #f5f5f5; }}
td {{ white-space: pre-wrap; word-break: break-word; }}
footer {{
    margin-top: 30px;
    border-top: 1px solid #aaa;
    padding-top: 10px;
    color: #666;
    font-size: 11px;
}}
</style>
</head>
<body>

<header>
<h1>Relatório Técnico da Microbacia Modelada</h1>
<div class="subtitle">HydroGeo Tools  v0.8.0</div>
<div class="subtitle">Gerado em {escape(generated)}</div>
</header>

<div class="notice">
<strong>Atenção:</strong>
os resultados apresentados são modelados a partir dos dados e parâmetros
registrados no diagnóstico HydroGeo. Não constituem, por si só,
verificação de campo, determinação de vazão ou confirmação de curso
d'água observado.
</div>

{_section("1. Identificação e caracterização", identification_rows)}
{_section("2. Morfometria", morphometry_rows)}
{_section("3. Drenagem modelada", drainage_rows)}
{_section("4. Topologia da rede modelada", topology_rows)}
{_section("5. Proveniência e arquivos associados", source_rows)}

<section>
<h2>6. Avisos, limitações e pendências</h2>
<ul>{warnings_html}</ul>
</section>

<footer>
HydroGeo Tools  relatório derivado do diagnóstico JSON já calculado.
Nenhum parâmetro hidrológico foi recalculado durante a geração deste documento.
</footer>

</body>
</html>
"""


def write_html_report(diagnostic_path, output_path):
    data = load_diagnostic(diagnostic_path)
    html = build_html_report(
        data,
        diagnostic_path=diagnostic_path,
    )

    target = Path(output_path)

    if target.exists():
        raise FileExistsError(
            "O arquivo de relatório já existe: " + str(target)
        )

    with target.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as stream:
        stream.write(html)

    return str(target)
