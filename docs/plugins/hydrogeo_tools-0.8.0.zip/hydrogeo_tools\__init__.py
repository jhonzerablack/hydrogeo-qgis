﻿def classFactory(iface):
    from .hydrogeo_tools import HydroGeoTools
    return HydroGeoTools(iface)
