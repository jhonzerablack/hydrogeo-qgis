"""Pacote transacional: cópias verificadas, produtos existentes, sem hidrologia."""
from datetime import datetime
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import unicodedata
import zipfile

from .export_results import _extract_paths, _sha256, _load_json
from .map_generator import collect_map_sources, generate_map
from .technical_report import write_html_report

SEMANTICS = ('Rede de drenagem e canal principal são produtos modelados. '
             'O pacote não substitui verificação de campo. Nenhuma hidrologia foi recalculada. '
             'PNG não georreferenciado; PDF cartográfico não é GeoPDF; norte da quadrícula.')
FOLDERS = ('01_Diagnostico', '02_Mapas', '03_Relatorios', '04_Dados', '05_Rastreabilidade')


def safe_name(value):
    value = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode()
    value = re.sub(r'[^A-Za-z0-9_.-]+', '_', value).strip('._')
    suffix = Path(value).suffix[:12]
    value = (value[:-len(suffix)][:100] + suffix) if suffix else value[:100]
    return 'HG_' + (value or 'arquivo')


def default_package_name(diagnostic):
    return safe_name(Path(diagnostic).stem) + '_pacote_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.zip'


def collect_package_sources(data, diagnostic):
    """Reutiliza exportação e adiciona referências explícitas de proveniência.

    Todas as referências declaradas são obrigatórias. Não varre diretórios.
    Shapefiles incluem componentes necessários e auxiliares conhecidos.
    """
    records = {}
    missing = []
    def add(label, raw):
        if not isinstance(raw, str) or not raw:
            return
        raw_path = raw.split('|', 1)[0]
        if '://' in raw_path or raw_path.startswith('/vsi'):
            missing.append(label + ': fonte não local: ' + raw)
            return
        source = Path(raw_path)
        if not source.is_absolute():
            source = Path(diagnostic).parent / source
        source = source.resolve()
        key = os.path.normcase(str(source))
        if key not in records:
            records[key] = {'source': str(source), 'labels': [], 'references': []}
        record = records[key]
        if label not in record['labels']:
            record['labels'].append(label)
        if raw not in record['references']:
            record['references'].append(raw)
    extracted = _extract_paths(data)
    for item in extracted:
        add(item['label'], item['path'])
    maps = collect_map_sources(data)
    for key in ('dem', 'basin', 'network', 'main_channel', 'outlet_points'):
        if not maps.get(key):
            missing.append('Referência obrigatória não declarada: ' + key)
        else:
            add(key, maps[key])
    labels = {i['label'] for i in extracted}
    for label in ('direcao_fluxo_D8', 'raster_microbacia', 'raster_rede_drenagem_modelada'):
        if label not in labels:
            missing.append('Referência obrigatória não declarada: ' + label)
    def walk(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ('path', 'uri') and isinstance(child, str):
                    add('referencia_diagnostico', child)
                elif key == 'sources' and isinstance(child, dict):
                    for name, source in child.items():
                        if isinstance(source, str):
                            add(name, source)
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(data)
    for record in list(records.values()):
        source = Path(record['source'])
        if source.suffix.lower() == '.shp':
            for suffix in ('.shx', '.dbf', '.prj'):
                add('componente_shapefile', str(source.with_suffix(suffix)))
            for suffix in ('.cpg', '.qix'):
                if source.with_suffix(suffix).is_file():
                    add('auxiliar_shapefile', str(source.with_suffix(suffix)))
    for record in records.values():
        if not Path(record['source']).is_file():
            missing.append(record['source'])
    if missing:
        raise FileNotFoundError('Pacote bloqueado. Fontes obrigatórias ausentes ou incompatíveis:\n' + '\n'.join(sorted(set(missing))))
    return list(records.values())


def generate_package(diagnostic_path, output_zip):
    diagnostic = Path(diagnostic_path).resolve()
    target = Path(output_zip).absolute()
    if target.suffix.lower() != '.zip':
        raise ValueError('O destino deve ter extensão .zip.')
    if target.exists():
        raise FileExistsError('O pacote já existe. Escolha outro nome: ' + str(target))
    if not target.parent.is_dir():
        raise FileNotFoundError('Pasta de destino inexistente: ' + str(target.parent))
    data = _load_json(diagnostic)
    if not isinstance(data.get('morphometry'), dict) or not data['morphometry']:
        raise ValueError('Diagnóstico sem morfometria válida.')
    sources = collect_package_sources(data, diagnostic)
    before = {str(p): _sha256(p) for p in [diagnostic, *[r['source'] for r in sources]]}
    # TemporaryDirectory sempre limpa inclusive em erro; staging no mesmo volume.
    with tempfile.TemporaryDirectory(prefix='.hydrogeo_package_', dir=target.parent) as temporary:
        staging = Path(temporary)
        content = staging / 'content'
        for folder in FOLDERS:
            (content / folder).mkdir(parents=True)
        records = []
        def copy(source, relative, labels, references):
            destination = content / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
            checksum = _sha256(destination)
            if checksum != before[str(source)]:
                raise RuntimeError('Fonte mudou durante a cópia: ' + str(source))
            records.append(dict(path=relative, source=str(source), labels=labels,
                                references=references, sha256=checksum, size=destination.stat().st_size))
        copy(diagnostic, '01_Diagnostico/' + safe_name(diagnostic.name), ['diagnostico_original'], [str(diagnostic)])
        # Um diretório por conjunto evita colisões e preserva nomes dos componentes SHP.
        groups = {}
        for record in sources:
            source = Path(record['source'])
            group = str(source.with_suffix('')) if source.suffix.lower() in ('.shp','.shx','.dbf','.prj','.cpg','.qix') else str(source)
            index = groups.setdefault(group, len(groups) + 1)
            relative = f'04_Dados/{index:03d}/' + safe_name(source.name)
            copy(source, relative, record['labels'], record['references'])
        generate_map(diagnostic, content/'02_Mapas/mapa_tecnico.pdf', content/'02_Mapas/mapa_tecnico.png')
        write_html_report(diagnostic, content/'03_Relatorios/relatorio_tecnico.html')
        (content/'05_Rastreabilidade/LEIA-ME.txt').write_text(
            SEMANTICS + '\nv0.8.0.\n'
            'Diagnóstico original preservado, inclusive caminhos de origem. Consulte o manifesto para localizar as cópias.\n'
            'Política: todas as fontes declaradas são obrigatórias; ausências bloqueiam o pacote.\n'
            'SHA256.txt cobre todos os demais arquivos, incluindo manifesto; não contém seu próprio hash.\n', encoding='utf-8')
        tracked = {r['path'] for r in records}
        for path in sorted(content.rglob('*')):
            if path.is_file() and path.relative_to(content).as_posix() not in tracked:
                records.append(dict(path=path.relative_to(content).as_posix(), source=None,
                                    sha256=_sha256(path), size=path.stat().st_size))
        if before != {p: _sha256(p) for p in before}:
            raise RuntimeError('Fontes alteradas durante a geração; pacote não publicado.')
        manifest = dict(schema='hydrogeo-package-1', version='v0.8.0', promoted=True,
                        created_local=datetime.now().astimezone().isoformat(), semantics=SEMANTICS,
                        missing_policy='block_all_declared_sources', missing=[], missing_count=0,
                        files=records, file_count=len(records)+2, sources_sha256=before)
        manifest_path = content/'05_Rastreabilidade/manifesto.json'
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
        lines = [r['sha256'] + '  ' + r['path'] for r in records]
        lines.append(_sha256(manifest_path) + '  05_Rastreabilidade/manifesto.json')
        (content/'05_Rastreabilidade/SHA256.txt').write_text('\n'.join(lines)+'\n', encoding='utf-8')
        archive = staging/'complete.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
            for path in sorted(content.rglob('*')):
                if path.is_file():
                    zipped.write(path, path.relative_to(content).as_posix())
        with zipfile.ZipFile(archive) as zipped:
            if zipped.testzip() is not None:
                raise RuntimeError('Falha na verificação do ZIP.')
        # Hard link atômico, sem substituição mesmo se outro processo criar o destino.
        # Em volumes sem suporte, falha segura sem publicar um ZIP parcial.
        os.link(archive, target)
    return dict(zip=str(target), included=manifest['file_count'], missing=0, sha256=_sha256(target))
