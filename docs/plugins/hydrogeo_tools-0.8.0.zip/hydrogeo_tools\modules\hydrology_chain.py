"""Explicit working resolution and persisted, hash-checked hydrologic lineage."""
import hashlib
import json
import math
import uuid
from pathlib import Path

NOTE = 'Reamostrar MDS não o transforma em MDT; árvores e estruturas permanecem. Resultados modelados exigem avaliação de campo.'

def digest(path):
    h = hashlib.sha256()
    with open(str(path).split('|')[0], 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def sidecar(path):
    return Path(str(path).split('|')[0] + '.hydrogeo.json')

def fresh(*paths):
    normalized = [str(Path(p).resolve()).casefold() for p in paths]
    if len(set(normalized)) != len(paths): raise ValueError('Saídas devem ser distintas.')
    for p in paths:
        if Path(p).exists() or sidecar(p).exists():
            raise ValueError('Escolha um arquivo novo: ' + str(p))

def read_record(path):
    p = sidecar(path)
    if not p.exists(): return None
    record = json.loads(p.read_text('utf-8'))
    if record.get('sha256') != digest(path):
        raise ValueError('Proveniência não corresponde ao conteúdo: ' + str(path))
    return record

def raster_info(path):
    from osgeo import gdal
    d = gdal.Open(str(path))
    if d is None or d.RasterCount != 1: raise ValueError('Requer raster de uma banda.')
    gt = d.GetGeoTransform()
    if gt[2] or gt[4] or gt[1] <= 0 or gt[5] >= 0: raise ValueError('Grade rotacionada não suportada.')
    b = d.GetRasterBand(1)
    nd = b.GetNoDataValue()
    return {'width': d.RasterXSize, 'height': d.RasterYSize,
            'cells': d.RasterXSize*d.RasterYSize, 'geotransform': list(gt),
            'resolution': [gt[1], -gt[5]], 'projection': d.GetProjection(),
            'nodata': str(nd) if nd is not None and not math.isfinite(nd) else nd,
            'metadata': d.GetMetadata(), 'band_metadata': b.GetMetadata(),
            'unit': b.GetUnitType(), 'scale': b.GetScale(), 'offset': b.GetOffset()}

def record_product(path, role, algorithm, inputs, parameters=None, run_id=None):
    parents = {}
    for key, value in inputs.items():
        parent = read_record(value)
        parents[key] = {'path': str(value), 'sha256': digest(value), 'provenance': parent}
    from osgeo import gdal
    from datetime import datetime, timezone
    try:
        from qgis.core import Qgis
        qgis_version = Qgis.QGIS_VERSION
    except ImportError:
        qgis_version = None
    record = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'runtime': {'gdal': gdal.VersionInfo(), 'qgis': qgis_version},
              'schema': 'hydrogeo-chain-1', 'role': role, 'algorithm': algorithm,
              'run_id': run_id or uuid.uuid4().hex, 'path': str(path), 'sha256': digest(path),
              'inputs': parents, 'parameters': parameters or {}, 'limitations': NOTE}
    if str(path).lower().endswith(('.tif', '.tiff')): record['grid'] = raster_info(path)
    with sidecar(path).open('x', encoding='utf-8') as f:
        json.dump(record, f, ensure_ascii=False, indent=2, allow_nan=False)
    return record

def validate_direction(path):
    """Scan every cell in bounded blocks; negative exits/zero sinks retain meaning."""
    from osgeo import gdal
    import numpy as np
    record = read_record(path)
    if record and record['role'] != 'direction': raise ValueError('O raster selecionado não é direção D8: ' + record['role'])
    d = gdal.Open(str(path))
    if d is None or d.RasterCount != 1: raise ValueError('Direção D8 inválida.')
    b = d.GetRasterBand(1); valid = 0; routing = 0
    for y in range(0, d.RasterYSize, 256):
        n = min(256, d.RasterYSize-y)
        a = b.ReadAsArray(0,y,d.RasterXSize,n)
        mask = b.GetMaskBand().ReadAsArray(0,y,d.RasterXSize,n) != 0
        v = a[mask]; valid += v.size
        if np.any(~np.isfinite(v)) or np.any(v != np.floor(v)) or np.any((v < -8) | (v > 8)):
            raise ValueError('Raster incompatível com direção GRASS D8 (-8 a 8); IDs de rede não são direções.')
        routing += int(np.count_nonzero((v >= 1) & (v <= 8)))
    if not valid or not routing: raise ValueError('Nenhuma direção D8 positiva disponível.')
    return {'record': record, 'valid_cells': valid, 'routing_cells': routing,
            'status': 'recorded' if record else 'legacy_unverified',
            'warning': None if record else 'Sem proveniência: códigos válidos não comprovam que este raster seja direção.'}

def check_dem_parent(product, dem):
    r = read_record(product)
    if r and r['inputs'].get('dem', {}).get('sha256') != digest(dem):
        raise ValueError('Produto derivado de outro MDT/resolução. Recalcule a cadeia com o MDT ativo.')
    return r

def check_snap_inputs(direction, accumulation, dem):
    audit = validate_direction(direction)
    d = check_dem_parent(direction, dem)
    a = check_dem_parent(accumulation, dem)
    if a and a['role'] != 'accumulation': raise ValueError('Selecione acumulação, não rede/direção.')
    if d and d['algorithm'] == 'grass:r.stream.extract':
        if d['inputs']['accumulation']['sha256'] != digest(accumulation):
            raise ValueError('Use a acumulação registrada como entrada desta extração. Snap não comprova direção.')
    return audit

def check_topology_chain(network, direction, basin, stream):
    paths = {'network': network, 'direction': direction, 'basin': basin, 'stream': stream}
    records = {k: read_record(v) if v else None for k,v in paths.items()}
    if not any(records.values()): return {'status': 'legacy_unverified', 'records': records}
    if not all(records.values()): raise ValueError('Cadeia parcialmente documentada. Recrie os produtos; não troque direção sobre máscara antiga.')
    n,d,b,s = [records[k] for k in ('network','direction','basin','stream')]
    if (n['role'],d['role'],b['role'],s['role']) != ('stream_vector','direction','basin','stream_raster'):
        raise ValueError('Tipos de produtos incompatíveis.')
    if not (n['run_id'] == d['run_id'] == s['run_id']) or d['algorithm'] != 'grass:r.stream.extract':
        raise ValueError('Rede e direção devem provir da mesma execução de r.stream.extract.')
    if b['inputs']['direction']['sha256'] != d['sha256']:
        raise ValueError('Microbacia delimitada com outra direção. Delimite novamente.')
    return {'status': 'verified_product_pair', 'records': records}

def resolution_plan(path, requested):
    provenance = read_record(path)
    if provenance and provenance['role'] not in ('working_dem', 'prepared_dem'):
        raise ValueError('Reamostre apenas elevação; refaça direção, acumulação e rede após a reamostragem.')
    info = raster_info(path)
    if not math.isfinite(requested) or requested <= 0: raise ValueError('Resolução deve ser positiva e finita.')
    from osgeo import osr
    s = osr.SpatialReference(wkt=info['projection'])
    if not s.IsProjected() or abs(s.GetLinearUnits()-1) > 1e-9: raise ValueError('Reamostragem requer SRC projetado em metros.')
    x,y = info['resolution']
    if requested < max(x,y): raise ValueError('Esta etapa permite apenas reduzir o detalhamento.')
    w,h = max(1,round(info['width']*x/requested)), max(1,round(info['height']*y/requested))
    return {'requested_m': requested, 'width': w, 'height': h,
            'effective_m': [info['width']*x/w,info['height']*y/h], 'source': info,
            'method': 'average', 'extent_policy': 'exact_source_extent',
            'nodata_policy': 'invalidate_any_target_with_source_nodata_overlap', 'limitations': NOTE}

def resample_working(path, output, requested, *, consent=False):
    if consent is not True: raise ValueError('Reamostragem requer consentimento explícito.')
    fresh(output)
    plan = resolution_plan(path, requested)
    from osgeo import gdal
    import numpy as np
    source = gdal.Open(str(path)); b = source.GetRasterBand(1)
    # Translate with explicit dimensions preserves exact extent; average is elevation-only.
    out = gdal.Translate(str(output), source, format='GTiff', width=plan['width'], height=plan['height'],
                         resampleAlg='average', outputType=gdal.GDT_Float64,
                         creationOptions=['COMPRESS=DEFLATE','TILED=YES'])
    if out is None: raise RuntimeError('Falha na reamostragem.')
    ob = out.GetRasterBand(1)
    nd = b.GetNoDataValue()
    if nd is None: nd = float('nan')
    ob.SetNoDataValue(nd)
    # Conservative footprint: no averaging across a hole may fabricate valid coverage.
    sx,sy = source.RasterXSize/plan['width'], source.RasterYSize/plan['height']
    maskband = b.GetMaskBand()
    left = np.floor(np.arange(plan['width'])*sx).astype(int)
    right = np.ceil((np.arange(plan['width'])+1)*sx-1e-10).astype(int)
    for row in range(plan['height']):
        top,bottom = int(math.floor(row*sy)), min(source.RasterYSize,int(math.ceil((row+1)*sy-1e-10)))
        mask = maskband.ReadAsArray(0,top,source.RasterXSize,bottom-top)
        invalid_columns = np.any(mask == 0, axis=0)
        prefix = np.concatenate(([0],np.cumsum(invalid_columns)))
        invalid = prefix[right] > prefix[left]
        values = ob.ReadAsArray(0,row,plan['width'],1)
        values[0,invalid] = nd
        ob.WriteArray(values,0,row)
    # Statistics are stale after resampling; other descriptive metadata are retained.
    metadata = {k:v for k,v in b.GetMetadata().items() if not k.startswith('STATISTICS_')}
    ob.SetMetadata(metadata)
    ob.SetUnitType(b.GetUnitType())
    ob.SetDescription(b.GetDescription())
    if b.GetScale() is not None: ob.SetScale(b.GetScale())
    if b.GetOffset() is not None: ob.SetOffset(b.GetOffset())
    out.FlushCache(); out = None; source = None
    record_product(output,'working_dem','gdal:average',{'source':path},plan)
    return plan
