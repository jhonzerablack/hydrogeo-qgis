"""Read-only raster/vector bridge for strict D8 topology evidence."""
from pathlib import Path
import hashlib

from .topology_d8 import verify_grid_network, EvidenceError
from .drainage_topology import analyze_drainage_topology
from .topology_diagnostics import unavailable


def analyze_d8_network(network, *, direction_path, basin_raster_path,
                       stream_raster_path, outlet, boundary_incomplete, basin_vector_path):
    import numpy as np
    from osgeo import gdal, osr, ogr
    from qgis.core import QgsWkbTypes, Qgis

    sources = {}
    evidence = None
    try:
        if not network.crs().isValid() or network.crs().isGeographic():
            raise EvidenceError('projected_crs_required')
        units = {Qgis.DistanceUnit.Meters: 'm', Qgis.DistanceUnit.Feet: 'ft'}
        unit = units.get(network.crs().mapUnits())
        if unit is None:
            raise EvidenceError('projected_crs_required')
        datasets = []
        for name, path in [('direction', direction_path), ('basin_mask', basin_raster_path),
                           ('stream_raster', stream_raster_path)]:
            if path is None or not Path(path).is_file():
                raise EvidenceError('missing_' + name)
            file = Path(path)
            with file.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            sources[name] = {'path': str(file), 'sha256': digest}
            ds = gdal.Open(str(file), gdal.GA_ReadOnly)
            if ds is None or ds.RasterCount != 1:
                raise EvidenceError('invalid_raster')
            datasets.append(ds)
        direction, basin, streams = datasets
        reference = osr.SpatialReference()
        reference.ImportFromWkt(direction.GetProjection())
        vector_crs = osr.SpatialReference()
        vector_crs.ImportFromWkt(network.crs().toWkt())
        if not reference.IsSame(vector_crs):
            raise EvidenceError('crs_mismatch')
        for ds in datasets[1:]:
            crs = osr.SpatialReference()
            crs.ImportFromWkt(ds.GetProjection())
            if (ds.RasterXSize != direction.RasterXSize or ds.RasterYSize != direction.RasterYSize
                    or ds.GetGeoTransform() != direction.GetGeoTransform() or not crs.IsSame(reference)):
                raise EvidenceError('raster_grid_mismatch')

        def read(ds):
            band = ds.GetRasterBand(1)
            values = band.ReadAsArray()
            valid = (band.GetMaskBand().ReadAsArray() != 0) & np.isfinite(values)
            nd = band.GetNoDataValue()
            if nd is not None:
                valid &= values != nd
            return values, valid

        directions, valid = read(direction)
        basin_values, basin_valid = read(basin)
        stream_values, stream_valid = read(streams)
        vector_ds = ogr.Open(str(basin_vector_path), 0)
        if vector_ds is None or vector_ds.GetLayerCount() != 1:
            raise EvidenceError('invalid_basin_geometry')
        burned = gdal.GetDriverByName('MEM').Create('', direction.RasterXSize, direction.RasterYSize, 1, gdal.GDT_Byte)
        burned.SetGeoTransform(direction.GetGeoTransform())
        burned.SetProjection(direction.GetProjection())
        if gdal.RasterizeLayer(burned, [1], vector_ds.GetLayer(0), burn_values=[1]) != 0:
            raise EvidenceError('basin_vector_mask_mismatch')
        if not np.array_equal(burned.ReadAsArray() > 0, basin_valid & (basin_values > 0)):
            raise EvidenceError('basin_vector_mask_mismatch')
        basin_cells = set(map(tuple, np.argwhere(basin_valid & (basin_values > 0))))
        stream_cells = set(map(tuple, np.argwhere(stream_valid & (stream_values > 0))))
        # Python ints keep strict JSON serializable evidence and feature IDs.
        basin_cells = {(int(r), int(c)) for r, c in basin_cells}
        stream_cells = {(int(r), int(c)) for r, c in stream_cells}
        records = []
        for feature in network.getFeatures():
            geometry = feature.geometry()
            if geometry.isNull() or geometry.isEmpty() or geometry.wkbType() != QgsWkbTypes.Type.LineString:
                raise EvidenceError('unsupported_geometry')
            records.append({'id': str(feature.id()),
                            'coordinates': [[p.x(), p.y()] for p in geometry.asPolyline()]})
        features, evidence = verify_grid_network(
            records, direction=directions, valid=valid, basin_cells=basin_cells,
            stream_cells=stream_cells, geotransform=direction.GetGeoTransform(),
            outlet=outlet, shape=directions.shape)
        if boundary_incomplete is not False:
            raise EvidenceError('basin_may_be_incomplete' if boundary_incomplete is True
                                else 'component_completeness_not_confirmed')
        result = analyze_drainage_topology(
            features, outlets=[{'id': 'outlet_d8', 'coordinate': evidence['outlet_coordinate'],
                                'direction_evidence': evidence['method'],
                                'complete_for_rb': True,
                                'completeness_evidence': evidence['coverage_scope']}],
            snap_tolerance=0, crs={'id': network.crs().authid(), 'projected': True},
            linear_unit=unit, sources=sources)
        result['d8_verification'] = evidence
        return result
    except (EvidenceError, ValueError, RuntimeError, OSError) as exc:
        codes = [str(exc)] if isinstance(exc, EvidenceError) else ['topology_error']
        if boundary_incomplete is True:
            codes.append('basin_may_be_incomplete')
        result = unavailable(*codes, sources=sources, detail=None if isinstance(exc, EvidenceError) else exc)
        if evidence is not None:
            result['d8_verification'] = evidence
        return result
