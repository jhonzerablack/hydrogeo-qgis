from pathlib import Path
from qgis.PyQt.QtWidgets import (
    QAction,
    QDialog,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QTabWidget,
    QWidget,
    QGridLayout,
    QMessageBox,
    QFileDialog,
    QInputDialog,
    QPlainTextEdit,
    QDialogButtonBox,
)
from qgis.PyQt.QtGui import QFont, QIcon
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsRasterBandStats,
    QgsCoordinateTransform, QgsPointXY, Qgis
)
from qgis.gui import QgsMapToolEmitPoint

from .modules.dem_analyzer import DEMAnalyzer
from .modules.terrain import TerrainEngine


class WatershedOutletTool(QgsMapToolEmitPoint):
    """Captura um exutório; Esc cancela sem alterar dados."""
    cancelled = pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.cancelled.emit()
            event.accept()
        else:
            super().keyPressEvent(event)


class HydroGeoDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._watershed_pending = None
        self._outlet_tool = None
        self._previous_map_tool = None
        self._outlet_message = None

        self.setWindowTitle("HydroGeo Tools — v0.8.0")
        self.resize(850, 580)

        self.active_dem_layer = None
        self.active_dem_info = None

        layout = QVBoxLayout(self)

        title = QLabel("HydroGeo Tools")
        font = QFont()
        font.setPointSize(18)
        font.setBold(True)
        title.setFont(font)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        subtitle = QLabel(
            "Recursos Hídricos  Relevo  Hidrologia  "
            "Microbacias  Geotecnologias"
        )
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.dem_status = QLabel(
            "MDT/MDE ATIVO: nenhum MDT/MDE definido"
        )
        self.dem_status.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )
        self.dem_status.setWordWrap(True)
        self.dem_status.setStyleSheet(
            "QLabel { "
            "padding: 8px; "
            "margin-top: 4px; "
            "margin-bottom: 4px; "
            "border: 1px solid #666; "
            "border-radius: 4px; "
            "font-weight: bold; "
            "}"
        )
        layout.addWidget(self.dem_status)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.add_module(
            "Projeto e Dados",
            [
                "Novo projeto",
                "Verificar dados",
                "Importar MDT / MDE",
                "Importar ortofoto",
                "Importar vetores"
            ]
        )

        self.add_module(
            "Relevo",
            [
                "Curvas de nível",
                "Declividade",
                "Hipsometria",
                "Orientação de vertentes",
                "Sombreamento do relevo"
            ]
        )

        self.add_module(
            "Hidrologia",
            [
                "Resolução de trabalho (opcional)",
                "Preparar MDT",
                "Direção de fluxo",
                "Acumulação de fluxo",
                "Rede de drenagem",
                "Delimitar microbacia"
            ]
        )

        self.add_module(
            "Análise",
            [
                "Pontos críticos",
                "Áreas de concentração",
                "Depressões",
                "Potencial de alagamento",
                "Cruzamentos com estradas"
            ]
        )

        self.add_module(
            "Produtos",
            [
                "Gerar mapa",
                "Gerar relatório",
                "Exportar resultados",
                "Pacote da microbacia"
            ]
        )

        status = QLabel(
            "v0.8.0"
        )
        status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(status)

    def add_module(self, name, tools):
        page = QWidget()
        grid = QGridLayout(page)

        for index, tool in enumerate(tools):
            button = QPushButton(tool)
            button.setMinimumHeight(55)
            if name == "Análise":
                button.setEnabled(False)
                button.setToolTip("Recurso planejado para versão futura; indisponível nesta versão.")
            elif tool == "Novo projeto":
                button.setToolTip("Reinicia somente a sessão HydroGeo; mantém o projeto QGIS e todas as camadas.")
            button.clicked.connect(
                lambda checked=False, t=tool: self.tool_clicked(t)
            )

            row = index // 2
            col = index % 2
            grid.addWidget(button, row, col)

        if name == "Análise":
            note = QLabel("Recursos planejados para versão futura — indisponíveis nesta versão.")
            note.setWordWrap(True)
            grid.addWidget(note, (len(tools) + 1) // 2, 0, 1, 2)
        self.tabs.addTab(page, name)

    def tool_clicked(self, tool):
        actions = {"Novo projeto": self.new_hydrogeo_session,
                   "Verificar dados": self.check_project_data,
                   "Importar ortofoto": self.import_orthophoto,
                   "Importar vetores": self.import_vectors}
        if tool in actions:
            actions[tool]()
            return
        if tool == "Importar MDT / MDE":
            self.import_dem()
            return

        if tool == "Resolução de trabalho (opcional)":
            self.resample_working_dem()
            return

        if tool == "Preparar MDT":
            self.prepare_dem()
            return

        if tool == "Direção de fluxo":
            self.create_flow_direction()
            return

        if tool == "Acumulação de fluxo":
            self.create_flow_accumulation()
            return

        if tool == "Rede de drenagem":
            self.create_stream_network()
            return

        if tool == "Delimitar microbacia":
            self.create_watershed()
            return

        if tool == "Gerar mapa":
            self.generate_technical_map()
            return

        if tool == "Pacote da microbacia":
            self.generate_watershed_package()
            return

        if tool == "Gerar relatório":
            self.generate_technical_report()
            return

        if tool == "Exportar resultados":
            self.export_hydrogeo_results()
            return

        if tool == "Curvas de nível":
            self.create_contours()
            return

        if tool == "Declividade":
            self.create_slope()
            return

        if tool == "Hipsometria":
            self.create_hypsometry()
            return

        if tool == "Orientação de vertentes":
            self.create_aspect()
            return

        if tool == "Sombreamento do relevo":
            self.create_hillshade()
            return

        QMessageBox.information(
            self,
            "HydroGeo Tools",
            f"Módulo '{tool}' preparado para implementação."
        )

    def new_hydrogeo_session(self):
        answer = QMessageBox.question(self, "Novo projeto HydroGeo",
            "Reiniciar a sessão HydroGeo e cancelar a seleção de exutório pendente?\n"
            "O MDT ativo será desmarcado. O projeto QGIS, todas as camadas e arquivos serão preservados.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._finish_watershed_pick(show=False)
        self.active_dem_layer = None
        self.active_dem_info = None
        self.dem_status.setText("MDT/MDE ATIVO: nenhum MDT/MDE definido")

    def check_project_data(self):
        from .modules.project_data import inspect_layer
        project = QgsProject.instance()
        layers = list(project.mapLayers().values())
        active = self.active_dem_layer
        lines = []
        if active is None:
            lines.append("AVISO — Nenhum MDT/MDE ativo definido.")
        elif not any(layer is active for layer in layers):
            layers.insert(0, active)
        for layer in layers:
            try:
                lines.append("\n" + layer.name())
                lines.extend(status + " — " + message for status, message in inspect_layer(layer, layer is active))
            except Exception as error:
                lines.append("ERRO — Camada indisponível: " + str(error))
        if not layers:
            lines.append("AVISO — Nenhuma camada para verificar.")
        self._show_scrollable_message("Verificar dados — sem recalcular hidrologia", "\n".join(lines))

    def _publish_imports(self, paths, raster=False):
        from .modules.project_data import load_inputs
        project = QgsProject.instance()
        before = set(project.mapLayers())
        dirty = project.isDirty()
        try:
            layers = load_inputs(paths, raster)
            added = project.addMapLayers(layers)
            if len(added) != len(layers):
                raise ValueError("Não foi possível carregar todas as camadas selecionadas.")
        except Exception as error:
            for layer_id in set(project.mapLayers()) - before:
                project.removeMapLayer(layer_id)
            project.setDirty(dirty)
            QMessageBox.critical(self, "Importar dados", "Importação cancelada; fontes preservadas.\n" + str(error))
            return
        QMessageBox.information(self, "Importar dados", f"{len(layers)} camada(s) carregada(s), sem alterar os arquivos.\n"
            "O MDT/MDE ativo foi preservado. Use Verificar dados para consultar avisos e proveniência.")

    def import_orthophoto(self):
        path, _ = QFileDialog.getOpenFileName(self, "Importar ortofoto", "",
            "Raster (*.tif *.tiff *.vrt *.img *.jp2 *.jpg *.jpeg *.png);;Todos os arquivos (*.*)")
        if path:
            self._publish_imports([path], raster=True)

    def import_vectors(self):
        from qgis.core import QgsProviderRegistry
        paths, _ = QFileDialog.getOpenFileNames(self, "Importar vetores", "",
            QgsProviderRegistry.instance().fileVectorFilters())
        if paths:
            self._publish_imports(paths)

    def generate_watershed_package(self):
        title = "Pacote da microbacia - v0.8.0"
        diagnostic, _ = QFileDialog.getOpenFileName(
            self, "Selecionar diagnóstico da microbacia", "", "Diagnóstico HydroGeo (*.json)")
        if not diagnostic:
            return
        from .modules.watershed_package import generate_package, default_package_name
        destination, _ = QFileDialog.getSaveFileName(
            self, "Salvar pacote da microbacia", str(Path(diagnostic).parent / default_package_name(diagnostic)),
            "Pacote ZIP (*.zip)")
        if not destination:
            return
        if not destination.lower().endswith('.zip'):
            destination += '.zip'
        if Path(destination).exists():
            QMessageBox.warning(self, title, "O pacote já existe. Escolha outro nome para preservar o arquivo.")
            return
        try:
            result = generate_package(diagnostic, destination)
        except Exception as error:
            QMessageBox.critical(self, title, "Pacote não publicado.\n\n" + str(error))
            return
        QMessageBox.information(self, title,
            f"Pacote concluído. Arquivos incluídos: {result['included']}; ausentes: {result['missing']}.\n"
            "Produtos modelados; não substituem verificação de campo.\n\n" + result['zip'])

    def generate_technical_map(self):
        """Exporta PDF e PNG do diagnóstico existente, sem refazer hidrologia."""
        title = "Gerar mapa técnico - v0.8.0"
        diagnostic_path, _ = QFileDialog.getOpenFileName(
            self, "Selecionar diagnóstico da microbacia", "",
            "Diagnóstico HydroGeo (*.json)"
        )
        if not diagnostic_path:
            return
        diagnostic = Path(diagnostic_path)
        default_name = diagnostic.stem.replace("_diagnostico_", "_mapa_") + ".pdf"
        output_path, _ = QFileDialog.getSaveFileName(
            self, "Salvar mapa técnico (PDF e PNG)",
            str(diagnostic.parent / default_name), "Mapa PDF (*.pdf)"
        )
        if not output_path:
            return
        if not output_path.lower().endswith(".pdf"):
            output_path += ".pdf"
        pdf = Path(output_path)
        png = pdf.with_suffix(".png")
        if pdf.exists() or png.exists():
            QMessageBox.warning(
                self, title, "O PDF ou PNG já existe. Escolha outro nome para preservar os arquivos."
            )
            return
        try:
            from .modules.map_generator import generate_map
            result = generate_map(diagnostic_path, pdf, png)
        except Exception as error:
            QMessageBox.critical(self, title, "Não foi possível gerar o mapa.\n\n" + str(error))
            return
        QMessageBox.information(
            self, title,
            "Mapa técnico gerado em PDF e PNG.\n"
            "Nenhum cálculo hidrológico foi refeito.\n"
            "Para manter a escala, imprima o PDF em A4 a 100%.\n\n"
            + result["pdf"] + "\n" + result["png"]
        )

    def generate_technical_report(self):
        """Gera relatório HTML a partir de diagnóstico HydroGeo existente."""

        title = "Gerar relatório técnico"

        diagnostic_path, _ = QFileDialog.getOpenFileName(
            self,
            "Selecionar diagnóstico da microbacia",
            "",
            "Diagnóstico HydroGeo (*.json);;Todos os arquivos (*.*)"
        )

        if not diagnostic_path:
            return

        diagnostic = Path(diagnostic_path)

        default_name = (
            diagnostic.stem
            .replace("_diagnostico_", "_relatorio_")
            + ".html"
        )

        default_path = str(
            diagnostic.parent / default_name
        )

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar relatório técnico",
            default_path,
            "Relatório HTML (*.html)"
        )

        if not output_path:
            return

        if not output_path.lower().endswith(".html"):
            output_path += ".html"

        output = Path(output_path)

        if output.exists():
            QMessageBox.warning(
                self,
                title,
                "O arquivo selecionado já existe.\n\n"
                "Escolha outro nome para preservar o relatório existente."
            )
            return

        try:
            from .modules.technical_report import write_html_report

            result = write_html_report(
                diagnostic_path,
                output_path
            )

            QMessageBox.information(
                self,
                title,
                "Relatório técnico gerado com sucesso.\n\n"
                "Formato: HTML\n"
                "Nenhum cálculo hidrológico foi refeito.\n\n"
                "Arquivo:\n"
                + str(result)
            )

        except Exception as error:
            QMessageBox.critical(
                self,
                title,
                "Não foi possível gerar o relatório técnico.\n\n"
                + str(error)
            )


    def export_hydrogeo_results(self):
        """Exporta produtos associados a um diagnóstico HydroGeo."""

        title = "Exportar resultados"

        diagnostic_path, _ = QFileDialog.getOpenFileName(
            self,
            "Selecionar diagnóstico da microbacia",
            "",
            "Diagnóstico HydroGeo (*.json);;Todos os arquivos (*.*)"
        )

        if not diagnostic_path:
            return

        destination = QFileDialog.getExistingDirectory(
            self,
            "Selecionar pasta de destino da exportação",
            str(Path(diagnostic_path).parent)
        )

        if not destination:
            return

        try:
            from .modules.export_results import export_results

            result = export_results(
                diagnostic_path,
                destination
            )

            QMessageBox.information(
                self,
                title,
                "Exportação concluída com sucesso.\n\n"
                f"Arquivos copiados: {result['copied']}\n"
                f"Arquivos ausentes: {result['missing']}\n\n"
                "Manifesto e SHA-256 foram gerados.\n\n"
                "Pasta:\n"
                + result["export_directory"]
            )

        except Exception as error:
            QMessageBox.critical(
                self,
                title,
                "Não foi possível exportar os resultados.\n\n"
                + str(error)
            )


    def create_aspect(self):
        """Calcula e opcionalmente classifica a orientação de vertentes."""

        if (
            self.active_dem_layer is None
            or not self.active_dem_layer.isValid()
        ):
            QMessageBox.warning(
                self,
                "Orientação de vertentes",
                "Importe e defina um MDT/MDE ativo antes "
                "de calcular a orientação de vertentes."
            )
            return

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar orientação de vertentes",
            "orientacao_vertentes_graus.tif",
            "GeoTIFF (*.tif *.tiff);;"
            "Todos os arquivos (*.*)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(
                self.active_dem_layer
            )

            output_layer = engine.aspect(
                output_path,
                z_factor=1.0
            )

            answer = QMessageBox.question(
                self,
                "Orientação de vertentes",
                "O raster contínuo em graus foi gerado.\n\n"
                "Deseja gerar também o mapa classificado "
                "por direção?\n\n"
                "N   = Norte\n"
                "NE = Nordeste\n"
                "E   = Leste\n"
                "SE = Sudeste\n"
                "S   = Sul\n"
                "SO = Sudoeste\n"
                "O   = Oeste\n"
                "NO = Noroeste",
                QMessageBox.StandardButton.Yes
                | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )

            classified = False
            class_layer = None
            class_path = None

            if answer == QMessageBox.StandardButton.Yes:
                source = Path(output_path)

                class_path = str(
                    source.with_name(
                        source.stem + "_classificada.tif"
                    )
                )

                class_layer = engine.classify_aspect(
                    output_path,
                    class_path
                )

                classified = True

            if classified:
                message = (
                    "Orientação de vertentes processada com sucesso.\n\n"
                    "Raster contínuo:\n"
                    "Unidade: graus (0 a 360°)\n"
                    "Fator Z: 1,0\n"
                    f"Camada: {output_layer.name()}\n"
                    f"Arquivo: {output_path}\n\n"
                    "Mapa classificado:\n"
                    "N  = 337,5-360° e 0-22,5°\n"
                    "NE = 22,5-67,5°\n"
                    "E  = 67,5-112,5°\n"
                    "SE = 112,5-157,5°\n"
                    "S  = 157,5-202,5°\n"
                    "SO = 202,5-247,5°\n"
                    "O  = 247,5-292,5°\n"
                    "NO = 292,5-337,5°\n\n"
                    f"Camada: {class_layer.name()}\n"
                    f"Arquivo: {class_path}\n\n"
                    "O MDT/MDE original não foi alterado."
                )
            else:
                message = (
                    "Orientação de vertentes calculada com sucesso.\n\n"
                    "Produto: orientação contínua em graus\n"
                    "Unidade: graus (0 a 360°)\n"
                    "Fator Z: 1,0\n"
                    f"Camada: {output_layer.name()}\n"
                    f"Arquivo: {output_path}\n\n"
                    "O raster contínuo foi preservado para "
                    "análises posteriores.\n"
                    "O MDT/MDE original não foi alterado."
                )

            QMessageBox.information(
                self,
                "Orientação de vertentes",
                message
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao calcular orientação de vertentes",
                str(exc)
            )

    def create_hillshade(self):
        """Gera o sombreamento do relevo."""

        if (
            self.active_dem_layer is None
            or not self.active_dem_layer.isValid()
        ):
            QMessageBox.warning(
                self,
                "Sombreamento do relevo",
                "Importe e defina um MDT/MDE ativo antes "
                "de gerar o sombreamento do relevo."
            )
            return

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar sombreamento do relevo",
            "sombreamento_relevo.tif",
            "GeoTIFF (*.tif *.tiff);;"
            "Todos os arquivos (*.*)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(
                self.active_dem_layer
            )

            output_layer = engine.hillshade(
                output_path,
                z_factor=1.0,
                azimuth=315.0,
                vertical_angle=45.0
            )

            QMessageBox.information(
                self,
                "Sombreamento do relevo",
                "Sombreamento do relevo gerado com sucesso.\n\n"
                "Método: Hillshade\n"
                "Azimute da iluminação: 315°\n"
                "Elevação da iluminação: 45°\n"
                "Fator Z: 1,0\n"
                f"Camada: {output_layer.name()}\n"
                f"Arquivo: {output_path}\n\n"
                "Este produto representa o relevo por iluminação "
                "simulada e pode ser utilizado como apoio "
                "cartográfico.\n\n"
                "O MDT/MDE original não foi alterado."
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao gerar sombreamento do relevo",
                str(exc)
            )

    def create_hypsometry(self):
        """Gera mapa hipsométrico a partir do MDT/MDE ativo."""

        if (
            self.active_dem_layer is None
            or not self.active_dem_layer.isValid()
        ):
            QMessageBox.warning(
                self,
                "Hipsometria",
                "Importe e defina um MDT/MDE ativo antes "
                "de gerar a hipsometria."
            )
            return

        if not self.active_dem_info:
            QMessageBox.warning(
                self,
                "Hipsometria",
                "Não foi possível obter as estatísticas "
                "do MDT/MDE ativo."
            )
            return

        minimum = float(
            self.active_dem_info["minimum"]
        )

        maximum = float(
            self.active_dem_info["maximum"]
        )

        amplitude = maximum - minimum

        if amplitude <= 10:
            suggested_interval = 1.0
        elif amplitude <= 30:
            suggested_interval = 5.0
        elif amplitude <= 100:
            suggested_interval = 10.0
        elif amplitude <= 300:
            suggested_interval = 25.0
        elif amplitude <= 1000:
            suggested_interval = 50.0
        else:
            suggested_interval = 100.0

        interval, accepted = QInputDialog.getDouble(
            self,
            "Hipsometria",
            (
                f"Elevação mínima: {minimum:.2f}\n"
                f"Elevação máxima: {maximum:.2f}\n"
                f"Amplitude: {amplitude:.2f}\n\n"
                "Unidade vertical não confirmada.\nIntervalo das classes (unidades do raster):"
            ),
            suggested_interval,
            0.01,
            100000.0,
            2
        )

        if not accepted:
            return

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar hipsometria",
            "hipsometria.tif",
            "GeoTIFF (*.tif *.tiff);;"
            "Todos os arquivos (*.*)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(
                self.active_dem_layer
            )

            output_layer, breaks = engine.hypsometry(
                output_path,
                minimum,
                maximum,
                interval
            )

            class_count = len(breaks) - 1

            class_lines = []

            for index in range(class_count):
                class_lines.append(
                    f"{breaks[index]:.2f} a "
                    f"{breaks[index + 1]:.2f}"
                )

            classes_text = "\n".join(class_lines)

            QMessageBox.information(
                self,
                "Hipsometria",
                "Hipsometria gerada com sucesso.\nUnidade vertical não confirmada.\n\n"
                f"Elevação mínima: {minimum:.2f}\n"
                f"Elevação máxima: {maximum:.2f}\n"
                f"Amplitude: {amplitude:.2f}\n"
                f"Intervalo: {interval:.2f}\n"
                f"Número de classes: {class_count}\n\n"
                f"Classes:\n{classes_text}\n\n"
                f"Camada: {output_layer.name()}\n"
                f"Arquivo: {output_path}\n\n"
                "Os valores originais de elevação foram "
                "preservados no produto.\n"
                "O MDT/MDE de origem não foi alterado."
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao gerar hipsometria",
                str(exc)
            )

    def create_slope(self):
        """Gera declividade em graus ou porcentagem."""

        if (
            self.active_dem_layer is None
            or not self.active_dem_layer.isValid()
        ):
            QMessageBox.warning(
                self,
                "Declividade",
                "Importe e defina um MDT/MDE ativo antes "
                "de calcular a declividade."
            )
            return

        options = [
            "Porcentagem (%)",
            "Graus (°)"
        ]

        choice, accepted = QInputDialog.getItem(
            self,
            "Declividade",
            "Unidade do produto:",
            options,
            0,
            False
        )

        if not accepted:
            return

        percent = choice == "Porcentagem (%)"

        if percent:
            default_name = "declividade_percentual.tif"
        else:
            default_name = "declividade_graus.tif"

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar declividade",
            default_name,
            "GeoTIFF (*.tif *.tiff);;"
            "Todos os arquivos (*.*)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(
                self.active_dem_layer
            )

            class_layer = None
            class_path = None
            classified = False

            if percent:
                output_layer = engine.slope_percent(
                    output_path,
                    z_factor=1.0
                )

                unit_text = "porcentagem (%)"

                answer = QMessageBox.question(
                    self,
                    "Classificar declividade",
                    "O raster contínuo em porcentagem foi gerado.\n\n"
                    "Deseja gerar também o mapa de "
                    "declividade classificada?\n\n"
                    "Classes:\n"
                    "1 = 0 a <3 %\n"
                    "2 = 3 a <8 %\n"
                    "3 = 8 a <20 %\n"
                    "4 = 20 a <45 %\n"
                    "5 = 45 a <75 %\n"
                    "6 = 75 % ou mais",
                    QMessageBox.StandardButton.Yes
                    | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )

                if answer == QMessageBox.StandardButton.Yes:
                    source = Path(output_path)

                    class_path = str(
                        source.with_name(
                            source.stem
                            + "_classificada.tif"
                        )
                    )

                    class_layer = (
                        engine.classify_slope_percent(
                            output_path,
                            class_path
                        )
                    )

                    classified = True

            else:
                output_layer = engine.slope_degrees(
                    output_path,
                    z_factor=1.0
                )

                unit_text = "graus (°)"

            if classified:
                message = (
                    "Declividade processada com sucesso.\n\n"
                    "Unidade: porcentagem (%)\n"
                    "Fator Z: 1,0\n\n"
                    f"Raster contínuo: {output_layer.name()}\n"
                    f"Arquivo: {output_path}\n\n"
                    f"Mapa classificado: {class_layer.name()}\n"
                    f"Arquivo: {class_path}\n\n"
                    "Classes: 0 a <3 %, 3 a <8 %, "
                    "8 a <20 %, 20 a <45 %, "
                    "45 a <75 % e 75 % ou mais.\n\n"
                    "O MDT/MDE original não foi alterado."
                )
            else:
                message = (
                    "Declividade calculada com sucesso.\n\n"
                    f"Unidade: {unit_text}\n"
                    "Fator Z: 1,0\n"
                    f"Camada: {output_layer.name()}\n"
                    f"Arquivo: {output_path}\n\n"
                    "O MDT/MDE original não foi alterado."
                )

            QMessageBox.information(
                self,
                "Declividade",
                message
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao calcular declividade",
                str(exc)
            )



    def _show_scrollable_message(self, title, message):
        """Exibe mensagens longas em janela rolável e redimensionável."""

        dialog = QDialog(self)
        dialog.setWindowTitle(title)
        dialog.setModal(True)
        dialog.resize(900, 700)
        dialog.setMinimumSize(650, 450)

        try:
            dialog.setWindowIcon(self.windowIcon())
        except Exception:
            pass

        layout = QVBoxLayout(dialog)

        text_box = QPlainTextEdit(dialog)
        text_box.setReadOnly(True)
        text_box.setPlainText(str(message))
        text_box.setLineWrapMode(
            QPlainTextEdit.LineWrapMode.NoWrap
        )

        layout.addWidget(text_box)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok,
            parent=dialog,
        )

        buttons.accepted.connect(dialog.accept)

        layout.addWidget(buttons)

        dialog.exec()

    def create_watershed(self):
        """Prepara as entradas antes de aguardar um clique no canvas."""
        title = "Delimitar microbacia"
        if self._watershed_pending is not None:
            self.cancel_watershed_pick()
        dem = self.active_dem_layer
        if not isinstance(dem, QgsRasterLayer) or not dem.isValid():
            QMessageBox.warning(self, title, "Importe e defina primeiro o MDT ativo.")
            return
        if not dem.crs().isValid() or dem.crs().mapUnits() != Qgis.DistanceUnit.Meters:
            QMessageBox.warning(self, title, "O MDT deve usar um SRC projetado em metros.")
            return
        if self.iface is None or self.iface.mapCanvas() is None:
            QMessageBox.warning(self, title, "O canvas do QGIS não está disponível.")
            return
        if not self._hydrology_resolution_warning(): return
        inputs = []
        for label in ("acumulação D8 em número de células", "direção D8 (use o par da rede; nunca IDs de rede)"):
            path, _ = QFileDialog.getOpenFileName(
                self, "Selecionar " + label, "", "GeoTIFF (*.tif *.tiff)")
            if not path:
                return
            layer = QgsRasterLayer(path, label)
            if not layer.isValid():
                QMessageBox.warning(self, title, "Não foi possível carregar " + label + ".")
                return
            if layer.crs() != dem.crs() or not TerrainEngine._same_stream_grid(layer, dem):
                QMessageBox.warning(self, title, "A " + label + " deve usar o mesmo SRC e a mesma grade do MDT.")
                return
            inputs.append(layer)
        try:
            from .modules.hydrology_chain import check_snap_inputs
            audit = check_snap_inputs(inputs[1].source(), inputs[0].source(), dem.source())
            if audit['warning']:
                if QMessageBox.question(self, title, audit['warning'] +
                    '\nConfirma que a entrada é direção GRASS D8? IDs 1–8 também podem parecer válidos.',
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes: return
        except Exception as exc:
            QMessageBox.warning(self, title, str(exc))
            return
        radius, accepted = QInputDialog.getDouble(
            self, title, "Raio de busca para ajustar o exutório (m):", 10.0, 0.01, 1000000.0, 2)
        if not accepted:
            return
        vector_path, _ = QFileDialog.getSaveFileName(
            self, "Salvar microbacia em um novo arquivo", "microbacia.gpkg", "GeoPackage (*.gpkg)")
        if not vector_path:
            return
        if not vector_path.lower().endswith(".gpkg"):
            vector_path += ".gpkg"
        raster_path = str(Path(vector_path).with_suffix(".tif"))
        if any(Path(path).exists() for path in (vector_path, raster_path)):
            QMessageBox.warning(self, title, "Escolha um nome novo: o vetor ou o raster de saída já existe.")
            return
        canvas = self.iface.mapCanvas()
        self._watershed_pending = (dem, inputs[0], inputs[1], radius, vector_path, raster_path)
        self._previous_map_tool = canvas.mapTool()
        self._outlet_tool = WatershedOutletTool(canvas)
        self._outlet_tool.canvasClicked.connect(self._watershed_clicked)
        self._outlet_tool.cancelled.connect(self.cancel_watershed_pick)
        self._outlet_tool.deactivated.connect(self._watershed_tool_deactivated)
        self._outlet_message = self.iface.messageBar().pushMessage(
            title, "Clique no exutório. Esc ou botão direito cancela.",
            level=Qgis.MessageLevel.Info, duration=0)
        self.hide()
        canvas.setMapTool(self._outlet_tool)
        canvas.setFocus()

    def _finish_watershed_pick(self, restore=True, show=True):
        tool = self._outlet_tool
        previous = self._previous_map_tool
        self._watershed_pending = None
        self._outlet_tool = None
        self._previous_map_tool = None
        if tool is not None:
            tool.canvasClicked.disconnect(self._watershed_clicked)
            tool.cancelled.disconnect(self.cancel_watershed_pick)
            tool.deactivated.disconnect(self._watershed_tool_deactivated)
            canvas = self.iface.mapCanvas()
            if restore and canvas.mapTool() is tool:
                try:
                    if previous is not None:
                        canvas.setMapTool(previous)
                    else:
                        canvas.unsetMapTool(tool)
                except RuntimeError:
                    canvas.unsetMapTool(tool)
            tool.deleteLater()
        if self._outlet_message is not None:
            self.iface.messageBar().popWidget(self._outlet_message)
            self._outlet_message = None
        if show:
            self.show()
            self.raise_()
            self.activateWindow()

    def cancel_watershed_pick(self):
        self._finish_watershed_pick()

    def _watershed_tool_deactivated(self):
        # Outra ferramenta escolhida pelo usuário deve permanecer ativa.
        self._finish_watershed_pick(restore=False)

    def reject(self):
        self._finish_watershed_pick(show=False)
        super().reject()

    def closeEvent(self, event):
        self._finish_watershed_pick(show=False)
        super().closeEvent(event)

    def _watershed_clicked(self, point, button):
        if button == Qt.MouseButton.RightButton:
            self.cancel_watershed_pick()
            return
        if button != Qt.MouseButton.LeftButton or self._watershed_pending is None:
            return
        dem, accumulation, direction, radius, vector_path, raster_path = self._watershed_pending
        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self._finish_watershed_pick()
        try:
            if not dem.isValid() or not canvas_crs.isValid():
                raise ValueError("MDT ou SRC do canvas inválido; selecione os dados novamente.")
            outlet = QgsPointXY(point)
            if canvas_crs != dem.crs():
                outlet = QgsCoordinateTransform(canvas_crs, dem.crs(), QgsProject.instance()).transform(outlet)
            if any(Path(path).exists() for path in (vector_path, raster_path)):
                raise ValueError("Uma saída já existe. Escolha outro nome para preservar os arquivos.")
            result = TerrainEngine(dem).delimit_watershed_d8(
                accumulation_layer=accumulation, direction_layer=direction,
                outlet_x=outlet.x(), outlet_y=outlet.y(),
                basin_raster_path=raster_path, basin_vector_path=vector_path,
                search_radius_m=radius)
            layer = result["layer"]
            if not layer.isValid():
                raise ValueError("O vetor gerado não é válido.")
            if QgsProject.instance().mapLayer(layer.id()) is None:
                QgsProject.instance().addMapLayer(layer)
            summary = (
                f"Microbacia modelada criada.\n\n"
                f"Área: {result['area_ha']:.4f} ha ({result['area_m2']:.2f} m²)\n"
                f"Perímetro: {result['perimeter_m']:.2f} m\n"
                f"SRC das coordenadas: {dem.crs().authid()} — {dem.crs().description()}\n"
                f"Ponto original: {result['original_outlet_x']:.3f}, {result['original_outlet_y']:.3f}\n"
                f"Ponto ajustado: {result['snapped_outlet_x']:.3f}, {result['snapped_outlet_y']:.3f}\n"
                f"Distância do snap: {result['snap_distance_m']:.3f} m\n"
                f"Raio de busca: {radius:.2f} m\n\n"
                f"Vetor: {vector_path}\nRaster: {raster_path}")
            warning = result.get("boundary_warning")
            # Additive v0.5.0 diagnostics: failure must not hide a valid basin
            # or the validated truncation warning.
            try:
                from .modules.watershed_diagnostics import (
                    diagnose,
                    save_outlets,
                    save_report,
                    summary_text,
                    attach_drainage_metrics
                )
                from .modules.main_channel import (
                    main_channel_modelled,
                    save_main_channel,
                    attach_main_channel,
                )
                from uuid import uuid4

                suffix = uuid4().hex[:10]
                base = Path(vector_path).with_suffix('')

                points_path = (
                    str(base)
                    + '_exutorios_'
                    + suffix
                    + '.gpkg'
                )

                report_path = (
                    str(base)
                    + '_diagnostico_'
                    + suffix
                    + '.json'
                )

                points = save_outlets(
                    dem,
                    accumulation,
                    result,
                    points_path
                )

                summary += (
                    "\nPontos auditáveis: "
                    + points_path
                )

                if QMessageBox.question(
                    self,
                    "Exutório auditável",
                    "Os dois pontos foram salvos. "
                    "Adicionar a camada de ponto clicado "
                    "e ajustado ao projeto?",
                    QMessageBox.StandardButton.Yes
                    | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                ) == QMessageBox.StandardButton.Yes:
                    QgsProject.instance().addMapLayer(points)

                vertical_metres = (
                    QMessageBox.question(
                        self,
                        "Unidade vertical do MDT",
                        "As elevações deste MDT estão em metros?\n"
                        "Confirme pela origem dos dados. "
                        "Sem confirmação, declividade e morfometria altimétrica em metros ficarão pendentes.",
                        QMessageBox.StandardButton.Yes
                        | QMessageBox.StandardButton.No,
                        QMessageBox.StandardButton.No
                    )
                    == QMessageBox.StandardButton.Yes
                )

                diagnostic = diagnose(
                    dem,
                    result,
                    vertical_metres
                )

                from .modules.hydrology_chain import raster_info, read_record, NOTE
                diagnostic['hydrologic_working_data'] = {
                    'dem': dem.source(), 'grid': raster_info(dem.source()),
                    'dem_provenance': read_record(dem.source()),
                    'direction_provenance': read_record(direction.source()),
                    'accumulation_provenance': read_record(accumulation.source()),
                    'snap_policy': 'maximum_accumulation_magnitude_in_radius_not_flow_proof',
                    'limitations': NOTE}
                summary += ('\nResolução de trabalho: '
                    f'{abs(dem.rasterUnitsPerPixelX()):.6g} × {abs(dem.rasterUnitsPerPixelY()):.6g} unidades do SRC.'
                    '\nElevação usada: ' + dem.source() + '\nDireção usada: ' + direction.source() + '\n' + NOTE)
                diagnostic['outlet_points_path'] = points_path
                diagnostic['dem_path'] = dem.source()
                diagnostic['basin_vector_path'] = vector_path
                diagnostic['basin_raster_path'] = raster_path

                from .modules.topology_diagnostics import (
                    attach_topology, analyze_selected_network,
                    diagnostic_summary,
                    summary_text as topology_summary,
                )
                attach_topology(diagnostic)

                calculate_drainage = (
                    QMessageBox.question(
                        self,
                        "Métricas da drenagem modelada",
                        "Deseja calcular o comprimento e a densidade "
                        "da rede de drenagem modelada dentro desta "
                        "microbacia?\n\n"
                        "O resultado depende da rede e do limiar "
                        "utilizados.",
                        QMessageBox.StandardButton.Yes
                        | QMessageBox.StandardButton.No,
                        QMessageBox.StandardButton.No
                    )
                    == QMessageBox.StandardButton.Yes
                )

                if calculate_drainage:
                    drainage_path, _ = QFileDialog.getOpenFileName(
                        self,
                        "Selecionar rede de drenagem modelada",
                        "",
                        "GeoPackage (*.gpkg)"
                    )

                    if drainage_path:
                        attach_topology(diagnostic, analyze_selected_network(
                            vector_path, drainage_path, diagnostic,
                            direction_path=direction.source(),
                            outlet=(result['snapped_outlet_x'], result['snapped_outlet_y']),
                        ))
                        try:
                            attach_drainage_metrics(
                                diagnostic,
                                vector_path,
                                drainage_path,
                                drainage_source=drainage_path
                            )
                            if QMessageBox.question(
                                self,
                                "Canal principal modelado",
                                "Deseja identificar o canal principal modelado?\n\n"
                                "Será escolhido o maior caminho conectado ao exutório "
                                "ajustado, com orientação pela acumulação D8. "
                                "O resultado não representa automaticamente um "
                                "curso d'água observado em campo.",
                                QMessageBox.StandardButton.Yes
                                | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No,
                            ) == QMessageBox.StandardButton.Yes:
                                try:
                                    main_result = main_channel_modelled(
                                        basin_vector_path=vector_path,
                                        drainage_layer=drainage_path,
                                        accumulation_layer=accumulation,
                                        outlet_x=result['snapped_outlet_x'],
                                        outlet_y=result['snapped_outlet_y'],
                                    )
                                    main_path = (
                                        str(base) + '_canal_principal_modelado_'
                                        + uuid4().hex + '.gpkg'
                                    )
                                    main_layer = save_main_channel(
                                        main_result, main_path, layer.crs()
                                    )
                                    attach_main_channel(
                                        diagnostic, main_result, main_path
                                    )
                                    if main_layer is not None:
                                        QgsProject.instance().addMapLayer(main_layer)
                                except Exception as main_error:
                                    diagnostic.setdefault('pending', []).append(
                                        "Canal principal modelado não concluído: "
                                        + str(main_error)
                                    )
                        except Exception as drainage_error:
                            diagnostic.setdefault(
                                "pending",
                                []
                            ).append(
                                "Métricas da drenagem não calculadas: "
                                + str(drainage_error)
                            )

                from .modules.morphometry import attach_morphometry, summary_text as morphometry_summary
                attach_morphometry(
                    diagnostic, vector_path,
                    (result['snapped_outlet_x'], result['snapped_outlet_y']),
                    vertical_metres,
                )
                save_report(
                    diagnostic,
                    report_path
                )

                summary += (
                    diagnostic_summary(diagnostic, summary_text(diagnostic), morphometry_summary(diagnostic))
                    + topology_summary(diagnostic)
                    + "\nRelatório: "
                    + report_path
                )

            except Exception as diagnostic_error:
                summary += (
                    "\n\nDiagnóstico v0.8.0 incompleto: "
                    + str(diagnostic_error)
                )
                summary += (
                    "\nA microbacia foi preservada. "
                    "Verifique as saídas já salvas antes de repetir."
                )

            if warning:
                self._show_scrollable_message(
                    "Microbacia — atenção ao limite",
                    summary + "\n\n" + warning,
                )
            else:
                self._show_scrollable_message(
                    "Delimitar microbacia",
                    summary,
                )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao delimitar microbacia",
                str(exc)
            )

    def create_stream_network(self):
        """Extrai a rede modelada a partir do MDT ativo e acumulacao D8."""
        if not self._hydrology_resolution_warning(): return

        title = "Rede de drenagem modelada"
        if self.active_dem_layer is None or not self.active_dem_layer.isValid():
            QMessageBox.warning(self, title, "Importe primeiro o MDT usado para gerar a acumulação D8.")
            return
        accumulation_path, _ = QFileDialog.getOpenFileName(
            self, "Selecionar acumulação D8 em número de células", "", "GeoTIFF (*.tif *.tiff)")
        if not accumulation_path:
            return
        accumulation = QgsRasterLayer(accumulation_path, "Acumulação D8")
        if not accumulation.isValid():
            QMessageBox.warning(self, title, "Não foi possível carregar a acumulação D8.")
            return
        threshold_help = (
            "Área contribuinte mínima (ha):\n\n"
            "Referências iniciais de interpretação:\n"
            "0,10 ha — detalhada\n"
            "0,25 ha — intermediária\n"
            "0,50 ha — generalizada\n\n"
            "O valor permanece livre e deve ser ajustado conforme "
            "a resolução do MDT, o relevo, a escala e a finalidade "
            "da análise."
        )

        area_ha, accepted = QInputDialog.getDouble(
            self,
            title,
            threshold_help,
            0.10,
            0.0001,
            100000000.0,
            4
        )
        if not accepted:
            return
        vector_path, _ = QFileDialog.getSaveFileName(
            self, "Salvar rede de drenagem em um novo arquivo", "rede_drenagem_modelada.gpkg",
            "GeoPackage (*.gpkg)")
        if not vector_path:
            return
        if not vector_path.lower().endswith(".gpkg"):
            vector_path += ".gpkg"
        raster_path = str(Path(vector_path).with_suffix(".tif"))
        try:
            result = TerrainEngine(self.active_dem_layer).stream_network_d8(
                accumulation_layer=accumulation,
                stream_vector_path=vector_path,
                stream_raster_path=raster_path,
                minimum_contributing_area_m2=area_ha * 10000.0)
            raster = QgsRasterLayer(raster_path, "Rede de drenagem modelada - raster")
            QgsProject.instance().addMapLayer(raster, False)
            QgsProject.instance().layerTreeRoot().addLayer(raster).setItemVisibilityChecked(False)
            QMessageBox.information(
                self, title,
                f"Rede modelada criada.\n\n"
                f"Área solicitada: {result['requested_area_ha']:.4f} ha\n"
                f"Área efetiva: {result['effective_area_ha']:.4f} ha\n"
                f"Limiar: {result['threshold_cells']:,} células\n"
                f"Trechos: {result['feature_count']:,}\n"
                f"Comprimento total: {result['total_length_m']:.2f} m\n\n"
                f"Vetor: {vector_path}\nRaster: {raster_path}\n"
                f"Direção pareada: {result['direction_path']}\n"
                "Use esta direção para uma NOVA delimitação e para a topologia.\n"
                "Acumulação é entrada da extração e critério de snap; não comprova a direção da rede.\n\n"
                "MDT e acumulação D8 original preservados.\n"
                "Rede modelada; conferir com ortofoto e observações de campo.")
        except Exception as exc:
            QMessageBox.critical(self, title, str(exc))

    def create_flow_accumulation(self):
        if not self._hydrology_resolution_warning(): return

        if self.active_dem_layer is None:
            QMessageBox.warning(
                self,
                "Acumulação de fluxo",
                "Importe primeiro o MDT preparado para hidrologia."
            )
            return

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar acumulação de fluxo D8",
            "acumulacao_fluxo_D8.tif",
            "GeoTIFF (*.tif *.tiff)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(self.active_dem_layer)

            result = engine.flow_accumulation_d8(
                output_path
            )

            valid = result["valid_cells"]
            positive = result["positive_cells"]
            negative = result["negative_cells"]
            zero = result["zero_cells"]

            if valid > 0:
                positive_pct = 100.0 * positive / valid
                negative_pct = 100.0 * negative / valid
                zero_pct = 100.0 * zero / valid
            else:
                positive_pct = 0.0
                negative_pct = 0.0
                zero_pct = 0.0

            stats = result["positive_stats"]

            def fmt(value):
                if value is None:
                    return "n/d"
                return f"{value:,.3f}"

            message = (
                "Acumulação de fluxo calculada com sucesso.\n\n"
                "Motor: GRASS r.watershed\n"
                "Método: D8 / Single Flow Direction\n"
                "Tratamento de áreas planas: habilitado\n"
                "Sinal original do GRASS: preservado\n\n"
                f"Células válidas: {valid:,}\n"
                f"Positivas: {positive:,} ({positive_pct:.2f}%)\n"
                f"Negativas: {negative:,} ({negative_pct:.2f}%)\n"
                f"Zero: {zero:,} ({zero_pct:.2f}%)\n\n"
                f"Valor mínimo: {fmt(result['minimum'])}\n"
                f"Valor máximo: {fmt(result['maximum'])}\n\n"
                "DISTRIBUIÇÃO DOS VALORES POSITIVOS\n"
                f"P50: {fmt(stats['p50'])}\n"
                f"P75: {fmt(stats['p75'])}\n"
                f"P90: {fmt(stats['p90'])}\n"
                f"P95: {fmt(stats['p95'])}\n"
                f"P99: {fmt(stats['p99'])}\n"
                f"P99,5: {fmt(stats['p995'])}\n"
                f"P99,9: {fmt(stats['p999'])}\n"
                f"Máximo positivo: {fmt(stats['max'])}\n\n"
                "Os valores negativos foram preservados e não "
                "devem ser interpretados automaticamente como "
                "ausência de fluxo.\n\n"
                "Arquivo:\n"
                + output_path
            )

            QMessageBox.information(
                self,
                "Acumulação de fluxo - D8",
                message
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro - Acumulação de fluxo",
                str(exc)
            )

    def create_flow_direction(self):
        """
        Gera a direcao de fluxo D8/SFD a partir do MDT ativo.
        """
        if not self._hydrology_resolution_warning(): return


        if self.active_dem_layer is None:
            QMessageBox.warning(
                self,
                "Direção de fluxo",
                "Importe primeiro o MDT preparado para hidrologia."
            )
            return

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar direção de fluxo D8",
            "direcao_fluxo_D8.tif",
            "GeoTIFF (*.tif *.tiff)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(
                self.active_dem_layer
            )

            layer = engine.flow_direction_d8(
                output_path
            )

            provider = layer.dataProvider()

            stats = provider.bandStatistics(
                1,
                QgsRasterBandStats.All
            )

            QMessageBox.information(
                self,
                "Direção de fluxo - D8",
                "Direção de fluxo calculada com sucesso.\n\n"
                "Motor: GRASS r.watershed\n"
                "Método: D8 / Single Flow Direction\n"
                "Tratamento de áreas planas: habilitado\n"
                "Vizinhança: 8 células\n\n"
                f"Valor mínimo: {stats.minimumValue:.0f}\n"
                f"Valor máximo: {stats.maximumValue:.0f}\n\n"
                "O raster representa direções modeladas de fluxo "
                "a partir do MDT ativo.\n\n"
                f"Arquivo:\n{output_path}"
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Direção de fluxo - erro",
                str(exc)
            )

    def _hydrology_resolution_warning(self):
        dem = self.active_dem_layer
        if dem is None or not dem.isValid():
            QMessageBox.warning(self, 'Hidrologia', 'Defina primeiro o MDT/MDE ativo.')
            return False
        cells = dem.width() * dem.height()
        fine = (dem.crs().mapUnits() == Qgis.DistanceUnit.Meters and
                min(abs(dem.rasterUnitsPerPixelX()), abs(dem.rasterUnitsPerPixelY())) < 0.25)
        if fine or cells > 10000000:
            answer = QMessageBox.question(self, 'Resolução hidrológica',
                f'Raster com {cells:,} células; resolução '
                f'{abs(dem.rasterUnitsPerPixelX()):.4g} × {abs(dem.rasterUnitsPerPixelY()):.4g} unidades do SRC.\n'
                'O processamento síncrono pode demorar e bloquear a interface.\n'
                'Para ensaio com MDS muito fino, considere 0,25 m ou 0,50 m na etapa opcional. '
                'Esses valores não são uma validação hidrológica. Reamostrar MDS não o transforma em MDT.\n'
                'Continuar na resolução atual?', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            return answer == QMessageBox.StandardButton.Yes
        return True

    def resample_working_dem(self):
        from .modules.hydrology_chain import resolution_plan, resample_working, NOTE
        dem = self.active_dem_layer
        if dem is None or not dem.isValid():
            QMessageBox.warning(self, 'Resolução de trabalho', 'Defina primeiro o MDT/MDE ativo.')
            return
        resolution, ok = QInputDialog.getDouble(self, 'Resolução de trabalho',
            'Resolução solicitada em metros (sugestões exploratórias: 0,25 ou 0,50):', 0.25, 0.001, 10000, 3)
        if not ok: return
        try:
            plan = resolution_plan(dem.source(), resolution)
            effective = plan['effective_m']
            answer = QMessageBox.question(self, 'Confirmar reamostragem opcional',
                f'Média dos valores de elevação. Extensão e SRC preservados.\n'
                f'Grade: {plan["width"]} × {plan["height"]}; resolução efetiva '
                f'{effective[0]:.9g} × {effective[1]:.9g} m.\n'
                'Células que sobrepõem NoData continuarão sem dado (cobertura conservadora).\n'
                + NOTE + '\nCriar uma cópia nesta resolução?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes: return
            output, _ = QFileDialog.getSaveFileName(self, 'Salvar cópia de trabalho', 'elevacao_trabalho.tif', 'GeoTIFF (*.tif)')
            if not output: return
            if not output.lower().endswith('.tif'): output += '.tif'
            resample_working(dem.source(), output, resolution, consent=True)
            layer = QgsRasterLayer(output, 'Elevação — resolução de trabalho')
            QgsProject.instance().addMapLayer(layer)
            self.active_dem_layer = layer
            self.active_dem_info = None
            self.dem_status.setText('MDT/MDE ATIVO: ' + output)
            QMessageBox.information(self, 'Resolução de trabalho',
                'Cópia criada e definida como elevação ativa. Agora prepare este raster e refaça toda a cadeia.\n' + NOTE)
        except Exception as exc:
            QMessageBox.critical(self, 'Resolução de trabalho', str(exc))

    def prepare_dem(self):
        """Gera e audita um MDT derivado preparado para hidrologia."""
        if not self._hydrology_resolution_warning(): return


        if self.active_dem_layer is None:
            QMessageBox.warning(
                self,
                "Preparar MDT",
                "Importe primeiro um MDT/MDE em Projeto e Dados."
            )
            return

        QMessageBox.information(
            self,
            "Preparar MDT",
            "O MDT original sera preservado.\n\n"
            "O HydroGeo Tools criara um novo raster derivado e "
            "preenchera depressoes com o metodo Wang & Liu.\n\n"
            "Apos o processamento, o resultado sera comparado "
            "automaticamente com o MDT original.\n\n"
            "Nesta etapa:\n"
            "- declividade minima: 0 grau;\n"
            "- NoData nao sera interpolado automaticamente;\n"
            "- o arquivo original nao sera sobrescrito."
        )

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar MDT preparado para hidrologia",
            "mdt_preparado_hidrologia.tif",
            "GeoTIFF (*.tif *.tiff)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(self.active_dem_layer)

            layer = engine.prepare_hydrologic_dem(
                output_path,
                min_slope=0.0
            )

            if QMessageBox.question(self, 'Usar MDT preparado',
                'Definir o MDT preparado como ativo para gerar direção, acumulação e rede?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes) == QMessageBox.StandardButton.Yes:
                self.active_dem_layer = layer
                self.active_dem_info = None
                self.dem_status.setText('MDT/MDE ATIVO: ' + layer.source())

            output_file = Path(output_path)

            difference_path = str(
                output_file.with_name(
                    output_file.stem + "_correcoes.tif"
                )
            )

            audit = engine.hydrologic_dem_difference(
                layer,
                difference_path
            )

            minimum = audit["minimum"]
            maximum = audit["maximum"]
            mean = audit["mean"]
            stddev = audit["stddev"]

            valid_cells = audit["valid_cells"]
            pixel_area = audit["pixel_area_m2"]
            changed_cells = audit["changed_cells"]
            changed_area_m2 = audit["changed_area_m2"]
            changed_area_ha = audit["changed_area_ha"]
            changed_percent = audit["changed_percent"]
            negative_cells = audit["negative_cells"]
            classes = audit["classes"]

            valid_area_m2 = valid_cells * pixel_area
            valid_area_ha = valid_area_m2 / 10000.0

            class_lines = []

            for item in classes:
                class_lines.append(
                    f'{item["label"]}: '
                    f'{item["count"]} celulas | '
                    f'{item["area_m2"]:.2f} m2 | '
                    f'{item["area_ha"]:.4f} ha | '
                    f'{item["percent"]:.2f}%'
                )

            classes_text = "\n".join(class_lines)

            if negative_cells == 0:
                negative_text = (
                    "Alteracoes negativas relevantes: nenhuma"
                )
            else:
                negative_text = (
                    "ATENCAO - alteracoes negativas relevantes: "
                    f"{negative_cells} celulas"
                )

            QMessageBox.information(
                self,
                "Preparar MDT - diagnostico",
                "MDT preparado e auditado com sucesso.\n\n"
                "Metodo: Wang & Liu\n"
                "Declividade minima: 0 grau\n"
                "NoData: preservado\n"
                "MDT original: preservado\n\n"

                "DIAGNOSTICO DAS CORRECOES\n"
                f"Alteracao minima: {minimum:.4f} m\n"
                f"Alteracao maxima: {maximum:.4f} m\n"
                f"Alteracao media: {mean:.4f} m\n"
                f"Desvio-padrao: {stddev:.4f} m\n\n"

                "AREA ANALISADA\n"
                f"Celulas validas: {valid_cells}\n"
                f"Area valida: {valid_area_m2:.2f} m2 "
                f"({valid_area_ha:.4f} ha)\n"
                f"Area corrigida (> 1 mm): "
                f"{changed_area_m2:.2f} m2 "
                f"({changed_area_ha:.4f} ha)\n"
                f"Celulas corrigidas: {changed_cells}\n"
                f"Percentual corrigido: {changed_percent:.2f}%\n\n"

                "CORRECOES POR FAIXA\n"
                f"{classes_text}\n\n"

                f"{negative_text}\n\n"

                "Observacao: alteracoes de ate 1 mm sao tratadas "
                "como sem alteracao para evitar ruido numerico.\n\n"

                f"MDT preparado:\n{output_path}\n\n"
                f"Raster de correcoes:\n{difference_path}"
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao preparar MDT",
                str(exc)
            )

    def create_contours(self):
        """Gera curvas de nivel tecnicas ou cartograficas."""

        if (
            self.active_dem_layer is None
            or not self.active_dem_layer.isValid()
        ):
            QMessageBox.warning(
                self,
                "Curvas de nivel",
                "Importe e defina um MDT/MDE ativo antes "
                "de gerar as curvas de nivel."
            )
            return

        suggested_interval = 1.0

        if self.active_dem_info:
            pixel_size = (
                abs(self.active_dem_info["pixel_x"])
                + abs(self.active_dem_info["pixel_y"])
            ) / 2.0

            if pixel_size >= 10:
                suggested_interval = 10.0
            elif pixel_size >= 5:
                suggested_interval = 5.0
            elif pixel_size >= 2:
                suggested_interval = 2.0
            elif pixel_size >= 1:
                suggested_interval = 1.0
            else:
                suggested_interval = 1.0

        interval, accepted = QInputDialog.getDouble(
            self,
            "Curvas de nivel",
            "Equidistancia vertical (m):",
            suggested_interval,
            0.01,
            10000.0,
            2
        )

        if not accepted:
            return

        product_type, accepted = QInputDialog.getItem(
            self,
            "Curvas de nivel",
            "Tipo de produto:",
            [
                "Tecnicas - analise e medicao",
                "Cartograficas - mapas e relatorios"
            ],
            0,
            False
        )

        if not accepted:
            return

        is_cartographic = product_type.startswith("Cartograficas")

        default_name = (
            "curvas_nivel_cartograficas.gpkg"
            if is_cartographic
            else "curvas_nivel_tecnicas.gpkg"
        )

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar curvas de nivel",
            default_name,
            "GeoPackage (*.gpkg);;"
            "Shapefile (*.shp);;"
            "Todos os arquivos (*.*)"
        )

        if not output_path:
            return

        try:
            engine = TerrainEngine(
                self.active_dem_layer
            )

            if not is_cartographic:
                output_layer = engine.contours(
                    output_path,
                    interval=interval,
                    field_name="ELEV"
                )

                QMessageBox.information(
                    self,
                    "Curvas de nivel",
                    "Curvas tecnicas geradas com sucesso.\n\n"
                    f"Equidistancia: {interval:g} m\n"
                    f"Camada: {output_layer.name()}\n"
                    f"Arquivo: {output_path}\n\n"
                    "A geometria foi derivada diretamente do MDT/MDE."
                )
                return

            output = Path(output_path)
            technical_path = str(
                output.with_name(
                    output.stem + "_base_tecnica" + output.suffix
                )
            )

            technical_layer = engine.contours(
                technical_path,
                interval=interval,
                field_name="ELEV"
            )

            cartographic_layer = engine.cartographic_contours(
                technical_layer,
                output_path,
                interval=interval,
                threshold=5.0,
                iterations=1
            )

            QMessageBox.information(
                self,
                "Curvas de nivel",
                "Curvas cartograficas geradas com sucesso.\n\n"
                f"Equidistancia: {interval:g} m\n"
                "Suavizacao: Chaiken\n"
                "Limiar cartografico: 5 m\n"
                "Iteracoes: 1\n\n"
                f"Base tecnica: {technical_path}\n"
                f"Produto cartografico: {output_path}\n"
                f"Camada: {cartographic_layer.name()}\n\n"
                "A base tecnica foi preservada separadamente."
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao gerar curvas de nivel",
                str(exc)
            )

    def import_dem(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Selecionar MDT / MDE",
            "",
            "Raster (*.tif *.tiff *.vrt *.img);;Todos os arquivos (*.*)"
        )

        if not file_path:
            return

        try:
            analyzer = DEMAnalyzer(file_path)

            if not analyzer.is_valid():
                QMessageBox.critical(
                    self,
                    "HydroGeo Tools",
                    "O arquivo selecionado não é um raster válido."
                )
                return

            result = analyzer.analyze()

            layer = QgsRasterLayer(
                file_path,
                "MDT - " + Path(file_path).stem
            )

            if not layer.isValid():
                raise ValueError(
                    "O raster foi analisado, mas não pôde ser "
                    "adicionado ao projeto QGIS."
                )

            QgsProject.instance().addMapLayer(layer)

            self.active_dem_layer = layer
            self.active_dem_info = result

            resolution = (
                abs(result["pixel_x"]) + abs(result["pixel_y"])
            ) / 2.0

            self.dem_status.setText(
                "MDT/MDE ATIVO: "
                + Path(file_path).stem
                + "\n"
                + result["crs_authid"]
                + " | resolução: "
                + f"{resolution:.2f} {result['map_units']}"
                + " | elevação: "
                + f"{result['minimum']:.2f}"
                + " a "
                + f"{result['maximum']:.2f}"
                + " | amplitude: "
                + f"{result['elevation_range']:.2f}"
                + "\nElevação e amplitude: unidade vertical não confirmada"
            )

            warnings = result["warnings"]

            if warnings:
                warning_text = "\n".join(
                    " " + warning for warning in warnings
                )
            else:
                warning_text = "Nenhum alerta básico identificado."

            if result["nodata_defined"]:
                nodata_text = str(result["nodata_value"])
            else:
                nodata_text = "Não definido"

            message = (
                "MDT / MDE carregado com sucesso.\n\n"
                "DIAGNÓSTICO DO RASTER\n\n"
                f"SRC: {result['crs_authid']}\n"
                f"Descrição: {result['crs_description']}\n"
                f"Unidades horizontais: {result['map_units']}\n"
                "Unidade vertical: não confirmada; consulte a origem do MDT.\n\n"
                f"Dimensões: {result['width']} x "
                f"{result['height']} pixels\n"
                f"Pixel X: {result['pixel_x']:.4f}\n"
                f"Pixel Y: {result['pixel_y']:.4f}\n"
                f"Bandas: {result['band_count']}\n\n"
                f"Elevação mínima: {result['minimum']:.3f}\n"
                f"Elevação máxima: {result['maximum']:.3f}\n"
                f"Elevação média: {result['mean']:.3f}\n"
                f"Desvio padrão: {result['stddev']:.3f}\n"
                f"Amplitude altimétrica: "
                f"{result['elevation_range']:.3f}\n\n"
                f"NoData: {nodata_text}\n\n"
                "ALERTAS\n"
                f"{warning_text}"
            )

            QMessageBox.information(
                self,
                "Diagnóstico MDT / MDE",
                message
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Erro ao analisar MDT / MDE",
                str(exc)
            )

class HydroGeoTools:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction(
            QIcon(
                str(
                    Path(__file__).parent
                    / "icon.png"
                )
            ),
            "HydroGeo Tools",
            self.iface.mainWindow()
        )

        self.action.setToolTip(
            "Ferramentas para recursos hídricos e geotecnologias"
        )

        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu(
            "&HydroGeo Tools",
            self.action
        )

        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.dialog is not None:
            self.dialog.close()
        if self.action:
            self.iface.removePluginMenu(
                "&HydroGeo Tools",
                self.action
            )

            self.iface.removeToolBarIcon(self.action)

    def run(self):
        if self.dialog is None:
            self.dialog = HydroGeoDialog(
                self.iface,
                self.iface.mainWindow()
            )

        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
