"""Isolated QGIS adapter, synthetic validation only; not wired to the plugin UI."""
from .drainage_topology import analyze_drainage_topology


def analyze_layer(layer, *, id_field, outlets, snap_tolerance, sources=None):
    """Read a projected singlepart line layer without editing or transforming it.

    Stable IDs come from a required attribute, never provider iteration order.
    Multipart/curved/3D/empty geometries are rejected, not silently flattened.
    Explicit noding is a caller precondition; core detects unresolved junctions.
    """
    from qgis.core import QgsWkbTypes, Qgis

    if not layer.isValid():
        raise ValueError('invalid_layer')
    if layer.fields().indexFromName(id_field) < 0:
        raise ValueError('missing_stable_id_field')
    crs=layer.crs()
    if not crs.isValid() or crs.isGeographic():
        raise ValueError('projected_crs_required')
    units={Qgis.DistanceUnit.Meters:'m', Qgis.DistanceUnit.Feet:'ft'}
    unit=units.get(crs.mapUnits())
    if unit is None:
        raise ValueError('unknown_linear_unit')
    records=[]
    for feature in layer.getFeatures():
        geometry=feature.geometry()
        if geometry.isNull() or geometry.isEmpty():
            raise ValueError('empty_geometry')
        if QgsWkbTypes.isMultiType(geometry.wkbType()):
            raise ValueError('multipart_requires_explicit_preparation')
        if geometry.wkbType() != QgsWkbTypes.Type.LineString:
            raise ValueError('only_2d_straight_linestring_supported')
        fid=feature[id_field]
        if not isinstance(fid,str) or not fid.strip():
            raise ValueError('stable_string_id_required')
        records.append({'id':fid,'coordinates':[[p.x(),p.y()] for p in geometry.asPolyline()]})
    result=analyze_drainage_topology(records,outlets=outlets,snap_tolerance=snap_tolerance,
                                   crs={'id':crs.authid() or crs.toWkt(),'projected':True},
                                   linear_unit=unit,sources=sources)
    result['adapter']={'name':'qgis_singlepart_read_only_v1','coordinate_transform':None,
                       'crs_wkt':crs.toWkt(),'id_field':id_field}
    return result
