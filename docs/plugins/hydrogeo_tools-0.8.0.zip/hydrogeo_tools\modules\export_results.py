from __future__ import annotations

from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil


def _sha256(path):
    digest = hashlib.sha256()

    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)

    return digest.hexdigest()


def _load_json(path):
    source = Path(path)

    with source.open("r", encoding="utf-8") as stream:
        data = json.load(stream)

    if not isinstance(data, dict):
        raise ValueError("Diagnóstico JSON inválido.")

    if "morphometry" not in data:
        raise ValueError(
            "O arquivo selecionado não parece ser um diagnóstico HydroGeo completo."
        )

    return data


def _find_first(value, key):
    if isinstance(value, dict):
        if key in value:
            return value[key]

        for child in value.values():
            result = _find_first(child, key)
            if result is not None:
                return result

    elif isinstance(value, list):
        for child in value:
            result = _find_first(child, key)
            if result is not None:
                return result

    return None


def _extract_paths(data):
    found = []

    def add(label, value):
        if not value:
            return

        if isinstance(value, dict):
            value = (
                value.get("uri")
                or value.get("path")
                or value.get("source")
            )

        if not value:
            return

        text = str(value)

        if any(
            item["path"].lower() == text.lower()
            for item in found
        ):
            return

        found.append({
            "label": label,
            "path": text,
        })

    sources = _find_first(data, "sources") or {}

    labels = {
        "direction": "direcao_fluxo_D8",
        "basin_mask": "raster_microbacia",
        "stream_raster": "raster_rede_drenagem_modelada",
        "basin": "microbacia_vetorial",
        "network": "rede_drenagem_modelada",
        "dem_path": "mdt_mde",
        "basin_vector": "microbacia_vetorial",
        "basin_raster_path": "raster_microbacia",
        "drainage_source": "rede_drenagem_modelada",
        "main_channel_path": "canal_principal_modelado",
        "outlet_points_path": "pontos_exutorio",
    }

    if isinstance(sources, dict):
        for name, item in sources.items():
            add(labels.get(name, name), item)

    direct_keys = [
        ("dem_path", "mdt_mde"),
        ("basin_vector_path", "microbacia_vetorial"),
        ("basin_raster_path", "raster_microbacia"),
        ("drainage_source", "rede_drenagem_modelada"),
        ("main_channel_path", "canal_principal_modelado"),
        ("outlet_points_path", "pontos_exutorio"),
    ]

    for key, label in direct_keys:
        add(label, data.get(key))

    working = data.get("hydrologic_working_data") or {}

    if isinstance(working, dict):
        add("mdt_mde", working.get("dem"))

    return found


def export_results(diagnostic_path, destination_root):
    diagnostic = Path(diagnostic_path)
    destination_root = Path(destination_root)

    data = _load_json(diagnostic_path)

    stamp = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")

    base_name = diagnostic.stem
    if "_diagnostico_" in base_name:
        base_name = base_name.split("_diagnostico_", 1)[0]

    export_dir = destination_root / (
        f"HydroGeo_{base_name}_exportacao_{stamp}"
    )

    if export_dir.exists():
        raise FileExistsError(
            "A pasta de exportação já existe: " + str(export_dir)
        )

    export_dir.mkdir(parents=True, exist_ok=False)

    files_dir = export_dir / "arquivos"
    files_dir.mkdir()

    records = []

    diagnostic_copy = export_dir / diagnostic.name
    shutil.copy2(diagnostic, diagnostic_copy)

    records.append({
        "label": "diagnostico_json",
        "source": str(diagnostic),
        "exported": str(diagnostic_copy),
        "status": "copied",
        "sha256": _sha256(diagnostic_copy),
    })

    for item in _extract_paths(data):
        source = Path(item["path"])

        record = {
            "label": item["label"],
            "source": str(source),
            "exported": None,
            "status": None,
            "sha256": None,
        }

        if not source.exists():
            record["status"] = "missing"
            records.append(record)
            continue

        target_name = source.name
        target = files_dir / target_name

        if target.exists():
            prefix = item["label"]
            target = files_dir / (
                prefix + "_" + target_name
            )

        shutil.copy2(source, target)

        record["exported"] = str(target.relative_to(export_dir))
        record["status"] = "copied"
        record["sha256"] = _sha256(target)

        records.append(record)

    manifesto = {
        "schema": "hydrogeo-export-1",
        "created_local": datetime.now().astimezone().isoformat(),
        "diagnostic_source": str(diagnostic),
        "export_directory": str(export_dir),
        "file_count": sum(
            1 for item in records
            if item["status"] == "copied"
        ),
        "missing_count": sum(
            1 for item in records
            if item["status"] == "missing"
        ),
        "files": records,
        "semantics": (
            "Produtos derivados/modelados são exportados sem alterar "
            "os arquivos originais. A exportação não representa "
            "verificação de campo."
        ),
    }

    manifesto_path = export_dir / "manifesto.json"

    with manifesto_path.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as stream:
        json.dump(
            manifesto,
            stream,
            ensure_ascii=False,
            indent=2,
            allow_nan=False,
        )

    hashes_path = export_dir / "SHA256.txt"

    lines = []

    for item in records:
        if item["status"] != "copied":
            continue

        exported = item["exported"]

        if exported == str(diagnostic_copy):
            exported = diagnostic_copy.name

        lines.append(
            item["sha256"] + "  " + str(exported)
        )

    lines.append(
        _sha256(manifesto_path)
        + "  "
        + manifesto_path.name
    )

    hashes_path.write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    return {
        "export_directory": str(export_dir),
        "manifesto": str(manifesto_path),
        "hashes": str(hashes_path),
        "copied": manifesto["file_count"],
        "missing": manifesto["missing_count"],
    }
