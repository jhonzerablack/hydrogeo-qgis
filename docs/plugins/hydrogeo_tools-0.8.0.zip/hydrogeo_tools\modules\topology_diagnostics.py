"""Additive, fail-closed presentation of modeled topology in the preview.

The legacy diagnostic and its three validated calculation modules are untouched.
Real-data direction/completeness evidence must be verified before releasing metrics.
"""
from copy import deepcopy


REASONS = {
    'product_chain_mismatch': 'Produtos de cadeias incompatíveis ou proveniência incompleta; refaça a cadeia e a delimitação.',
    'legacy_provenance_unverified': 'Produtos legados sem proveniência; coerência avaliada apenas pelo verificador D8.',
    'network_not_selected': 'Rede modelada não selecionada.',
    'basin_may_be_incomplete': 'Microbacia toca o limite válido do MDT; cobertura possivelmente incompleta.',
    'component_completeness_not_confirmed': 'Completude da componente não comprovada.',
    'direction_not_verified': 'Direção de escoamento ainda não verificada em toda a rede.',
    'ambiguous_direction': 'Direção ambígua ou exutório terminal não comprovado.',
    'cycle_detected': 'Ciclo ou duplicação na componente.',
    'component_disconnected': 'Rede desconexa: consultar cada componente; não há agregação global.',
    'unresolved_intersection': 'Interseção interna sem conexão topológica comprovada.',
    'overlapping_or_duplicate_geometry': 'Geometrias sobrepostas ou duplicadas.',
    'ambiguous_snap': 'Agrupamento de extremidades ambíguo na tolerância informada.',
    'ambiguous_outlet_match': 'Exutório sem correspondência única na rede.',
    'no_consecutive_order_pair': 'Não existe par de ordens consecutivas para calcular Rb.',
    'invalid_basin_geometry': 'Geometria da microbacia inválida; sem reparo automático para topologia. Execute Verificar validade e Corrigir geometrias em uma cópia; revise limites e conectividade antes de recalcular. Preserve o original.',
    'crs_mismatch': 'Microbacia e rede possuem SRC diferentes.',
    'projected_crs_required': 'Topologia requer SRC projetado e unidade linear conhecida.',
    'empty_network': 'Nenhuma linha da rede foi encontrada na microbacia.',
    'invalid_layer': 'Não foi possível abrir uma das camadas.',
    'unsupported_geometry': 'Geometria não suportada; requer preparação explícita.',
    'topology_error': 'Falha na análise topológica; consultar detalhe técnico no JSON.',
    'unsupported_grid': 'Grade rotacionada ou orientação de eixos não suportada.',
    'vector_not_on_d8_cell_centers': 'A rede vetorial não acompanha os centros das células D8; preparação requer revisão.',
    'vector_outside_d8_grid': 'A rede possui coordenadas fora da grade D8.',
    'vector_segment_not_d8_aligned': 'Trecho vetorial não corresponde a passos cardinais ou diagonais D8.',
    'vector_d8_direction_conflict': 'Trecho vetorial conflita com a direção D8.',
    'd8_nodata': 'Direção D8 sem dado válido na área analisada.',
    'd8_invalid_or_region_exit': 'Direção D8 inválida, depressão ou saída da região.',
    'd8_cycle': 'Ciclo detectado no escoamento D8.',
    'basin_d8_does_not_reach_outlet': 'Há células da microbacia que não chegam ao exutório pelo D8.',
    'basin_mask_omits_d8_contributor': 'Máscara da microbacia omite uma célula contribuinte pelo D8.',
    'outlet_outside_basin_mask': 'Exutório fora da máscara da microbacia.',
    'outlet_not_terminal_d8': 'Exutório não é a saída terminal da microbacia pelo D8.',
    'outlet_missing_from_stream_raster': 'Exutório ausente do raster da rede modelada.',
    'vector_stream_raster_coverage_mismatch': 'Vetor e raster da rede não cobrem as mesmas células na microbacia.',
    'stream_network_incomplete': 'A rede tem lacunas em ligações de jusante exigidas pelo D8.',
    'basin_vector_mask_mismatch': 'Vetor e máscara raster da microbacia não correspondem.',
    'raster_grid_mismatch': 'Os rasters não usam exatamente a mesma grade e SRC.',
    'missing_direction': 'Raster de direção D8 não disponível.',
    'missing_basin_mask': 'Máscara raster da microbacia não disponível.',
    'missing_stream_raster': 'Raster da rede não disponível; a cobertura completa não pode ser comprovada.',
    'invalid_raster': 'Raster inválido ou com número de bandas não suportado.',
    'duplicate_source_id': 'Identificador de origem duplicado.',
    'duplicate_vector_step': 'Passo da rede duplicado no vetor.',
    'network_size_requires_review': 'Rede excede o limite provisório de 5.000 arestas; desempenho requer validação.',
    'per_component_results_only_no_global_aggregation': 'Resultados separados por componente, sem soma ou Rb global.',
    'invalid_coordinates': 'Coordenadas inválidas ou não finitas.',
    'zero_length_piece': 'Trecho de comprimento nulo.',
    'self_intersection': 'Linha com auto-interseção.',
    'invalid_snap_tolerance': 'Tolerância de conexão inválida.',
    'unknown_linear_unit': 'Unidade linear não reconhecida.',
    'invalid_or_duplicate_feature_id': 'Identificador de feição inválido ou duplicado.',
    'empty_or_invalid_line': 'Linha vazia ou inválida.',
    'self_loop': 'Linha retorna ao próprio nó inicial.',
    'duplicate_edge': 'Ligação topológica duplicada.',
    'snap_collapsed_edge': 'A tolerância colapsa uma ligação da rede.',
    'duplicate_edge_after_snap': 'A tolerância produz ligações duplicadas.',
    'invalid_or_duplicate_outlet_id': 'Identificador de exutório inválido ou duplicado.',
}


def unavailable(*reasons, sources=None, detail=None):
    result = {'schema_version': '0.8.0-integration1',
              'product_kind': 'modeled_drainage_network', 'status': 'unavailable',
              'reason_codes': sorted(set(reasons)), 'metrics': None, 'components': [],
              'sources': sources, 'warnings': [],
              'integration_policy': 'verified_direction_and_completeness_required'}
    if detail:
        result['technical_detail'] = str(detail)
    return result


def attach_topology(diagnostic, topology=None):
    """Attach an independent result, never mutate any existing diagnostic value.

    In this integration incomplete components have no published metrics, even
    though the isolated core supports structural counts for incomplete trees.
    """
    result = deepcopy(topology) if topology is not None else unavailable('network_not_selected')
    result['integration_policy'] = 'verified_direction_and_completeness_required'
    result['legacy_namespace_note'] = ('Campos modelled_channels/modelled_headwaters/modelled_confluences '
        'em morphometry são reservas históricas v0.7.0. Consultar drainage_topology para a análise v0.8.0.')
    suppressed = False
    for component in result.get('components', []):
        declarations = component.get('outlet_declarations', [])
        complete = (len(declarations) == 1
                    and declarations[0].get('complete_for_rb') is True
                    and bool(declarations[0].get('completeness_evidence')))
        if component.get('status') == 'available' and not complete:
            suppressed = True
            component.update(status='unavailable', metrics=None,
                             reason_codes=['component_completeness_not_confirmed'])
            component['bifurcation_ratios'] = {
                'status': 'unavailable', 'values': None,
                'reason_codes': ['component_completeness_not_confirmed']}
    if suppressed:
        result.update(status='unavailable', metrics=None)
        result['reason_codes'] = sorted(set(result.get('reason_codes', [])
                                           + ['component_completeness_not_confirmed']))
    diagnostic['drainage_topology'] = result
    return diagnostic


def _reasons(codes):
    return '; '.join(REASONS.get(code, 'Indisponibilidade técnica: ' + str(code)) for code in codes)


def diagnostic_summary(diagnostic, legacy_text, morphometry_text):
    """Clarify legacy placeholder wording only in presentation, preserving JSON."""
    text = legacy_text.replace('Canal principal: pendente de implementação e validação.',
                               'Canal principal modelado: não calculado nesta execução.')
    omitted = ('Número de canais modelados:', 'Cabeceiras modeladas:', 'Confluências modeladas:')
    morphometry = '\n'.join(line for line in morphometry_text.split('\n')
                           if not line.startswith(omitted))
    morphometry = morphometry.replace('Morfometria v0.7.0', 'Morfometria — métodos validados v0.7.0')
    return text + morphometry


def summary_text(diagnostic):
    result = diagnostic.get('drainage_topology')
    if result is None:
        return ''
    lines = ['', '', 'Topologia da rede de drenagem modelada — v0.8.0']
    if result['status'] != 'available':
        lines.append('Resultado global indisponível: ' + _reasons(result.get('reason_codes', [])))
    for i, component in enumerate(result.get('components', []), 1):
        lines.append('Componente ' + str(component.get('id', i)))
        metrics = component.get('metrics')
        if component.get('status') != 'available' or metrics is None:
            lines.append('Indisponível: ' + _reasons(component.get('reason_codes', [])))
            continue
        lines.extend([
            'Cabeceiras modeladas: ' + str(metrics['modeled_headwater_count']),
            'Confluências modeladas: ' + str(metrics['modeled_confluence_count']),
            'Segmentos topológicos: ' + str(metrics['topological_segments']['count']),
            'Canais contínuos por ordem de Strahler: ' + ', '.join(
                str(k) + ': ' + str(v) for k, v in metrics['strahler_streams']['counts_by_order'].items()),
            'Maior ordem de Strahler modelada: ' + str(metrics['max_strahler_order']),
        ])
        rb = component['bifurcation_ratios']
        if rb['status'] == 'available':
            lines.append('Rb por canais contínuos (adimensional): ' + ', '.join(
                'Rb' + str(k) + '=' + format(v, '.6g') for k, v in rb['values'].items()))
        else:
            lines.append('Rb indisponível: ' + _reasons(rb.get('reason_codes', [])))
    if result.get('warnings'):
        lines.append('Avisos: ' + _reasons(result['warnings']))
    lines.append('Resultados modelados; não constituem verificação de campo.')
    return '\n'.join(lines)


def analyze_selected_network(basin_vector_path, drainage_layer, diagnostic, *,
                             direction_path=None, outlet=None, stream_raster_path=None):
    """Read-only preflight. Never equate a main-channel result with flow proof.

    No automatic repair or spatial snapping is performed. The optional D8
    verifier requires full raster/vector agreement before releasing results.
    """
    from pathlib import Path
    import hashlib
    from qgis.core import QgsVectorLayer, QgsWkbTypes

    def source(layer):
        path = layer.source()
        file = Path(path.split('|')[0])
        return {'uri': path, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()
                if file.is_file() else None, 'crs': layer.crs().authid()}

    sources = {}
    try:
        basin = QgsVectorLayer(str(basin_vector_path), 'Microbacia modelada', 'ogr')
        network = (QgsVectorLayer(str(drainage_layer), 'Rede modelada', 'ogr')
                   if isinstance(drainage_layer, (str, Path)) else drainage_layer)
        if network is None or not basin.isValid() or not network.isValid():
            return unavailable('invalid_layer')
        sources = {'basin': source(basin), 'network': source(network)}
        reasons = ['direction_not_verified', 'component_completeness_not_confirmed']
        if diagnostic.get('touches_dem_boundary') is True:
            reasons.append('basin_may_be_incomplete')
        if basin.crs() != network.crs():
            reasons.append('crs_mismatch')
        if not network.crs().isValid() or network.crs().isGeographic():
            reasons.append('projected_crs_required')
        geometries = [f.geometry() for f in basin.getFeatures()]
        if not geometries or any(g.isEmpty() or not g.isGeosValid() for g in geometries):
            reasons.append('invalid_basin_geometry')
        count = 0
        for feature in network.getFeatures():
            geometry = feature.geometry()
            if geometry.isEmpty() or QgsWkbTypes.flatType(geometry.wkbType()) != QgsWkbTypes.Type.LineString:
                reasons.append('unsupported_geometry')
            count += 1
        if not count:
            reasons.append('empty_network')
        if direction_path is not None and outlet is not None:
            from .topology_d8_qgis import analyze_d8_network
            if stream_raster_path is None:
                stream_raster_path = str(Path(network.source().split('|')[0]).with_suffix('.tif'))
            from .hydrology_chain import check_topology_chain
            try:
                chain = check_topology_chain(network.source(), direction_path,
                    diagnostic.get('basin_raster_path'), stream_raster_path)
            except (ValueError, KeyError, OSError) as exc:
                return unavailable('product_chain_mismatch', sources=sources, detail=exc)
            checked = analyze_d8_network(
                network, direction_path=direction_path,
                basin_raster_path=diagnostic.get('basin_raster_path'),
                stream_raster_path=stream_raster_path, outlet=outlet,
                boundary_incomplete=diagnostic.get('touches_dem_boundary'),
                basin_vector_path=basin_vector_path)
            checked['hydrologic_chain'] = chain
            if chain['status'] == 'legacy_unverified':
                checked.setdefault('warnings', []).append('legacy_provenance_unverified')
            checked.setdefault('sources', {}).update(sources)
            fatal = set(reasons) - {'direction_not_verified', 'component_completeness_not_confirmed',
                                    'basin_may_be_incomplete'}
            if fatal:
                # Preserve evidence only; do not publish metrics behind a failed geometry gate.
                rejected = unavailable(*sorted(fatal | set(checked.get('reason_codes', []))),
                                       sources=checked['sources'])
                rejected['hydrologic_chain'] = chain
                if 'd8_verification' in checked:
                    rejected['d8_verification'] = checked['d8_verification']
                return rejected
            return checked
        result = unavailable(*reasons, sources=sources)
        result['preflight'] = {'network_source_features': count,
                               'scope': 'source_layer_not_basin_topological_count',
                               'original_data_modified': False,
                               'direction_evidence': None, 'completeness_evidence': None}
        return result
    except Exception as exc:
        return unavailable('topology_error', sources=sources, detail=exc)
