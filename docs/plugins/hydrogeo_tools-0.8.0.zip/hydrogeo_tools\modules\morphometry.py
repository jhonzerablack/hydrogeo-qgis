"""Auditable planar morphometry, v0.7.0. No empirical runoff prediction.

A [m²], P [m], L [m] = max Euclidean distance from adjusted outlet to
outer-boundary vertices. Ff=A/L²; Kc=P/(2*sqrt(pi*A)); Ic=4*pi*A/P²;
H=zmax-zmin [m]; Rr=H/L [m/m]; Dd=1000*network_length_m/A [km/km²].
L is an outlet-to-divide straight axis, NOT a flow path or channel length.
Kc uses the exact circle constant, not the rounded coefficient 0.28.
"""
import hashlib
import math
from pathlib import Path


def shape_indices(area_m2, perimeter_m, axial_length_m):
    """Pure SI calculation; reject missing, nonfinite and nonpositive input."""
    a, p, length = map(float, (area_m2, perimeter_m, axial_length_m))
    if not all(math.isfinite(x) and x > 0 for x in (a, p, length)):
        raise ValueError('Área, perímetro e comprimento axial devem ser positivos e finitos.')
    return dict(form_factor=a / length**2,
                compactness_coefficient=p / (2 * math.sqrt(math.pi * a)),
                circularity_index=4 * math.pi * a / p**2)


def _metric(value, unit, formula, source, reason=None, status=None):
    if value is not None and not math.isfinite(value):
        raise ValueError('Resultado não finito: ' + formula)
    return dict(value=value, unit=unit, formula=formula, source=source,
                status=status or ('unavailable' if value is None else 'computed'), reason=reason)


def _source(path):
    """Fingerprint actual input bytes; never write a sidecar to a source."""
    uri = str(path)
    file = Path(uri.split('|')[0])
    info = dict(uri=uri, sha256=None)
    if file.is_file():
        digest = hashlib.sha256()
        with file.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        info['sha256'] = digest.hexdigest()
    return info


def calculate(basin_path, diagnostic, outlet_xy, vertical_metres=False):
    """Read polygon and validated diagnostic; no mutation of either input.

    Elevations inherit the validated raster-mask sampling, including its cell
    counts. Network values inherit the validated clipping routine: feature
    lengths are summed, not deduplicated; counts are features, not channels.
    """
    from qgis.core import QgsVectorLayer, QgsGeometry, QgsPointXY, QgsUnitTypes, QgsWkbTypes
    layer = QgsVectorLayer(str(basin_path), 'morphometry input', 'ogr')
    if not layer.isValid() or not layer.crs().isValid() or layer.crs().isGeographic() or layer.crs().mapUnits() != QgsUnitTypes.DistanceUnit.Meters:
        raise ValueError('Morfometria requer vetor válido e SRC projetado em metros.')
    geometries = []
    geometry_repairs = []

    # Reparo geométrico estritamente temporário.
    # O arquivo original nunca é modificado.
    max_area_change_pct = 0.0001

    for feature in layer.getFeatures():
        g = feature.geometry()

        if (
            g.isNull()
            or g.isEmpty()
            or g.type()
            != QgsWkbTypes.GeometryType.PolygonGeometry
        ):
            raise ValueError(
                'Polígono vazio ou não poligonal.'
            )

        if g.constGet().hasCurvedSegments():
            raise ValueError(
                'Polígono curvo; não será linearizado automaticamente.'
            )

        if not g.isGeosValid():
            original_area = float(g.area())

            if (
                not math.isfinite(original_area)
                or original_area <= 0
            ):
                raise ValueError(
                    'Polígono inválido com área original não utilizável.'
                )

            repaired = g.makeValid()

            if (
                repaired.isNull()
                or repaired.isEmpty()
                or not repaired.isGeosValid()
                or repaired.type()
                != QgsWkbTypes.GeometryType.PolygonGeometry
            ):
                raise ValueError(
                    'Polígono inválido e reparo temporário não confiável.'
                )

            if repaired.constGet().hasCurvedSegments():
                raise ValueError(
                    'Reparo temporário produziu geometria curva.'
                )

            repaired_area = float(
                repaired.area()
            )

            if (
                not math.isfinite(repaired_area)
                or repaired_area <= 0
            ):
                raise ValueError(
                    'Reparo temporário produziu área inválida.'
                )

            area_change_m2 = abs(
                repaired_area
                - original_area
            )

            area_change_pct = (
                100.0
                * area_change_m2
                / original_area
            )

            if (
                not math.isfinite(area_change_pct)
                or area_change_pct
                > max_area_change_pct
            ):
                raise ValueError(
                    'Polígono inválido: makeValid() alteraria '
                    'a área acima da tolerância permitida '
                    f'({area_change_pct:.12g}% > '
                    f'{max_area_change_pct}%); '
                    'morfometria não calculada.'
                )

            geometry_repairs.append(
                {
                    'feature_id': int(
                        feature.id()
                    ),
                    'method': (
                        'QgsGeometry.makeValid() '
                        'somente em memória'
                    ),
                    'original_area_m2': (
                        original_area
                    ),
                    'repaired_area_m2': (
                        repaired_area
                    ),
                    'area_change_m2': (
                        area_change_m2
                    ),
                    'area_change_pct': (
                        area_change_pct
                    ),
                    'original_wkb': (
                        QgsWkbTypes.displayString(
                            g.wkbType()
                        )
                    ),
                    'repaired_wkb': (
                        QgsWkbTypes.displayString(
                            repaired.wkbType()
                        )
                    ),
                    'original_file_modified': False
                }
            )

            g = repaired

        geometries.append(
            QgsGeometry(g)
        )

    if not geometries:
        raise ValueError(
            'Microbacia sem feições.'
        )

    geometry = QgsGeometry.unaryUnion(
        geometries
    )

    if (
        geometry.isEmpty()
        or not geometry.isGeosValid()
        or geometry.type()
        != QgsWkbTypes.GeometryType.PolygonGeometry
    ):
        raise ValueError(
            'União da microbacia inválida após validação/reparo temporário.'
        )
    a, p = geometry.area(), geometry.length()
    if not all(math.isfinite(v) and v > 0 for v in (a, p)):
        raise ValueError('Área/perímetro inválidos.')
    # Avoid silently associating raster/network summaries with another basin.
    for key, value in (('area_m2', a), ('perimeter_m', p)):
        previous = diagnostic.get(key)
        if previous is None or not math.isclose(float(previous), value, rel_tol=1e-8, abs_tol=1e-6):
            raise ValueError('Vetor e diagnóstico discordam: ' + key)
    metrics = {}
    def put(key, value, unit, formula, source, **kw):
        metrics[key] = _metric(value, unit, formula, source, **kw)
    put('area', a, 'm²', 'area(union(polygons))', 'basin_vector')
    put('perimeter', p, 'm', 'length(boundary(union(polygons))); inclui anéis internos', 'basin_vector')
    polygons = (
        geometry.asMultiPolygon()
        if geometry.isMultipart()
        else [geometry.asPolygon()]
    )

    component_audit = []
    axial_component_index = None
    axial_component_area_m2 = None
    residual_area_m2 = None
    residual_area_pct = None

    for index, polygon in enumerate(polygons):
        part_geometry = QgsGeometry.fromPolygonXY(
            polygon
        )

        component_audit.append(
            {
                'index': index,
                'area_m2': float(
                    part_geometry.area()
                ),
                'perimeter_m': float(
                    part_geometry.length()
                ),
                'area_relative': float(part_geometry.area()) / float(a),
                'area_pct': 100.0 * float(part_geometry.area()) / float(a),
                'outlet_intersects': None
            }
        )

    length = None
    endpoint = None
    axial_reason = None
    form_factor_reason = None

    outlet_valid = (
        outlet_xy is not None
        and len(outlet_xy) == 2
        and all(
            math.isfinite(float(v))
            for v in outlet_xy
        )
    )

    if not outlet_valid:
        axial_reason = (
            'Exutório ajustado ausente ou inválido.'
        )

    else:
        x, y = map(
            float,
            outlet_xy
        )

        point = QgsGeometry.fromPointXY(
            QgsPointXY(x, y)
        )

        if len(polygons) == 1:
            axial_component_index = 0

        elif geometry_repairs:
            # Contact must be unique and the omitted area negligible under
            # the existing geometric tolerance. No snap or largest-part fallback.
            candidates = []
            for index, polygon in enumerate(polygons):
                part_geometry = QgsGeometry.fromPolygonXY(polygon)
                intersects = bool(part_geometry.intersects(point))
                component_audit[index]['outlet_intersects'] = intersects
                component_audit[index]['outlet_distance_m'] = float(part_geometry.distance(point))
                if intersects:
                    candidates.append(index)
            if len(candidates) != 1:
                axial_reason = (
                    'Geometria reparada multipartes: contato do exutório '
                    'ausente ou ambíguo; componente axial indisponível.'
                )
            else:
                candidate = candidates[0]
                other_area_pct = 100.0 * sum(
                    part['area_m2'] for part in component_audit
                    if part['index'] != candidate
                ) / float(a)
                if other_area_pct <= max_area_change_pct:
                    axial_component_index = candidate
                else:
                    axial_reason = (
                        'Geometria reparada multipartes: componente em contato '
                        'com o exutório não representa a área global dentro da '
                        f'tolerância geométrica ({other_area_pct:.12g}% de área '
                        f'externa > {max_area_change_pct}%); sem componente '
                        'hidrologicamente justificável, eixo indisponível.'
                    )

        else:
            axial_reason = (
                'Bacia multipartes sem reparo geométrico: '
                'eixo único não definido nesta versão.'
            )

        if (
            axial_component_index is not None
        ):
            axial_polygon = polygons[
                axial_component_index
            ]

            axial_geometry = (
                QgsGeometry.fromPolygonXY(
                    axial_polygon
                )
            )

            axial_component_area_m2 = float(
                axial_geometry.area()
            )

            residual_area_m2 = max(
                0.0,
                float(a)
                - axial_component_area_m2
            )

            residual_area_pct = (
                100.0
                * residual_area_m2
                / float(a)
                if a > 0
                else None
            )

            if not axial_geometry.intersects(
                point
            ):
                axial_reason = (
                    'Exutório ajustado fora da '
                    'componente axial selecionada.'
                )

            else:
                farthest = max(
                    axial_polygon[0],
                    key=lambda v: (
                        (v.x() - x) ** 2
                        + (v.y() - y) ** 2
                    )
                )

                endpoint = [
                    farthest.x(),
                    farthest.y()
                ]

                length = math.hypot(
                    endpoint[0] - x,
                    endpoint[1] - y
                )

                if (
                    len(polygons) > 1
                    and geometry_repairs
                ):
                    form_factor_reason = (
                        'Geometria reparada multipartes: '
                        'fator de forma mantido indisponível '
                        'para não combinar área global com '
                        'eixo de uma única componente.'
                    )

    put(
        'axial_length',
        length,
        'm',
        'max(||v-exutorio_ajustado||), '
        'v no limite externo da componente '
        'que contém o exutório',
        'basin_vector + adjusted_outlet',
        reason=axial_reason
    )

    put(
        'compactness_coefficient',
        p / (2 * math.sqrt(math.pi * a)),
        '1',
        'P/(2*sqrt(pi*A))',
        'basin_vector'
    )

    put(
        'circularity_index',
        4 * math.pi * a / p**2,
        '1',
        '4*pi*A/P²',
        'basin_vector'
    )

    form_factor_value = (
        a / length**2
        if (
            length
            and not form_factor_reason
        )
        else None
    )

    put(
        'form_factor',
        form_factor_value,
        '1',
        'A/L²',
        'basin_vector + adjusted_outlet',
        reason=(
            form_factor_reason
            or axial_reason
        )
    )
    zmin, zmax = diagnostic.get('elevation_min'), diagnostic.get('elevation_max')
    valid_z = vertical_metres and all(isinstance(v, (int, float)) and math.isfinite(v) for v in (zmin, zmax)) and zmax >= zmin
    count, total = diagnostic.get('elevation_cells', 0), diagnostic.get('basin_cells', 0)
    valid_z = valid_z and 0 < count <= total
    partial = valid_z and count < total
    relief = zmax-zmin if valid_z else None
    reason = ('Amostragem parcial: NoData; amplitude apenas das células válidas.' if partial else
              None if valid_z else 'Unidade vertical em metros não confirmada ou amostras inválidas.')
    put('elevation_range', relief, 'm', 'zmax-zmin', 'validated_diagnostic + basin_raster + dem', reason=reason, status='partial' if partial else None)
    put('relief_ratio', relief/length if relief is not None and length else None, 'm/m', '(zmax-zmin)/L', 'elevation_range + axial_length', reason=reason or axial_reason, status='partial' if partial and length else None)
    network = diagnostic.get('drainage_length_m')
    network_ok = isinstance(network, (int, float)) and math.isfinite(network) and network >= 0 and bool(diagnostic.get('drainage_source'))
    network = network if network_ok else None
    nr = None if network_ok else 'Rede modelada não selecionada ou métricas válidas indisponíveis.'
    put('modelled_network_length', network, 'm', 'sum(length(feature intersection basin))', 'validated_drainage_metrics', reason=nr)
    put('modelled_drainage_density', 1000*network/a if network_ok else None, 'km/km²', '(Lt/1000)/(A/1000000)', 'modelled_network_length + basin_vector', reason=nr)
    features = diagnostic.get('drainage_intersecting_features')
    features_ok = network_ok and isinstance(features, int) and not isinstance(features, bool) and features >= 0
    put('modelled_intersecting_features', features if features_ok else None, 'feições', 'count(input features with positive clipped length)', 'validated_drainage_metrics', reason=None if features_ok else 'Contagem válida indisponível.')
    channel = diagnostic.get('main_channel_length_m')
    channel_ok = isinstance(channel, (int, float)) and math.isfinite(channel) and channel > 0 and bool(diagnostic.get('main_channel_path'))
    put('modelled_main_channel_length', channel if channel_ok else None, 'm', 'comprimento do caminho selecionado pelo módulo validado v0.6.0', 'validated_main_channel', reason=None if channel_ok else 'Canal principal modelado não calculado com sucesso.')
    for key in ('modelled_channels', 'modelled_headwaters', 'modelled_confluences'):
        put(key, None, '1', 'não implementada: requer topologia dirigida validada da rede completa', 'none', reason='Feições intersectadas e candidatos do canal principal não comprovam esta contagem.')
    sources = {'basin_vector': _source(basin_path)}
    for key in ('dem_path', 'basin_raster_path', 'drainage_source', 'main_channel_path', 'outlet_points_path'):
        if diagnostic.get(key):
            sources[key] = _source(diagnostic[key])
    return dict(schema_version='0.7.0', status='computed', metrics=metrics,
                crs_wkt=layer.crs().toWkt(), crs_authid=layer.crs().authid(),
                sources=sources, adjusted_outlet_xy=[float(v) for v in outlet_xy] if outlet_xy is not None and len(outlet_xy) == 2 and all(math.isfinite(float(v)) for v in outlet_xy) else None,
                axial_endpoint_xy=endpoint, vertical_metres_confirmed=bool(vertical_metres),
                geometry_repair=dict(
                    applied=bool(geometry_repairs),
                    temporary_in_memory=True,
                    original_file_modified=False,
                    maximum_allowed_area_change_pct=max_area_change_pct,
                    features=geometry_repairs,
                    component_count=len(polygons),
                    components=component_audit,
                    axial_component_index=axial_component_index,
                    axial_component_area_m2=axial_component_area_m2,
                    residual_area_m2=residual_area_m2,
                    residual_area_pct=residual_area_pct,
                    axial_selection=dict(
                        policy='unique_exact_outlet_contact_and_negligible_other_area_v080',
                        maximum_other_area_pct=max_area_change_pct,
                        threshold_basis='existing geometric area tolerance; not hydrological connectivity proof',
                        snap_applied=False,
                        largest_component_fallback=False,
                        selected_index=axial_component_index if length is not None else None,
                        selected_area_relative=axial_component_area_m2 / a if length is not None else None,
                        reason=axial_reason or (
                            'Componente única com exutório.' if len(polygons) == 1 else
                            'Contato único com exutório e área das demais componentes dentro da tolerância geométrica.'
                        )
                    )
                ),
                elevation_sampling=dict(valid_cells=count, basin_cells=total, minimum=zmin, maximum=zmax),
                warnings=[str(diagnostic.get('boundary_warning') or ''),
                          'Microbacia e drenagem modeladas; sem inferência de vazões ou propensão a enchentes.',
                          'Eixo reto exutório-divisor pode atravessar o exterior de bacia côncava; não é trajeto de escoamento.',
                          'Rede: soma por feição, sem deduplicação; depende do limiar e da segmentação. Limiar não inferido do nome do arquivo.',
                          'Perímetro inclui limites de furos e depende da resolução do polígono.'],
                empirical_response_models='not included')


def attach_morphometry(diagnostic, basin_path, outlet_xy, vertical_metres=False):
    """Failure is explicit and never prevents saving the existing diagnostic."""
    try:
        diagnostic['morphometry'] = calculate(basin_path, diagnostic, outlet_xy, vertical_metres)
    except Exception as error:
        diagnostic['morphometry'] = dict(schema_version='0.7.0', status='unavailable', reason=str(error), metrics={})
        diagnostic.setdefault('pending', []).append('Morfometria indisponível: ' + str(error))
    return diagnostic


def summary_text(diagnostic):
    section = diagnostic.get('morphometry', {})
    if section.get('status') != 'computed':
        return '\n\nMorfometria v0.7.0 indisponível: ' + section.get('reason', 'não calculada')
    names = {'area': 'Área', 'perimeter': 'Perímetro (inclui furos)', 'axial_length': 'Comprimento axial reto exutório-divisor',
             'form_factor': 'Fator de forma (eixo reto)', 'compactness_coefficient': 'Coeficiente de compacidade (constante exata)',
             'circularity_index': 'Índice de circularidade', 'elevation_range': 'Amplitude altimétrica', 'relief_ratio': 'Relação de relevo',
             'modelled_network_length': 'Comprimento da rede modelada', 'modelled_drainage_density': 'Densidade de drenagem modelada',
             'modelled_intersecting_features': 'Feições da rede modelada intersectadas', 'modelled_main_channel_length': 'Comprimento do canal principal modelado',
             'modelled_channels': 'Número de canais modelados', 'modelled_headwaters': 'Cabeceiras modeladas', 'modelled_confluences': 'Confluências modeladas'}
    lines = ['\n\nMorfometria v0.7.0 — microbacia modelada']

    repair = section.get(
        'geometry_repair',
        {}
    )

    if repair.get('applied'):
        lines.append(
            'Geometria: reparo temporário em memória '
            'aplicado para cálculo; arquivo original não alterado.'
        )
    for key, metric in section['metrics'].items():
        value = 'indisponível' if metric['value'] is None else f"{metric['value']:.6g} {metric['unit']}"
        lines.append(names[key] + ': ' + value + (' — ' + metric['reason'] if metric['reason'] else ''))
    lines.append('Métodos, unidades, fontes e SHA-256 no JSON. Eixo reto não é comprimento de escoamento.')
    return '\n'.join(lines)
