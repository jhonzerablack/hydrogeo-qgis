﻿from qgis.core import (
    QgsRasterLayer,
    QgsRasterBandStats,
    QgsUnitTypes
)


class DEMAnalyzer:
    """Analisa tecnicamente um MDT/MDE raster sem modificar o arquivo original."""

    def __init__(self, raster_path):
        self.raster_path = raster_path
        self.layer = QgsRasterLayer(raster_path, "MDT_MDE")

    def is_valid(self):
        return self.layer.isValid()

    def analyze(self):
        if not self.is_valid():
            raise ValueError("O arquivo selecionado não é um raster válido.")

        provider = self.layer.dataProvider()

        crs = self.layer.crs()
        extent = self.layer.extent()

        width = self.layer.width()
        height = self.layer.height()

        pixel_x = abs(self.layer.rasterUnitsPerPixelX())
        pixel_y = abs(self.layer.rasterUnitsPerPixelY())

        band_count = self.layer.bandCount()
        data_type = provider.dataType(1)

        stats = provider.bandStatistics(
            1,
            QgsRasterBandStats.All
        )

        nodata_defined = provider.sourceHasNoDataValue(1)
        nodata_value = (
            provider.sourceNoDataValue(1)
            if nodata_defined
            else None
        )

        map_units = crs.mapUnits()
        unit_name = QgsUnitTypes.toString(map_units)

        warnings = []

        if not crs.isValid():
            warnings.append(
                "O raster não possui um sistema de referência válido."
            )

        if crs.isGeographic():
            warnings.append(
                "O raster utiliza coordenadas geográficas. "
                "Análises de distância, área, declividade e hidrologia "
                "normalmente devem utilizar um SRC projetado adequado."
            )

        if abs(pixel_x - pixel_y) > max(pixel_x, pixel_y) * 0.01:
            warnings.append(
                "Os pixels não são aproximadamente quadrados."
            )

        if band_count > 1:
            warnings.append(
                f"O raster possui {band_count} bandas. "
                "Um MDT/MDE normalmente utiliza uma única banda de elevação."
            )

        elevation_range = stats.maximumValue - stats.minimumValue

        if elevation_range <= 0:
            warnings.append(
                "Não foi detectada variação de elevação no raster."
            )

        result = {
            "path": self.raster_path,
            "name": self.layer.name(),

            "crs_authid": crs.authid(),
            "crs_description": crs.description(),
            "is_geographic": crs.isGeographic(),
            "map_units": unit_name,

            "width": width,
            "height": height,
            "pixel_x": pixel_x,
            "pixel_y": pixel_y,

            "extent_xmin": extent.xMinimum(),
            "extent_xmax": extent.xMaximum(),
            "extent_ymin": extent.yMinimum(),
            "extent_ymax": extent.yMaximum(),

            "band_count": band_count,
            "data_type": int(data_type),

            "minimum": stats.minimumValue,
            "maximum": stats.maximumValue,
            "mean": stats.mean,
            "stddev": stats.stdDev,
            "elevation_range": elevation_range,

            "nodata_defined": nodata_defined,
            "nodata_value": nodata_value,

            "warnings": warnings
        }

        return result
