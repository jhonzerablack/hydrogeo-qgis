from __future__ import annotations

import json
from pathlib import Path


def load_diagnostic(path):
    source = Path(path)

    with source.open("r", encoding="utf-8") as stream:
        data = json.load(stream)

    if not isinstance(data, dict):
        raise ValueError("Diagnóstico JSON inválido.")

    if "morphometry" not in data:
        raise ValueError(
            "O arquivo selecionado não parece ser um diagnóstico HydroGeo completo."
        )

    return data


def _find_first(value, key):
    if isinstance(value, dict):
        if key in value:
            return value[key]

        for child in value.values():
            result = _find_first(child, key)
            if result is not None:
                return result

    elif isinstance(value, list):
        for child in value:
            result = _find_first(child, key)
            if result is not None:
                return result

    return None


def _source_path(data, key):
    sources = _find_first(data, "sources") or {}

    if isinstance(sources, dict):
        item = sources.get(key)

        if isinstance(item, dict):
            return (
                item.get("uri")
                or item.get("path")
                or item.get("source")
            )

        if item:
            return str(item)

    return None


def collect_map_sources(data):
    result = {}

    mappings = {
        "dem": [
            ("dem_path", data.get("dem_path")),
            ("working_dem", (data.get("hydrologic_working_data") or {}).get("dem")),
        ],
        "basin": [
            ("source", _source_path(data, "basin")),
            ("direct", data.get("basin_vector_path")),
        ],
        "network": [
            ("source", _source_path(data, "network")),
            ("direct", data.get("drainage_source")),
        ],
        "main_channel": [
            ("direct", data.get("main_channel_path")),
        ],
        "outlet_points": [
            ("direct", data.get("outlet_points_path")),
        ],
    }

    for name, candidates in mappings.items():
        value = None

        for _, candidate in candidates:
            if candidate:
                value = str(candidate)
                break

        if value:
            result[name] = value

    return result


def _nice_step(value):
    """Readable cartographic interval, never larger than the requested span."""
    import math
    power = 10 ** math.floor(math.log10(value))
    return max(n * power for n in (1, 2, 2.5, 5, 10) if n * power <= value)


def _number(value, decimals=2):
    import math
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
        return "não disponível"
    return f"{value:,.{decimals}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def generate_map(diagnostic_path, output_pdf, output_png):
    """Compose existing results in a private project; never run hydrology tools.

    PNG is a page illustration (not a georeferenced raster). Save the rendered
    QImage directly: GDAL cannot update PNG metadata in place on QGIS 4.2.
    """
    from datetime import datetime
    import shutil
    import tempfile
    from qgis.core import (
        Qgis, QgsFillSymbol, QgsLayoutExporter, QgsLayoutItemLabel,
        QgsLayoutItemLegend, QgsLayoutItemMap, QgsLayoutItemMapGrid,
        QgsLayoutItemPage, QgsLayoutItemPolygon, QgsLayoutItemScaleBar,
        QgsLayoutPoint, QgsLayoutSize, QgsLayoutMeasurement,
        QgsMarkerSymbol, QgsPrintLayout, QgsProject, QgsRasterLayer,
        QgsSingleSymbolRenderer, QgsVectorLayer, QgsLineSymbol, QgsTextFormat,
        QgsLegendStyle, QgsLegendRenderer, QgsMapLayerLegendUtils,
        QgsColorRampLegendNodeSettings, QgsBasicNumericFormat,
    )
    from qgis.PyQt.QtCore import QPointF, Qt
    from qgis.PyQt.QtGui import QColor, QFont, QPolygonF

    data = load_diagnostic(diagnostic_path)
    sources = collect_map_sources(data)
    required = ("dem", "basin", "network", "main_channel", "outlet_points")
    missing = [key for key in required if not sources.get(key)
               or not Path(sources[key].split("|")[0]).is_file()]
    if missing:
        raise FileNotFoundError("Arquivos obrigatórios não encontrados: " + ", ".join(missing))
    output_pdf, output_png = Path(output_pdf), Path(output_png)
    if output_pdf.resolve() == output_png.resolve():
        raise ValueError("PDF e PNG devem ter caminhos distintos.")
    for path in (output_pdf, output_png):
        if path.exists():
            raise FileExistsError("Escolha outro nome; o arquivo já existe: " + str(path))
        if not path.parent.is_dir():
            raise FileNotFoundError("Pasta de saída não encontrada: " + str(path.parent))

    # No registration in QgsProject.instance(), even on export failures.
    project = QgsProject()
    layers = {}
    names = {"basin": "Limite da microbacia", "network": "Rede de drenagem modelada",
             "main_channel": "Canal principal modelado", "outlet_points": "Exutório ajustado",
             "dem": "MDT/MDE"}
    for key in required:
        options = QgsVectorLayer.LayerOptions()
        options.forceReadOnly = True
        options.loadDefaultStyle = False
        layer = (QgsRasterLayer(sources[key], names[key]) if key == "dem" else
                 QgsVectorLayer(sources[key], names[key], "ogr", options))
        if not layer.isValid() or not layer.crs().isValid():
            raise ValueError("Camada ou SRC inválido: " + sources[key])
        project.addMapLayer(layer, False)
        layers[key] = layer
    basin = layers["basin"]
    crs = basin.crs()
    if crs.isGeographic() or crs.mapUnits() != Qgis.DistanceUnit.Meters:
        raise ValueError("O mapa técnico requer o SRC projetado em metros da microbacia. "
                         "Reprojete os dados antes de gerar o diagnóstico.")
    project.setCrs(crs)
    extent = basin.extent()
    if extent.isEmpty() or extent.width() <= 0 or extent.height() <= 0:
        raise ValueError("A microbacia não possui extensão cartográfica válida.")
    outlet = layers["outlet_points"]
    if "tipo" in outlet.fields().names():
        if not outlet.setSubsetString('"tipo" = \'ajustado\'') or outlet.featureCount() != 1:
            raise ValueError("Não foi possível identificar um único exutório ajustado.")
    elif outlet.featureCount() != 1:
        raise ValueError("Exutório ambíguo: falta a identificação do ponto ajustado.")
    symbols = {
        "basin": QgsFillSymbol.createSimple({"color": "255,255,255,0", "outline_color": "45,57,62", "outline_width": "0.45"}),
        "network": QgsLineSymbol.createSimple({"color": "66,137,174", "width": "0.3"}),
        "main_channel": QgsLineSymbol.createSimple({"color": "0,65,116", "width": "0.75"}),
        "outlet_points": QgsMarkerSymbol.createSimple({"name": "circle", "color": "178,64,44", "size": "3", "outline_color": "255,255,255", "outline_width": "0.4"}),
    }
    for key, symbol in symbols.items():
        layers[key].setRenderer(QgsSingleSymbolRenderer(symbol))
    layers["dem"].setOpacity(0.65)
    renderer = layers["dem"].renderer()
    if hasattr(renderer, "setLegendSettings"):
        ramp_settings = QgsColorRampLegendNodeSettings()
        numeric = QgsBasicNumericFormat()
        numeric.setNumberDecimalPlaces(1)
        ramp_settings.setNumericFormat(numeric)
        renderer.setLegendSettings(ramp_settings)

    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName("Mapa técnico da microbacia - v0.8.0")
    layout.pageCollection().page(0).setPageSize("A4", QgsLayoutItemPage.Orientation.Portrait)

    def text_format(size, bold=False):
        fmt = QgsTextFormat()
        font = QFont("Arial")
        font.setPointSizeF(size)
        font.setBold(bold)
        fmt.setFont(font)
        fmt.setSize(size)
        fmt.setColor(QColor("#263d46"))
        return fmt

    def label(text, x, y, w, h, size=8, bold=False, center=False):
        item = QgsLayoutItemLabel(layout)
        item.setText(text)
        item.setTextFormat(text_format(size, bold))
        item.setMargin(0)
        if center:
            item.setHAlign(Qt.AlignmentFlag.AlignHCenter)
        layout.addLayoutItem(item)
        item.attemptMove(QgsLayoutPoint(x, y))
        item.attemptResize(QgsLayoutSize(w, h))
        return item

    label("HYDROGEO TOOLS  /  v0.8.0", 18, 9, 174, 5, 8, True)
    label("Mapa técnico da microbacia", 18, 16, 174, 9, 17, True)
    label("Produtos hidrológicos modelados • Coordenadas em metros", 18, 26, 174, 5, 9)
    map_item = QgsLayoutItemMap(layout)
    layout.addLayoutItem(map_item)
    map_item.attemptMove(QgsLayoutPoint(18, 39))
    map_item.attemptResize(QgsLayoutSize(174, 160))
    map_item.setCrs(crs)
    map_item.setMapRotation(0)
    map_item.setLayers([layers[k] for k in ("outlet_points", "main_channel", "network", "basin", "dem")])
    map_item.setKeepLayerSet(True)
    extent.scale(1.19)
    map_item.zoomToExtent(extent)
    # Rounded denominator and the linked scale bar describe the same map.
    import math
    rounding = 10 ** max(0, math.floor(math.log10(map_item.scale())) - 2)
    map_item.setScale(math.ceil(map_item.scale() / rounding) * rounding)
    map_item.setFrameEnabled(True)
    map_item.setFrameStrokeColor(QColor("#52656d"))
    map_item.setFrameStrokeWidth(QgsLayoutMeasurement(0.25))
    grid = map_item.grid()
    grid.setEnabled(True)
    grid.setCrs(crs)
    grid.setStyle(QgsLayoutItemMapGrid.FrameAnnotationsOnly)
    step = _nice_step(map_item.extent().width() / 4)
    grid.setIntervalX(step)
    grid.setIntervalY(step)
    grid.setFrameStyle(QgsLayoutItemMapGrid.ExteriorTicks)
    grid.setFrameWidth(1.5)
    grid.setFramePenSize(0.2)
    grid.setAnnotationEnabled(True)
    grid.setAnnotationFormat(QgsLayoutItemMapGrid.Decimal)
    grid.setAnnotationPrecision(0 if step >= 1 else 2)
    grid.setAnnotationTextFormat(text_format(7))
    grid.setAnnotationFrameDistance(2)
    for side in (QgsLayoutItemMapGrid.Top, QgsLayoutItemMapGrid.Bottom,
                 QgsLayoutItemMapGrid.Left, QgsLayoutItemMapGrid.Right):
        grid.setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, side)
        grid.setAnnotationDirection(QgsLayoutItemMapGrid.BoundaryDirection, side)
    grid.setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, QgsLayoutItemMapGrid.Top)

    # Map is unrotated in its real projected CRS: this denotes grid north.
    label("N", 179, 43, 8, 5, 11, True, True)
    arrow = QgsLayoutItemPolygon(QPolygonF([QPointF(183, 49), QPointF(180.8, 58),
                                           QPointF(183, 56), QPointF(185.2, 58)]), layout)
    arrow.setSymbol(QgsFillSymbol.createSimple({"color": "38,61,70", "outline_style": "no"}))
    layout.addLayoutItem(arrow)
    label("quadrícula", 173, 59, 19, 4, 6, center=True)

    scalebar = QgsLayoutItemScaleBar(layout)
    scalebar.setStyle("Single Box")
    scalebar.setLinkedMap(map_item)
    scalebar.setUnits(Qgis.DistanceUnit.Meters)
    scalebar.setNumberOfSegments(4)
    scalebar.setNumberOfSegmentsLeft(0)
    scalebar.setUnitsPerSegment(_nice_step(map_item.extent().width() * 0.33 / 4))
    scalebar.setUnitLabel("m")
    scalebar.setHeight(2)
    scalebar.setTextFormat(text_format(7))
    layout.addLayoutItem(scalebar)
    scalebar.update()
    scalebar.attemptMove(QgsLayoutPoint((210 - scalebar.sizeWithUnits().width()) / 2, 207))
    label("Escala 1:" + _number(map_item.scale(), 0) + " • impressão em A4 (100%)",
          18, 218, 174, 5, 8, center=True)

    legend = QgsLayoutItemLegend(layout)
    legend.setTitle("LEGENDA")
    legend.setLinkedMap(map_item)
    legend.setSyncMode(Qgis.LegendSyncMode.Manual)
    root = legend.model().rootGroup()
    root.clear()
    for key in ("basin", "network", "main_channel", "outlet_points", "dem"):
        node = root.addLayer(layers[key])
        if key != "dem":
            QgsLegendRenderer.setNodeLegendStyle(node, QgsLegendStyle.Hidden)
        else:
            vertical_m = (data.get("morphometry") or {}).get("vertical_metres_confirmed")
            QgsMapLayerLegendUtils.setLegendNodeUserLabel(node, 0, "Elevação (m)" if vertical_m else "Valores do raster")
            legend.model().refreshLayerLegend(node)
    for style in (QgsLegendStyle.Title, QgsLegendStyle.Group, QgsLegendStyle.Subgroup, QgsLegendStyle.SymbolLabel):
        legend.rstyle(style).setTextFormat(text_format(8, style == QgsLegendStyle.Title))
    legend.setBoxSpace(0)
    legend.setSymbolWidth(7)
    legend.setSymbolHeight(3)
    layout.addLayoutItem(legend)
    legend.attemptMove(QgsLayoutPoint(18, 226))
    legend.adjustBoxSize()

    topology = data.get("drainage_topology") or {}
    order = ((topology.get("metrics") or {}).get("max_strahler_order")
             if topology.get("status") == "available" else None)
    generated = datetime.now().astimezone()
    label("QUADRO TÉCNICO", 108, 226, 84, 5, 8, True)
    rows = [
        "Área: " + _number(data.get("area_ha"), 3) + " ha",
        "Perímetro: " + _number(data.get("perimeter_m")) + " m",
        "Rede total: " + _number(data.get("drainage_length_m")) + " m",
        "Canal principal: " + _number(data.get("main_channel_length_m")) + " m",
        "Ordem máxima de Strahler: " + _number(order, 0),
        "SRC: " + crs.authid(),
        crs.description(),
        "Gerado: " + generated.strftime("%d/%m/%Y %H:%M %z"),
    ]
    for i, row in enumerate(rows):
        label(row, 108, 235 + i * 4, 84, 4, 7.5)
    provenance = (data.get("hydrologic_working_data") or {}).get("dem_provenance") or {}
    origin = ((provenance.get("inputs") or {}).get("source") or {}).get("path")
    source_name = Path(origin or sources["dem"]).name
    import textwrap
    footer = "\n".join(textwrap.wrap("Fonte MDT/MDE: " + source_name, 115))
    footer += "\nDiagnóstico: " + Path(diagnostic_path).name
    footer += "\nLimite, drenagem, canal e exutório: resultados modelados HydroGeo Tools."
    footer += "\nProdutos modelados; não substituem verificação de campo."
    label(footer, 18, 274, 174, 18, 7)

    exporter = QgsLayoutExporter(layout)
    # Stage both products before publishing; failures leave no half-finished pair.
    published = []
    with tempfile.TemporaryDirectory(prefix="hydrogeo_map_", dir=output_pdf.parent) as staging:
        staged_pdf, staged_png = Path(staging) / "map.pdf", Path(staging) / "map.png"
        settings = QgsLayoutExporter.PdfExportSettings()
        settings.dpi = 300
        settings.appendGeoreference = False
        result = exporter.exportToPdf(str(staged_pdf), settings)
        if result != QgsLayoutExporter.Success:
            raise RuntimeError(f"Falha ao exportar PDF ({result}): {exporter.errorMessage()}")
        image = exporter.renderPageToImage(0, dpi=200)
        if image.isNull() or not image.save(str(staged_png), "PNG"):
            raise RuntimeError("Falha ao renderizar ou gravar o PNG do mapa.")
        try:
            for source, target in ((staged_pdf, output_pdf), (staged_png, output_png)):
                with target.open("xb") as stream:
                    published.append(target)
                    with source.open("rb") as input_stream:
                        shutil.copyfileobj(input_stream, stream)
        except Exception:
            for target in published:
                target.unlink(missing_ok=True)
            raise
    return {"pdf": str(output_pdf), "png": str(output_png), "sources": sources,
            "crs": crs.authid(), "scale": map_item.scale(), "grid_interval": step,
            "generated_at": generated.isoformat(), "png_georeferenced": False,
            "legend_layers": [n.name() for n in root.findLayers()],
            "outlet_count": outlet.featureCount(), "strahler_order": order}


