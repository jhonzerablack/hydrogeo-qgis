"""Canal principal modelado a partir da rede e da acumulação D8.

Módulo experimental da v0.6.0.

Não altera:
- MDT;
- acumulação;
- rede de drenagem;
- microbacia.

O resultado deve ser tratado como canal principal MODELADO.
"""

import math
import json
from pathlib import Path

from qgis.core import (
    QgsGeometry,
    QgsPointXY,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsProject
)

def _sample_abs_accumulation(accumulation, point):
    """Amostra a magnitude da acumulação D8 em um ponto."""

    provider = accumulation.dataProvider()

    value, ok = provider.sample(
        QgsPointXY(point),
        1
    )

    if not ok or value is None:
        return None

    value = float(value)

    if not math.isfinite(value):
        return None

    return abs(value)


def _node_key(point, tolerance_m):
    """Cria chave espacial aproximada para conectar extremidades."""

    tolerance_m = float(tolerance_m)

    if tolerance_m <= 0:
        tolerance_m = 0.01

    return (
        round(point.x() / tolerance_m),
        round(point.y() / tolerance_m)
    )


def _line_parts(geometry):
    """Converte geometria linear simples ou multipartes em partes."""

    if geometry is None or geometry.isEmpty():
        return []

    if QgsWkbTypes.flatType(geometry.wkbType()) == QgsWkbTypes.Type.GeometryCollection:
        return [part for child in geometry.asGeometryCollection()
                for part in _line_parts(child)]
    if geometry.type() != QgsWkbTypes.GeometryType.LineGeometry:
        return []  # Point contacts do not represent channel length or connections.

    parts = []

    if geometry.isMultipart():
        lines = geometry.asMultiPolyline()

        for line in lines:
            if len(line) >= 2:
                parts.append(
                    [QgsPointXY(p) for p in line]
                )

    else:
        line = geometry.asPolyline()

        if len(line) >= 2:
            parts.append(
                [QgsPointXY(p) for p in line]
            )

    return parts


def _component_path(edges, nodes):
    """Orient a tree from its D8 downstream terminal, never from noisy junctions.

    Each headwater in a tree has one simple path to the outlet. No edge is
    removed because its endpoint samples disagree with that topology.
    Cyclic networks and tied downstream terminals need further information.
    """
    adjacency = {key: [] for key in nodes}
    for index, edge in enumerate(edges):
        a, b = edge['upstream_key'], edge['downstream_key']
        adjacency[a].append((b, index))
        adjacency[b].append((a, index))
    start = min(nodes, key=lambda key: nodes[key]['distance'])
    component = {start}
    component_edges = set()
    todo = [start]
    while todo:
        current = todo.pop()
        for other, index in adjacency[current]:
            component_edges.add(index)
            if other not in component:
                component.add(other)
                todo.append(other)
    if len(component_edges) != len(component) - 1:
        raise ValueError('Componente do exutório contém ciclos ou trechos duplicados; '
                         'a orientação hidrológica requer revisão da rede.')
    terminals = [key for key in component if len(adjacency[key]) == 1]
    accumulation = {}
    for key in terminals:
        _, index = adjacency[key][0]
        edge = edges[index]
        side = 'upstream' if edge['upstream_key'] == key else 'downstream'
        accumulation[key] = edge[side + '_acc']
    known = [key for key in terminals if accumulation[key] is not None]
    if len(known) != len(terminals) or not known:
        raise ValueError('Acumulação D8 ausente em extremo da componente; '
                         'não é possível definir jusante com segurança.')
    sink = max(known, key=lambda key: accumulation[key])
    if sum(math.isclose(accumulation[key], accumulation[sink]) for key in known) != 1:
        raise ValueError('Extremos com acumulação D8 máxima empatada; orientação ambígua.')
    # Root the entire component, then traverse only children of the outlet.
    parent = {sink: None}
    children = {key: [] for key in component}
    todo = [sink]
    reversed_edges = []
    while todo:
        current = todo.pop()
        for other, index in adjacency[current]:
            if other in parent:
                continue
            parent[other] = current
            children[current].append((other, index))
            if edges[index]['downstream_key'] != current:
                reversed_edges.append(index)
            todo.append(other)
    nearest = start
    if not children[start]:
        usable = [key for key in component if children[key]]
        if usable:
            start = min(usable, key=lambda key: nodes[key]['distance'])
    candidates = []
    todo = [(start, [], 0.0)]
    while todo:
        current, path, length = todo.pop()
        if not children[current]:
            if path:
                candidates.append({'headwater': current, 'length_m': length, 'edges': path})
            continue
        for other, index in children[current]:
            todo.append((other, path + [index], length + edges[index]['length_m']))
    if not candidates:
        raise ValueError('Não foi possível conectar o exutório à rede modelada: '
                         'o nó mais próximo não possui cabeceira a montante.')
    best = max(candidates, key=lambda item: item['length_m'])
    def node_info(key):
        point = nodes[key]['point']
        return {'id': list(key), 'x': point.x(), 'y': point.y()}
    debug = {
        'method': 'Componente arbórea; jusante pelo extremo de maior magnitude D8; '
                  'maior caminho simples do exutório até cabeceira a montante.',
        'nearest_node': node_info(nearest),
        'start_node': node_info(start), 'downstream_terminal': node_info(sink),
        'downstream_accumulation': accumulation[sink],
        'outlet_distance_m': nodes[start]['distance'],
        'component_nodes': [node_info(key) for key in sorted(component)],
        'component_edges': sorted(component_edges),
        'component_length_m': sum(edges[i]['length_m'] for i in component_edges),
        'orientation_conflicts_with_endpoint_samples': sorted(reversed_edges),
        'headwater_candidates': candidates,
        'selected_path': best,
        'edges': [{'id': i, 'a': list(edges[i]['upstream_key']),
                   'b': list(edges[i]['downstream_key']),
                   'a_acc': edges[i]['upstream_acc'], 'b_acc': edges[i]['downstream_acc'],
                   'length_m': edges[i]['length_m']} for i in sorted(component_edges)],
    }
    return best['edges'], best['length_m'], nodes[start]['distance'], debug


def main_channel_modelled(
    basin_vector_path,
    drainage_layer,
    accumulation_layer,
    outlet_x,
    outlet_y,
    connection_tolerance_m=0.05,
    debug_path=None
):
    """
    Identifica o canal principal MODELADO dentro da microbacia.

    Estratégia:
    1. recorta a rede pela microbacia;
    2. constrói nós/extremidades e a componente do exutório;
    3. identifica jusante pelo extremo de maior magnitude D8;
    4. orienta a árvore inteira sem quebrar junções por amostras locais;
    5. enumera cabeceiras a montante e escolhe o maior caminho simples.

    A acumulação D8 define a orientação hidrológica dos trechos.
    O comprimento acumulado define o caminho principal.

    O resultado não deve ser interpretado automaticamente como
    curso d'água observado em campo.
    """

    basin = QgsVectorLayer(
        str(basin_vector_path),
        "Microbacia modelada",
        "ogr"
    )

    if not basin.isValid():
        raise ValueError(
            "Não foi possível abrir a microbacia modelada."
        )

    if isinstance(
        drainage_layer,
        (str, Path)
    ):
        drainage = QgsVectorLayer(
            str(drainage_layer),
            "Rede de drenagem modelada",
            "ogr"
        )
    else:
        drainage = drainage_layer

    if (
        drainage is None
        or not drainage.isValid()
    ):
        raise ValueError(
            "A rede de drenagem modelada não é válida."
        )

    if (
        accumulation_layer is None
        or not accumulation_layer.isValid()
    ):
        raise ValueError(
            "A acumulação D8 não é válida."
        )

    if basin.crs() != drainage.crs():
        raise ValueError(
            "Microbacia e rede de drenagem devem usar o mesmo SRC."
        )

    if basin.crs() != accumulation_layer.crs():
        raise ValueError(
            "Microbacia e acumulação D8 devem usar o mesmo SRC."
        )

    basin_geometries = []
    geometry_audit = {'validation': 'GEOS isGeosValid; input features and union',
                      'repair_applied': False, 'validated_repair_available': False,
                      'features': [], 'union_is_valid': None}

    def unavailable(code, text):
        result = {'status': 'unavailable', 'reason_code': code, 'reason_text': text,
                  'geometry_audit': geometry_audit, 'geometry': None,
                  'main_channel_length_m': None, 'main_channel_segments': None,
                  'outlet_network_distance_m': None,
                  'main_channel_semantics': 'Canal principal MODELADO indisponível; '
                      'não representa automaticamente curso de água observado em campo.'}
        if debug_path is not None:
            with Path(debug_path).open('x', encoding='utf-8') as stream:
                json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        return result

    for feature in basin.getFeatures():
        geometry = feature.geometry()

        empty = geometry is None or geometry.isEmpty()
        valid = not empty and geometry.isGeosValid()
        geometry_audit['features'].append({
            'feature_id': int(feature.id()), 'is_empty': empty, 'is_valid': valid,
            'validation_errors': [] if valid or empty else
                [error.what() for error in geometry.validateGeometry()],
        })

        if (
            geometry is None
            or geometry.isEmpty()
        ):
            continue

        basin_geometries.append(
            QgsGeometry(geometry)
        )

    if any(not item['is_valid'] for item in geometry_audit['features']):
        return unavailable('invalid_basin_geometry',
            'Canal principal modelado indisponível: a bacia de entrada possui geometria '
            'inválida ou vazia e não há procedimento de reparo explicitamente validado '
            'para este cálculo. Nenhum reparo, componente residual ou comprimento substituto foi usado. Execute Verificar validade e Corrigir geometrias em uma cópia; revise limites, componentes e conectividade da rede antes de recalcular. Preserve o original.')

    if not basin_geometries:
        return unavailable('invalid_basin_geometry',
            'Canal principal modelado indisponível: a bacia não possui geometria; '
            'nenhum comprimento substituto foi usado.')

    if len(basin_geometries) == 1:
        basin_geometry = basin_geometries[0]
    else:
        basin_geometry = QgsGeometry.unaryUnion(
            basin_geometries
        )

    if (
        basin_geometry is None
        or basin_geometry.isEmpty()
    ):
        return unavailable('invalid_basin_geometry',
            'Canal principal modelado indisponível: a união das geometrias da bacia '
            'é vazia ou falhou; nenhum comprimento substituto foi usado.')

    geometry_audit['union_is_valid'] = basin_geometry.isGeosValid()
    if not geometry_audit['union_is_valid']:
        return unavailable('invalid_basin_geometry',
            'Canal principal modelado indisponível: a união das geometrias da bacia é inválida; '
            'nenhum reparo ou comprimento substituto foi usado.')

    edges = []
    clipped_geometries = []
    tolerance = float(connection_tolerance_m)
    if not math.isfinite(tolerance) or tolerance <= 0:
        raise ValueError("Tolerância de conexão deve ser positiva e finita.")
    buckets = {}

    def endpoint_key(point):
        cell = (math.floor(point.x()/tolerance), math.floor(point.y()/tolerance))
        nearby = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for key in buckets.get((cell[0]+dx, cell[1]+dy), []):
                    distance = math.hypot(point.x()-key[0], point.y()-key[1])
                    if distance <= tolerance:
                        nearby.append((distance, key))
        if nearby:
            return min(nearby)[1]
        key = (point.x(), point.y())
        buckets.setdefault(cell, []).append(key)
        return key

    for feature in drainage.getFeatures():
        geometry = feature.geometry()

        if (
            geometry is None
            or geometry.isEmpty()
        ):
            continue

        if not geometry.intersects(
            basin_geometry
        ):
            continue

        clipped = geometry.intersection(
            basin_geometry
        )

        if (
            clipped is None
            or clipped.isEmpty()
        ):
            continue

        clipped_geometries.append(clipped)

    # Preserve the supplied network's endpoint topology. A geometric crossing
    # of raster-derived lines is not necessarily a hydrological junction.
    for clipped in clipped_geometries:
        for points in _line_parts(clipped):
            first = points[0]
            last = points[-1]

            acc_first = _sample_abs_accumulation(
                accumulation_layer,
                first
            )

            acc_last = _sample_abs_accumulation(
                accumulation_layer,
                last
            )

            # Maior magnitude de acumulação = jusante.
            # Labels are provisional; connectivity is retained even with NoData.
            if acc_first is None or acc_last is None or acc_first <= acc_last:
                upstream = first
                downstream = last
                upstream_acc = acc_first
                downstream_acc = acc_last
                oriented_points = points
            else:
                upstream = last
                downstream = first
                upstream_acc = acc_last
                downstream_acc = acc_first

                oriented_points = list(
                    reversed(points)
                )

            geometry_oriented = (
                QgsGeometry.fromPolylineXY(
                    oriented_points
                )
            )

            length_m = float(
                geometry_oriented.length()
            )

            if (
                not math.isfinite(length_m)
                or length_m <= 0
            ):
                continue

            up_key, down_key = endpoint_key(upstream), endpoint_key(downstream)
            if up_key == down_key and length_m <= tolerance:
                continue  # Intersection round-off collapsed into the same node.

            edges.append(
                {
                    "geometry": geometry_oriented,
                    "upstream": upstream,
                    "downstream": downstream,
                    "upstream_key": up_key,
                    "downstream_key": down_key,
                    "upstream_acc": upstream_acc,
                    "downstream_acc": downstream_acc,
                    "length_m": length_m
                }
            )

    if not edges:
        raise ValueError(
            "Nenhum trecho válido da rede foi encontrado "
            "dentro da microbacia."
        )

    outlet = QgsPointXY(
        float(outlet_x),
        float(outlet_y)
    )

    nodes = {}

    for edge in edges:
        for name in (
            "upstream",
            "downstream"
        ):
            point = edge[name]

            key = edge[name + "_key"]

            distance = math.hypot(
                point.x() - outlet.x(),
                point.y() - outlet.y()
            )

            previous = nodes.get(
                key
            )

            if (
                previous is None
                or distance < previous["distance"]
            ):
                nodes[key] = {
                    "point": point,
                    "distance": distance
                }

    selected_indexes, main_length_m, outlet_snap_distance_m, debug = _component_path(edges, nodes)
    if debug_path is not None:
        with Path(debug_path).open('x', encoding='utf-8') as stream:
            json.dump(debug, stream, ensure_ascii=False, indent=2, allow_nan=False)

    selected_geometries = [
        edges[index]["geometry"]
        for index in selected_indexes
    ]

    combined = QgsGeometry.unaryUnion(
        selected_geometries
    )

    if (
        combined is None
        or combined.isEmpty()
    ):
        raise ValueError(
            "Não foi possível construir o "
            "canal principal modelado."
        )

    try:
        merged = combined.mergeLines()

        if (
            merged is not None
            and not merged.isEmpty()
        ):
            combined = merged

    except Exception:
        pass

    return {
        "debug": debug,
        "geometry": combined,
        "main_channel_length_m": main_length_m,
        "main_channel_segments": len(
            selected_indexes
        ),
        "outlet_network_distance_m": (
            outlet_snap_distance_m
        ),
        "main_channel_semantics": (
            "Canal principal modelado definido como o caminho "
            "conectado de maior comprimento entre o nó mais próximo "
            "do exutório ajustado na mesma componente arbórea "
            "e as cabeceiras da rede de drenagem "
            "modelada dentro da microbacia. A magnitude da "
            "acumulação D8 define jusante pelo extremo de maior magnitude; "
            "a árvore é orientada preservando todas as conexões. Não representa "
            "automaticamente curso d'água observado em campo."
        )
    }

def save_main_channel(
    result,
    output_path,
    crs
):
    """
    Salva o canal principal modelado em GeoPackage.

    Não altera a rede original.
    """

    if result.get('status') == 'unavailable':
        return None

    from qgis.core import (
        QgsFeature,
        QgsField,
        QgsVectorFileWriter
    )
    from qgis.PyQt.QtCore import QMetaType

    output_path = str(
        output_path
    )

    layer = QgsVectorLayer(
        "LineString?crs=" + crs.authid(),
        "Canal principal modelado",
        "memory"
    )

    if not layer.isValid():
        raise ValueError(
            "Não foi possível criar a camada temporária "
            "do canal principal modelado."
        )

    provider = layer.dataProvider()

    provider.addAttributes(
        [
            QgsField(
                "compr_m",
                QMetaType.Type.Double
            ),
            QgsField(
                "trechos",
                QMetaType.Type.Int
            ),
            QgsField(
                "dist_exut",
                QMetaType.Type.Double
            ),
            QgsField(
                "metodo",
                QMetaType.Type.QString
            ),
            QgsField(
                "semantica",
                QMetaType.Type.QString
            )
        ]
    )

    layer.updateFields()

    feature = QgsFeature(
        layer.fields()
    )

    feature.setGeometry(
        result["geometry"]
    )

    feature["compr_m"] = (
        result["main_channel_length_m"]
    )

    feature["trechos"] = (
        result["main_channel_segments"]
    )

    feature["dist_exut"] = (
        result["outlet_network_distance_m"]
    )

    feature["metodo"] = (
        "Maior caminho conectado; "
        "orientação por acumulação D8"
    )

    feature["semantica"] = (
        result["main_channel_semantics"]
    )

    provider.addFeature(
        feature
    )

    options = (
        QgsVectorFileWriter.SaveVectorOptions()
    )

    options.driverName = "GPKG"
    options.layerName = (
        "canal_principal_modelado"
    )

    write_result = (
        QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            output_path,
            QgsProject.instance().transformContext(),
            options
        )
    )

    if write_result[0] != (
        QgsVectorFileWriter.WriterError.NoError
    ):
        raise RuntimeError(
            "Falha ao salvar o canal principal modelado: "
            + str(write_result)
        )

    saved = QgsVectorLayer(
        output_path,
        "Canal principal modelado",
        "ogr"
    )

    if not saved.isValid():
        raise RuntimeError(
            "O canal principal foi salvo, "
            "mas não pôde ser reaberto."
        )

    return saved


def attach_main_channel(
    diagnostic,
    main_channel_result,
    main_channel_path
):
    """
    Acrescenta o canal principal modelado ao diagnóstico.
    """

    if 'debug' in main_channel_result:
        diagnostic['main_channel_debug'] = main_channel_result['debug']

    if main_channel_result.get('status') == 'unavailable':
        diagnostic.pop('main_channel_debug', None)
        diagnostic['main_channel_status'] = 'unavailable'
        for key in ('reason_code', 'reason_text', 'geometry_audit'):
            diagnostic['main_channel_' + key] = main_channel_result[key]
    else:
        for key in ('status', 'reason_code', 'reason_text', 'geometry_audit'):
            diagnostic.pop('main_channel_' + key, None)

    diagnostic[
        "main_channel_length_m"
    ] = main_channel_result[
        "main_channel_length_m"
    ]

    diagnostic[
        "main_channel_segments"
    ] = main_channel_result[
        "main_channel_segments"
    ]

    diagnostic[
        "main_channel_outlet_distance_m"
    ] = main_channel_result[
        "outlet_network_distance_m"
    ]

    diagnostic[
        "main_channel_semantics"
    ] = main_channel_result[
        "main_channel_semantics"
    ]

    diagnostic[
        "main_channel_path"
    ] = None if main_channel_result.get('status') == 'unavailable' else str(
        main_channel_path
    )

    pending = diagnostic.get(
        "pending",
        []
    )

    diagnostic["pending"] = [
        item
        for item in pending
        if not item.startswith(
            "Canal principal:"
        )
    ]

    return diagnostic
