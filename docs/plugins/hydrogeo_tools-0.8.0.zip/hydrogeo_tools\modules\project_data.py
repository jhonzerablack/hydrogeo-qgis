"""Read-only validation of project inputs; no hydrological computation."""
import math
from pathlib import Path
from qgis.core import QgsRasterLayer, QgsVectorLayer, QgsUnitTypes
from .hydrology_chain import read_record, digest


def inspect_layer(layer, elevation=False):
    rows = []
    def add(status, message): rows.append((status, message))
    if layer is None or not layer.isValid():
        return [('ERRO', 'Camada ausente ou ilegível.')]
    source = layer.source().split('|')[0]
    local = Path(source)
    if layer.providerType() != 'memory' and not local.is_file():
        add('ERRO' if layer.providerType() in ('gdal', 'ogr') and '://' not in source and not source.startswith('/vsi') else 'AVISO', 'Fonte ausente ou não local verificável: ' + source)
    elif local.is_file():
        try:
            with local.open('rb') as stream: stream.read(1)
            add('PASS', 'Fonte local legível: ' + source)
        except OSError as error: add('ERRO', str(error))
    crs = layer.crs()
    if not crs.isValid(): add('ERRO', 'SRC ausente; defina o SRC correto em uma cópia, conforme a origem dos dados.')
    elif crs.isGeographic() or crs.mapUnits() != QgsUnitTypes.DistanceUnit.DistanceMeters:
        add('ERRO' if elevation else 'AVISO', 'SRC não projetado em metros: ' + crs.authid())
    else: add('PASS', 'SRC projetado em metros: ' + crs.authid())
    ext = layer.extent()
    if not all(math.isfinite(v) for v in [ext.xMinimum(),ext.yMinimum(),ext.xMaximum(),ext.yMaximum()]):
        add('ERRO', 'Extensão não finita.')
    else: add('PASS', 'Extensão: ' + ext.toString())
    if isinstance(layer, QgsRasterLayer):
        if layer.width() <= 0 or layer.height() <= 0 or layer.bandCount() < 1:
            add('ERRO', 'Raster sem células ou bandas.')
        else:
            rx, ry = abs(layer.rasterUnitsPerPixelX()), abs(layer.rasterUnitsPerPixelY())
            add('PASS' if rx > 0 and ry > 0 else 'ERRO', f'Resolução: {rx:g} × {ry:g}; {layer.bandCount()} banda(s).')
            block = layer.dataProvider().block(1, ext, min(layer.width(),32), min(layer.height(),32))
            add('PASS' if block and block.isValid() else 'ERRO', 'Leitura amostral da banda 1 (não certifica todos os pixels).')
        if elevation:
            if layer.bandCount() != 1: add('ERRO', 'MDT/MDE deve ter uma banda de elevação.')
            add('AVISO', 'Unidade vertical e natureza MDT/MDS dependem da documentação da fonte.')
    elif isinstance(layer, QgsVectorLayer):
        count = 0
        for feature in layer.getFeatures():
            count += 1
            g = feature.geometry()
            if g.isNull() or g.isEmpty() or not g.isGeosValid():
                add('ERRO', f'Feição {feature.id()}: geometria vazia/inválida. Execute Verificar validade e Corrigir geometrias em uma cópia; revise limites e conectividade antes de recalcular. Original preservado.')
        if not count: add('ERRO', 'Vetor vazio.')
        elif not any(s == 'ERRO' for s,m in rows): add('PASS', f'{count} feição(ões) com geometria válida.')
    if local.is_file():
        try:
            record = read_record(source)
            if record:
                add('PASS', 'Hash do produto confere com proveniência: ' + str(record.get('role')))
                for name, parent in record.get('inputs', {}).items():
                    p = Path(parent.get('path',''))
                    if not p.is_file(): add('ERRO', 'Referência ausente: ' + name + ': ' + str(p))
                    elif digest(p) != parent.get('sha256'): add('ERRO', 'Hash da referência diverge: ' + name)
                    else: add('PASS', 'Referência conferida: ' + name)
            else: add('AVISO', 'Sem proveniência HydroGeo registrada; origem não comprovada.')
        except Exception as error: add('ERRO', 'Proveniência inválida: ' + str(error))
    return rows


def load_inputs(paths, raster=False):
    """Validate the entire selection before publishing any layer to the project."""
    layers = []
    for filename in paths:
        if not Path(filename).is_file(): raise ValueError('Arquivo ausente: ' + filename)
        layer = QgsRasterLayer(filename, Path(filename).stem) if raster else QgsVectorLayer(filename, Path(filename).stem, 'ogr')
        issues = inspect_layer(layer)
        errors = [message for status,message in issues if status == 'ERRO']
        if errors: raise ValueError(filename + '\n' + '\n'.join(errors))
        layers.append(layer)
    return layers
